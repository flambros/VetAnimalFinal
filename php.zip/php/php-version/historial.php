<?php
// historial.php - Pacientes y Ficha Médica
require_once __DIR__ . '/backend/config/db.php';
require_once __DIR__ . '/frontend/includes/header.php';

// Procesar agregar nueva mascota (Gato, Perro, etc.)
$mensajeMascota = '';
if (isset($_POST['action']) && $_POST['action'] === 'nueva_mascota') {
    $usuario_id = !empty($_SESSION['user']['id']) ? $_SESSION['user']['id'] : 3;
    $nombre = trim($_POST['nombre'] ?? '');
    $especie = trim($_POST['especie'] ?? 'Perro');
    $raza = trim($_POST['raza'] ?? 'Mestizo');
    $edad = intval($_POST['edad'] ?? 1);
    $peso = floatval($_POST['peso'] ?? 4.0);
    $foto = trim($_POST['foto'] ?? '');

    if (empty($foto)) {
        $foto = ($especie === 'Gato')
            ? 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=500&q=80'
            : 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=500&q=80';
    }

    if (!empty($nombre)) {
        $stmt = $pdo->prepare("
            INSERT INTO mascotas (usuario_id, nombre, especie, raza, edad, peso, foto, estado_salud)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'Estable')
        ");
        $stmt->execute([$usuario_id, $nombre, $especie, $raza, $edad, $peso, $foto]);
        $mensajeMascota = "¡$nombre ($especie) ha sido agregado exitosamente a la base de datos!";
    }
}

// Obtener todas las mascotas de la base de datos
$mascotas = $pdo->query("SELECT * FROM mascotas ORDER BY id DESC")->fetchAll();

// Obtener registros médicos
$historial = $pdo->query("
    SELECT h.*, m.nombre as mascota_nombre, m.especie as mascota_especie, m.foto as mascota_foto
    FROM historial_clinico h
    LEFT JOIN mascotas m ON h.mascota_id = m.id
    ORDER BY h.fecha DESC
")->fetchAll();
?>

<div class="container section">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:28px; flex-wrap:wrap; gap:16px;">
        <div>
            <h1>Pacientes e Historial Clínico</h1>
            <p style="color:var(--text-muted);">Registro de mascotas atendidas y fichas de evolución médica con diagnóstico y radiografías.</p>
        </div>
        <button class="btn btn-primary" onclick="mostrarModalMascota()">
            🐾 Registrar Nueva Mascota (Gato / Perro)
        </button>
    </div>

    <?php if (!empty($mensajeMascota)): ?>
        <div style="background:#ecfdf5; border:1px solid #6ee7b7; color:#065f46; padding:14px 18px; border-radius:var(--radius-md); margin-bottom:24px;">
            ✅ <?= htmlspecialchars($mensajeMascota) ?>
        </div>
    <?php endif; ?>

    <!-- Cuadrícula de Mascotas Registradas -->
    <h2 style="font-size:1.4rem; margin-bottom:16px;">Mascotas en Base de Datos (<?= count($mascotas) ?>)</h2>
    <div class="cards-grid" style="margin-bottom:40px;">
        <?php foreach ($mascotas as $m): ?>
            <div class="card fade-in pet-card">
                <img src="<?= htmlspecialchars($m['foto']) ?>" alt="<?= htmlspecialchars($m['nombre']) ?>" class="pet-avatar">
                <div style="flex:1;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <h3 style="font-size:1.15rem;"><?= htmlspecialchars($m['nombre']) ?></h3>
                        <span class="badge" style="font-size:0.75rem;"><?= htmlspecialchars($m['especie']) ?></span>
                    </div>
                    <p style="color:var(--text-muted); font-size:0.85rem; margin-top:2px;">
                        <?= htmlspecialchars($m['raza'] ?? 'Mestizo') ?> • <?= htmlspecialchars($m['edad'] ?? 1) ?> años • <?= htmlspecialchars($m['peso'] ?? 5) ?> kg
                    </p>
                    <div style="margin-top:6px; font-size:0.8rem; color:#10b981; font-weight:600;">
                        ● <?= htmlspecialchars($m['estado_salud'] ?? 'Saludable') ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Fichas Médicas de Evolución -->
    <h2 style="font-size:1.4rem; margin-bottom:16px;">Fichas Médicas y Diagnósticos</h2>
    <div style="display:flex; flex-direction:column; gap:18px;">
        <?php if (empty($historial)): ?>
            <div class="card" style="text-align:center; padding:30px;">
                <p style="color:var(--text-muted);">No hay consultas médicas registradas aún.</p>
            </div>
        <?php else: ?>
            <?php foreach ($historial as $h): ?>
                <div class="card fade-in" style="display:grid; grid-template-columns: auto 1fr; gap:24px; align-items:start;">
                    <div style="text-align:center;">
                        <img src="<?= htmlspecialchars($h['mascota_foto']) ?>" alt="<?= htmlspecialchars($h['mascota_nombre']) ?>" style="width:64px; height:64px; border-radius:50%; object-fit:cover; margin-bottom:6px;">
                        <div style="font-weight:700; font-size:0.9rem;"><?= htmlspecialchars($h['mascota_nombre']) ?></div>
                    </div>

                    <div>
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:8px; flex-wrap:wrap; gap:8px;">
                            <h3 style="font-size:1.2rem;"><?= htmlspecialchars($h['motivo']) ?></h3>
                            <span class="badge">📅 <?= htmlspecialchars($h['fecha']) ?></span>
                        </div>

                        <div style="background:#f8fafc; padding:14px; border-radius:var(--radius-md); border:1px solid var(--border-color); margin-bottom:12px;">
                            <p style="font-size:0.95rem; margin-bottom:6px;">
                                <strong>Diagnóstico Clínico:</strong> <?= htmlspecialchars($h['diagnostico']) ?>
                            </p>
                            <p style="font-size:0.9rem; color:var(--text-muted);">
                                <strong>Tratamiento Indicado:</strong> <?= htmlspecialchars($h['tratamiento']) ?>
                            </p>
                        </div>

                        <div style="display:flex; justify-content:space-between; align-items:center; font-size:0.85rem; color:var(--text-muted); flex-wrap:wrap; gap:8px;">
                            <div>👨‍⚕️ Atendido por: <strong><?= htmlspecialchars($h['veterinario']) ?></strong> (<?= htmlspecialchars($h['sede']) ?>)</div>

                            <?php if (!empty($h['radiografia_url'])): ?>
                                <a href="<?= htmlspecialchars($h['radiografia_url']) ?>" target="_blank" class="btn btn-outline" style="font-size:0.8rem; padding:4px 10px;">
                                    🔍 Ver Placa Radiográfica
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Modal para Registrar Nueva Mascota (Perro, Gato, etc) -->
<div id="modal-mascota" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(15,23,42,0.6); z-index:100; align-items:center; justify-content:center;">
    <div class="card" style="width:100%; max-width:500px; padding:30px; box-shadow:var(--shadow-xl);">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
            <h2>Nueva Mascota</h2>
            <button onclick="cerrarModalMascota()" style="background:none; border:none; font-size:1.5rem; cursor:pointer; color:var(--text-muted);">&times;</button>
        </div>

        <form method="POST">
            <input type="hidden" name="action" value="nueva_mascota">

            <div class="form-group">
                <label class="form-label">Nombre de la Mascota</label>
                <input type="text" name="nombre" class="form-control" placeholder="Ej: Milo, Luna, Simón" required>
            </div>

            <div class="form-group">
                <label class="form-label">Especie</label>
                <select name="especie" class="form-control" required>
                    <option value="Gato">Gato 🐱</option>
                    <option value="Perro">Perro 🐶</option>
                    <option value="Conejo">Conejo 🐰</option>
                    <option value="Ave">Ave 🦜</option>
                    <option value="Otro">Otro</option>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">Raza</label>
                <input type="text" name="raza" class="form-control" placeholder="Ej: Siamés, Golden Retriever, Mestizo">
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                <div class="form-group">
                    <label class="form-label">Edad (Años)</label>
                    <input type="number" name="edad" class="form-control" min="0" max="30" value="2">
                </div>
                <div class="form-group">
                    <label class="form-label">Peso (Kg)</label>
                    <input type="number" step="0.1" name="peso" class="form-control" value="4.5">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Foto URL (Opcional)</label>
                <input type="url" name="foto" class="form-control" placeholder="https://... o dejá vacío para foto automática">
            </div>

            <div style="display:flex; justify-content:flex-end; gap:12px; margin-top:20px;">
                <button type="button" class="btn btn-outline" onclick="cerrarModalMascota()">Cancelar</button>
                <button type="submit" class="btn btn-primary">Guardar en Base de Datos</button>
            </div>
        </form>
    </div>
</div>

<script>
function mostrarModalMascota() {
    document.getElementById('modal-mascota').style.display = 'flex';
}
function cerrarModalMascota() {
    document.getElementById('modal-mascota').style.display = 'none';
}
</script>

<?php require_once __DIR__ . '/frontend/includes/footer.php'; ?>
