-- ==========================================================
-- VetAnimal Clínica Veterinaria - Base de Datos MySQL
-- Compatible con XAMPP (phpMyAdmin) y PHP 7.4 / 8.x
-- ==========================================================

CREATE DATABASE IF NOT EXISTS `vetanimal_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `vetanimal_db`;

-- Tabla de Usuarios (Veterinarios y Clientes)
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(100) NOT NULL,
  `email` VARCHAR(120) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `rol` ENUM('veterinario', 'cliente') NOT NULL DEFAULT 'cliente',
  `telefono` VARCHAR(30) NULL,
  `especialidad` VARCHAR(100) NULL,
  `api_key` VARCHAR(64) NOT NULL UNIQUE,
  `creado_en` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabla de Mascotas (Perros, Gatos, etc.)
CREATE TABLE IF NOT EXISTS `mascotas` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `usuario_id` INT NOT NULL,
  `nombre` VARCHAR(60) NOT NULL,
  `especie` VARCHAR(30) NOT NULL,
  `raza` VARCHAR(60) NULL,
  `edad` INT NULL,
  `peso` DECIMAL(5,2) NULL,
  `foto` TEXT NULL,
  `estado_salud` VARCHAR(50) DEFAULT 'Estable',
  `alergias` VARCHAR(150) NULL,
  `condiciones_cronicas` TEXT NULL,
  `creado_en` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`usuario_id`) REFERENCES `usuarios`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabla de Turnos (Consultas Generales y Especializadas)
CREATE TABLE IF NOT EXISTS `turnos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `usuario_id` INT NOT NULL,
  `mascota_id` INT NOT NULL,
  `fecha` DATE NOT NULL,
  `hora` VARCHAR(10) NOT NULL,
  `motivo` VARCHAR(150) NOT NULL,
  `tipo` ENUM('general', 'especializado') DEFAULT 'general',
  `veterinario` VARCHAR(100) NOT NULL,
  `sede` VARCHAR(100) DEFAULT 'Sede Central Del Viso (Av. Eduardo Madero 1250)',
  `estado` ENUM('pendiente', 'confirmado', 'completado', 'cancelado') DEFAULT 'pendiente',
  `notas` TEXT NULL,
  `creado_en` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`usuario_id`) REFERENCES `usuarios`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`mascota_id`) REFERENCES `mascotas`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabla de Historial Clínico y Diagnósticos
CREATE TABLE IF NOT EXISTS `historial_clinico` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `mascota_id` INT NOT NULL,
  `fecha` DATE NOT NULL,
  `motivo` VARCHAR(150) NOT NULL,
  `diagnostico` TEXT NOT NULL,
  `tratamiento` TEXT NOT NULL,
  `veterinario` VARCHAR(100) NOT NULL,
  `sede` VARCHAR(100) DEFAULT 'Sede Central Del Viso',
  `radiografia_url` TEXT NULL,
  `creado_en` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`mascota_id`) REFERENCES `mascotas`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabla de Productos de la Tienda y Farmacia
CREATE TABLE IF NOT EXISTS `productos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(120) NOT NULL,
  `categoria` VARCHAR(60) NOT NULL,
  `precio` DECIMAL(10,2) NOT NULL,
  `stock` INT NOT NULL DEFAULT 10,
  `imagen` TEXT NULL,
  `descripcion` TEXT NULL,
  `creado_en` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabla de Órdenes y Compras
CREATE TABLE IF NOT EXISTS `pedidos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_code` VARCHAR(30) NOT NULL,
  `usuario_id` INT NOT NULL,
  `cliente_nombre` VARCHAR(100) NOT NULL,
  `cliente_email` VARCHAR(120) NOT NULL,
  `total` DECIMAL(10,2) NOT NULL,
  `estado` ENUM('pendiente', 'pagado', 'entregado') DEFAULT 'pagado',
  `creado_en` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- Datos Iniciales de Prueba
-- ==========================================================

-- Usuarios (Clave default: "123456" y "Admin2026!")
INSERT INTO `usuarios` (`id`, `nombre`, `email`, `password`, `rol`, `telefono`, `especialidad`, `api_key`) VALUES
(1, 'Dr. Santiago Méndez (Admin)', 'admin@vetanimal.com', '$2y$10$e8w.xQ.50sYV5H.q2Wp.6.vD5O.N/WqYlIq80.d2Oqv0G8j56q1j2', 'veterinario', '11-4000-1000', 'Medicina General y Cirugía', 'vet_admin_secret_key_2026_x99'),
(2, 'Dra. Martina Paz', 'martina.paz@vetanimal.com', '$2y$10$e8w.xQ.50sYV5H.q2Wp.6.vD5O.N/WqYlIq80.d2Oqv0G8j56q1j2', 'veterinario', '11-4000-1001', 'Cardiología y Ecodoppler', 'vet_martina_secret_key_2026'),
(3, 'Agustina Gómez (Cliente)', 'agustina.gomez@example.com', '$2y$10$e8w.xQ.50sYV5H.q2Wp.6.vD5O.N/WqYlIq80.d2Oqv0G8j56q1j2', 'cliente', '11-5555-2222', NULL, 'client_agustina_api_key_8832');

-- Mascotas
INSERT INTO `mascotas` (`id`, `usuario_id`, `nombre`, `especie`, `raza`, `edad`, `peso`, `foto`, `estado_salud`, `alergias`, `condiciones_cronicas`) VALUES
(1, 3, 'Bella', 'Perro', 'Golden Retriever', 4, 28.50, 'https://images.unsplash.com/photo-1552053831-71594a27632d?w=500&q=80', 'Estable', 'Picaduras de pulgas', 'Ninguna'),
(2, 3, 'Milo', 'Gato', 'Siamés', 2, 4.20, 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=500&q=80', 'Excelente', 'Ninguna', 'Ninguna'),
(3, 3, 'Luna', 'Gato', 'Carey / Europeo', 3, 3.80, 'https://images.unsplash.com/photo-1573865526739-10659fec78a5?w=500&q=80', 'En tratamiento', 'Ciertos cereales', 'Gastroenteritis leve en remisión'),
(4, 3, 'Simba', 'Gato', 'Común Naranja', 1, 4.50, 'https://images.unsplash.com/photo-1543852786-1cf6624b9987?w=500&q=80', 'Saludable', 'Ninguna', 'Ninguna');

-- Turnos
INSERT INTO `turnos` (`id`, `usuario_id`, `mascota_id`, `fecha`, `hora`, `motivo`, `tipo`, `veterinario`, `sede`, `estado`) VALUES
(1, 3, 1, '2026-09-20', '10:30', 'Control Clínico Anual y Vacunación', 'general', 'Dr. Santiago Méndez', 'Sede Central Del Viso (Av. Eduardo Madero 1250)', 'confirmado'),
(2, 3, 2, '2026-09-22', '16:00', 'Ecocardiograma Doppler Preventivo', 'especializado', 'Dra. Martina Paz', 'Sede Central Del Viso / Red Tortuguitas', 'pendiente');

-- Historial Clínico
INSERT INTO `historial_clinico` (`id`, `mascota_id`, `fecha`, `motivo`, `diagnostico`, `tratamiento`, `veterinario`, `sede`, `radiografia_url`) VALUES
(1, 1, '2026-08-15', 'Revisión por claudicación en miembro posterior derecho', 'Esguince leve en articulación tibiotarsiana. Placa radiográfica sin fisuras óseas.', 'Reposo relativo 7 días y Meloxicam 0.1 mg/kg vía oral cada 24 hs.', 'Dr. Santiago Méndez', 'Sede Central Del Viso', 'https://images.unsplash.com/photo-1516549655169-df83a0774514?w=600&q=80'),
(2, 2, '2026-07-10', 'Control de rutina y desparasitación', 'Paciente felino normopeso, auscultación cardiopulmonar fisiológica y mucosas rosadas.', 'Praziquantel + Pirantel suspensión oral y plan de refuerzo Triple Felina.', 'Dra. Martina Paz', 'Sede Central Del Viso', NULL);

-- Productos
INSERT INTO `productos` (`id`, `nombre`, `categoria`, `precio`, `stock`, `imagen`, `descripcion`) VALUES
(1, 'Alimento Royal Canin Mini Adult 7.5kg', 'Alimentos', 34500.00, 15, 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=400&q=80', 'Nutrición balanceada de alta gama para perros adultos pequeños.'),
(2, 'Pipeta Antiparasitaria Frontline Plus Perros', 'Farmacia', 9800.00, 24, 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400&q=80', 'Elimina pulgas, garrapatas y piojos en caninos de 10 a 20 kg.'),
(3, 'Alimento Cat Chow Gatitos Carne & Leche 3kg', 'Alimentos', 16200.00, 18, 'https://images.unsplash.com/photo-1548767797-d8c844163c4c?w=400&q=80', 'Proteínas de alta biodisponibilidad y DHA para el desarrollo cognitivo felino.'),
(4, 'Shampoo Dermatológico Antiséptico Clorhexidina', 'Higiene', 8400.00, 12, 'https://images.unsplash.com/photo-1535294435445-d7249524ef2e?w=400&q=80', 'Fórmula medicada suave para el alivio de dermatitis e irritaciones.');
