<?php
// turnos.php - Gestión y Reserva de Turnos
require_once __DIR__ . '/backend/config/db.php';
require_once __DIR__ . '/frontend/includes/header.php';

// Procesar cancelación de turno directa desde PHP
if (isset($_POST['action']) && $_POST['action'] === 'cancelar' && !empty($_POST['turno_id'])) {
    $turnoId = intval($_POST['turno_id']);
    $stmt = $pdo->prepare("UPDATE turnos SET estado = 'cancelado' WHERE id = ?");
    $stmt->execute([$turnoId]);
    $mensajeExito = "El turno #$turnoId ha sido cancelado exitosamente.";
}

// Procesar nuevo turno desde PHP (POST tradicional o con JS)
if (isset($_POST['action']) && $_POST['action'] === 'crear') {
    $usuario_id = !empty($_SESSION['user']['id']) ? $_SESSION['user']['id'] : 3;
    $mascota_id = intval($_POST['mascota_id'] ?? 1);
    $fecha = trim($_POST['fecha'] ?? '');
    $hora = trim($_POST['hora'] ?? '10:00');
    $motivo = trim($_POST['motivo'] ?? 'Control General');
    $tipo = trim($_POST['tipo'] ?? 'general');
    $veterinario = trim($_POST['veterinario'] ?? 'Dr. Santiago Méndez');
    $sede = ($tipo === 'especializado') 
        ? 'Sede Central Del Viso / Red Tortuguitas' 
        : 'Sede Central Del Viso (Av. Eduardo Madero 1250)';

    if (!empty($fecha)) {
        $stmt = $pdo->prepare("
            INSERT INTO turnos (usuario_id, mascota_id, fecha, hora, motivo, tipo, veterinario, sede, estado)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'confirmado')
        ");
        $stmt->execute([$usuario_id, $mascota_id, $fecha, $hora, $motivo, $tipo, $veterinario, $sede]);
        $mensajeExito = "¡Turno agendado correctamente para el $fecha a las $hora hs con $veterinario!";
    }
}

// Consultar turnos activos
$stmtTurnos = $pdo->query("
    SELECT t.*, m.nombre as mascota_nombre, m.especie as mascota_especie, u.nombre as dueno_nombre
    FROM turnos t
    LEFT JOIN mascotas m ON t.mascota_id = m.id
    LEFT JOIN usuarios u ON t.usuario_id = u.id
    WHERE t.estado != 'cancelado'
    ORDER BY t.fecha ASC, t.hora ASC
");
$turnos = $stmtTurnos->fetchAll();

// Mascotas disponibles para el select
$mascotas = $pdo->query("SELECT id, nombre, especie, raza FROM mascotas ORDER BY nombre ASC")->fetchAll();
?>

<div class="container section">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:28px; flex-wrap:wrap; gap:16px;">
        <div>
            <h1>Gestión de Turnos</h1>
            <p style="color:var(--text-muted);">Agendá consultas clínicas o estudios de alta complejidad para tu mascota.</p>
        </div>
        <button id="btn-nuevo-turno" class="btn btn-primary" onclick="mostrarModalTurno()">
            ➕ Agendar Nuevo Turno
        </button>
    </div>

    <?php if (!empty($mensajeExito)): ?>
        <div style="background:#ecfdf5; border:1px solid #6ee7b7; color:#065f46; padding:14px 18px; border-radius:var(--radius-md); margin-bottom:24px;">
            ✅ <?= htmlspecialchars($mensajeExito) ?>
        </div>
    <?php endif; ?>

    <!-- Lista de Turnos Agendados -->
    <div class="cards-grid">
        <?php if (empty($turnos)): ?>
            <div class="card" style="grid-column: 1 / -1; text-align:center; padding:40px;">
                <p style="color:var(--text-muted);">No hay turnos pendientes en este momento.</p>
            </div>
        <?php else: ?>
            <?php foreach ($turnos as $t): ?>
                <div class="card fade-in" style="display:flex; flex-direction:column; justify-content:space-between;">
                    <div>
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:12px;">
                            <span class="badge" style="background:<?= $t['tipo'] === 'especializado' ? '#fef3c7' : '#eff6ff' ?>; color:<?= $t['tipo'] === 'especializado' ? '#b45309' : '#1d4ed8' ?>; border-color:<?= $t['tipo'] === 'especializado' ? '#fde68a' : '#bfdbfe' ?>;">
                                <?= $t['tipo'] === 'especializado' ? '🔬 Especializado' : '🩺 Consulta General' ?>
                            </span>
                            <span style="font-weight:700; color:var(--primary); font-size:1.1rem;">
                                <?= htmlspecialchars($t['hora']) ?> hs
                            </span>
                        </div>

                        <h3 style="font-size:1.2rem; margin-bottom:6px;">
                            🐾 <?= htmlspecialchars($t['mascota_nombre'] ?? 'Mascota') ?> 
                            <small style="font-size:0.85rem; color:var(--text-muted); font-weight:normal;">(<?= htmlspecialchars($t['mascota_especie'] ?? '') ?>)</small>
                        </h3>
                        <p style="font-weight:600; color:#334155; margin-bottom:6px;">
                            <?= htmlspecialchars($t['motivo']) ?>
                        </p>
                        <p style="color:var(--text-muted); font-size:0.9rem; margin-bottom:4px;">
                            📅 <strong>Fecha:</strong> <?= htmlspecialchars($t['fecha']) ?>
                        </p>
                        <p style="color:var(--text-muted); font-size:0.9rem; margin-bottom:4px;">
                            👨‍⚕️ <strong>Veterinario:</strong> <?= htmlspecialchars($t['veterinario']) ?>
                        </p>
                        <p style="color:var(--text-muted); font-size:0.85rem; margin-bottom:12px;">
                            📍 <?= htmlspecialchars($t['sede']) ?>
                        </p>
                    </div>

                    <form method="POST" onsubmit="return confirm('¿Confirmás cancelar este turno?');">
                        <input type="hidden" name="action" value="cancelar">
                        <input type="hidden" name="turno_id" value="<?= $t['id'] ?>">
                        <button type="submit" class="btn btn-outline" style="width:100%; color:#ef4444 !important; border-color:#fca5a5; font-size:0.85rem; padding:8px 12px;">
                            Cancelar Turno
                        </button>
                    </form>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Modal para Reservar Turno con JavaScript y PHP -->
<div id="modal-turno" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(15,23,42,0.6); z-index:100; align-items:center; justify-content:center;">
    <div class="card" style="width:100%; max-width:540px; max-height:90vh; overflow-y:auto; position:relative; padding:30px; box-shadow:var(--shadow-xl);">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
            <h2>Reservar Turno</h2>
            <button onclick="cerrarModalTurno()" style="background:none; border:none; font-size:1.5rem; cursor:pointer; color:var(--text-muted);">&times;</button>
        </div>

        <form method="POST">
            <input type="hidden" name="action" value="crear">

            <div class="form-group">
                <label class="form-label">Paciente / Mascota</label>
                <select name="mascota_id" class="form-control" required>
                    <?php foreach ($mascotas as $m): ?>
                        <option value="<?= $m['id'] ?>">
                            <?= htmlspecialchars($m['nombre']) ?> (<?= htmlspecialchars($m['especie']) ?> - <?= htmlspecialchars($m['raza'] ?? 'Mestizo') ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">Tipo de Atención</label>
                <select name="tipo" id="turno-tipo" class="form-control" onchange="cambiarTipoTurno(this.value)">
                    <option value="general">Clínica General / Vacunación</option>
                    <option value="especializado">Cardiografía / Ecodoppler / Rx (Especializado)</option>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">Motivo de Consulta</label>
                <input type="text" name="motivo" class="form-control" placeholder="Ej: Control de vacunas o revisión cardíaca" required>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                <div class="form-group">
                    <label class="form-label">Fecha</label>
                    <input type="date" name="fecha" class="form-control" min="<?= date('Y-m-d') ?>" value="<?= date('Y-m-d', strtotime('+1 day')) ?>" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Horario</label>
                    <select name="hora" class="form-control">
                        <option value="09:00">09:00 hs</option>
                        <option value="10:30">10:30 hs</option>
                        <option value="12:00">12:00 hs</option>
                        <option value="16:00">16:00 hs</option>
                        <option value="17:30">17:30 hs</option>
                        <option value="19:00">19:00 hs</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Veterinario Asignado</label>
                <select name="veterinario" id="turno-vet" class="form-control">
                    <option value="Dr. Santiago Méndez">Dr. Santiago Méndez (Clínica General & Cirugía)</option>
                    <option value="Dra. Martina Paz">Dra. Martina Paz (Cardiología & Doppler)</option>
                </select>
            </div>

            <div style="display:flex; justify-content:flex-end; gap:12px; margin-top:24px;">
                <button type="button" class="btn btn-outline" onclick="cerrarModalTurno()">Cancelar</button>
                <button type="submit" class="btn btn-primary">Confirmar Turno</button>
            </div>
        </form>
    </div>
</div>

<script>
function mostrarModalTurno() {
    const m = document.getElementById('modal-turno');
    m.style.display = 'flex';
}

function cerrarModalTurno() {
    const m = document.getElementById('modal-turno');
    m.style.display = 'none';
}

function cambiarTipoTurno(tipo) {
    const vetSelect = document.getElementById('turno-vet');
    if (tipo === 'especializado') {
        vetSelect.value = 'Dra. Martina Paz';
    } else {
        vetSelect.value = 'Dr. Santiago Méndez';
    }
}
</script>

<?php require_once __DIR__ . '/frontend/includes/footer.php'; ?>
