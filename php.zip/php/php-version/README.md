# VetAnimal Clínica Veterinaria - Versión PHP + MySQL para XAMPP

Este proyecto ha sido estructurado con una arquitectura limpia de **Frontend** y **Backend**, diseñado específicamente para ejecutarse en un entorno clásico de **XAMPP / WampServer / Laragon**.

---

## 📂 Estructura del Proyecto (Separación Frontend / Backend)

```text
vetanimal/
├── backend/
│   ├── config/
│   │   ├── db.php               -> Conexión a la base de datos MySQL (PDO) con fallback inteligente
│   │   └── api_auth.php         -> Validación y autenticación mediante API Key o sesión
│   └── api/
│       ├── login.php            -> Endpoint para autenticación y entrega de token/API Key
│       ├── turnos.php           -> Endpoint CRUD de turnos (consultas y especializados)
│       ├── pacientes.php        -> Endpoint para listar y registrar mascotas (gatos/perros) e historial
│       ├── tienda.php           -> Endpoint de productos y recepción de pedidos
│       └── chat.php             -> Endpoint del asistente inteligente VetBot
│
├── frontend/
│   ├── css/
│   │   └── style.css            -> Estilos limpios y responsivos con variables CSS y componentes
│   ├── js/
│   │   ├── main.js              -> Animaciones en JavaScript Vanilla (scroll reveal, fade-in, hover)
│   │   ├── api.js               -> Conexiones asíncronas con el backend PHP (fetch + X-API-KEY)
│   │   └── chatbox.js           -> Widget interactivo del Asistente IA flotante
│   └── includes/
│       ├── header.php           -> Cabecera modular con navegación y estado de sesión
│       └── footer.php           -> Pie de página modular con scripts y datos de la clínica
│
├── index.php                    -> Página principal / Dashboard con estadísticas en vivo
├── turnos.php                   -> Gestión y reserva de turnos (generales y especializados)
├── historial.php                -> Ficha de pacientes, radiografías y formulario para agregar mascotas
├── tienda.php                   -> Farmacia y nutrición con carrito de compras en JavaScript
├── login.php                    -> Inicio de sesión tradicional o ingreso directo con API Key
├── logout.php                   -> Cierre de sesión seguro
└── database.sql                 -> Script para importar en phpMyAdmin (tablas y datos iniciales)
```

---

## 🚀 Guía Paso a Paso para Ejecutar en XAMPP

### 1. Descargar e Instalar XAMPP
Si no tenés XAMPP instalado:
* Descargalo gratis desde [apachefriends.org](https://www.apachefriends.org/es/index.html).
* Instala los componentes básicos: **Apache** y **MySQL**.

### 2. Copiar los Archivos a la Carpeta `htdocs`
1. Descomprimí el archivo `vetanimal-php-xampp.zip`.
2. Copiá la carpeta resultante y pegala dentro de:
   ```text
   C:\xampp\htdocs\vetanimal
   ```
   *(Asegurate de que dentro de `C:\xampp\htdocs\vetanimal\` queden directamente archivos como `index.php`, `database.sql`, `backend/`, `frontend/`, etc.)*

### 3. Iniciar Apache y MySQL
1. Abrí el programa **XAMPP Control Panel** desde el menú inicio de Windows.
2. Hacé clic en el botón **"Start"** de **Apache**.
3. Hacé clic en el botón **"Start"** de **MySQL**.
*(Ambos módulos deben ponerse en color verde).*

### 4. Importar la Base de Datos en phpMyAdmin
1. En tu navegador web (Chrome, Edge o Firefox), abrí:
   ```text
   http://localhost/phpmyadmin
   ```
2. En el menú superior, hacé clic en la pestaña **"Importar"** (o *Import*).
3. Hacé clic en **"Seleccionar archivo"** y buscá el archivo `database.sql` que está dentro de `C:\xampp\htdocs\vetanimal\database.sql`.
4. Bajá hasta el final y hacé clic en el botón **"Importar"** (o *Go / Continuar*).
*(Esto creará la base `vetanimal_db` con todas las tablas: usuarios, mascotas, turnos, historial y productos).*

### 5. Abrir la Aplicación en el Navegador
Abrí en tu navegador:
```text
http://localhost/vetanimal
```
¡Listo! La página completa de VetAnimal estará corriendo 100% en PHP y MySQL.

---

## 🔑 Credenciales y API Keys Disponibles

El proyecto soporta autenticación tanto por credenciales como por **API Key**:

| Rol | Email | Contraseña | API Key |
| :--- | :--- | :--- | :--- |
| **Veterinario / Admin** | `admin@vetanimal.com` | `Admin2026!` | `vet_admin_secret_key_2026_x99` |
| **Cliente / Tutor** | `agustina.gomez@example.com` | `123456` | `client_agustina_api_key_8832` |

> Podés ingresar a `http://localhost/vetanimal/login.php` y pegar la API Key directamente para acceder sin tener que recordar contraseñas.

---

## 🎓 ¿Cómo Explicar la Arquitectura a tu Profesor?

1. **Separación de Responsabilidades**:
   * **Backend (`backend/api/`)**: Escrito en PHP puro con sentencias preparadas mediante `PDO` para evitar inyecciones SQL. Devuelve datos en formato JSON y valida peticiones con la cabecera `X-API-KEY`.
   * **Frontend (`frontend/`)**: La presentación está hecha en HTML5 estructurado, con estilos CSS centralizados y responsivos.
2. **Animaciones con JavaScript**:
   * Las transiciones, apariciones suaves al hacer scroll (`IntersectionObserver`), el cálculo de totales en tiempo real del carrito de compras y la apertura del widget flotante del chat están implementados en JavaScript Vanilla (`main.js` y `chatbox.js`).
3. **Conexiones**:
   * El archivo `frontend/js/api.js` centraliza las llamadas `fetch()` asíncronas con el backend en PHP, adjuntando la API Key en las cabeceras HTTP.
