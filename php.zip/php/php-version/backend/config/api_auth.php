<?php
// backend/config/api_auth.php
// Middleware para validar el ingreso mediante API Key o Sesión de Usuario

require_once __DIR__ . '/db.php';

function obtenerApiKeyEnviada() {
    // 1. Cabecera personalizada X-API-KEY
    if (isset($_SERVER['HTTP_X_API_KEY'])) {
        return trim($_SERVER['HTTP_X_API_KEY']);
    }
    // 2. Cabecera Authorization: Bearer <token>
    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $auth = trim($_SERVER['HTTP_AUTHORIZATION']);
        if (stripos($auth, 'Bearer ') === 0) {
            return trim(substr($auth, 7));
        }
        return $auth;
    }
    // 3. Parámetro GET o POST ?api_key=...
    if (!empty($_GET['api_key'])) {
        return trim($_GET['api_key']);
    }
    if (!empty($_POST['api_key'])) {
        return trim($_POST['api_key']);
    }
    return null;
}

function autenticarPorApiKey($pdo) {
    $apiKey = obtenerApiKeyEnviada();

    if ($apiKey) {
        $stmt = $pdo->prepare("SELECT id, nombre, email, rol, especialidad, api_key FROM usuarios WHERE api_key = ? LIMIT 1");
        $stmt->execute([$apiKey]);
        $user = $stmt->fetch();
        if ($user) {
            $_SESSION['user'] = $user;
            return $user;
        }
    }

    // Si ya existe sesión activa en PHP
    if (!empty($_SESSION['user'])) {
        return $_SESSION['user'];
    }

    return null;
}

function requerirAutenticacion($pdo) {
    $user = autenticarPorApiKey($pdo);
    if (!$user) {
        header('Content-Type: application/json', true, 401);
        echo json_encode([
            "error" => "No autorizado. Se requiere una API Key válida o iniciar sesión.",
            "ejemplo_cabecera" => "X-API-KEY: vet_admin_secret_key_2026_x99",
            "api_keys_prueba" => [
                "Administrador / Veterinario" => "vet_admin_secret_key_2026_x99",
                "Cliente Tutor" => "client_agustina_api_key_8832"
            ]
        ]);
        exit;
    }
    return $user;
}
