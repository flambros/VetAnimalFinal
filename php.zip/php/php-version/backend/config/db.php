<?php
// backend/config/db.php
// Archivo de conexión a la Base de Datos (compatible con XAMPP / MySQL y fallback SQLite)

session_start();

$host = '127.0.0.1';
$port = '3306';
$db   = 'vetanimal_db';
$user = 'root';
$pass = ''; // Por defecto en XAMPP la clave de root es vacía
$charset = 'utf8mb4';

$pdo = null;

try {
    // 1. Intentar conexión a MySQL (XAMPP)
    $dsn = "mysql:host=$host;port=$port;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // 2. Si MySQL no está iniciado o aún no importaron la base en phpMyAdmin,
    // usamos SQLite como respaldo automático para que no de pantalla blanca.
    try {
        $sqliteFile = __DIR__ . '/vetanimal_local.sqlite';
        $pdo = new PDO("sqlite:" . $sqliteFile);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        inicializarBaseDatosSqlite($pdo);
    } catch (\Exception $ex) {
        header('Content-Type: application/json');
        die(json_encode([
            "error" => "No se pudo conectar a la base de datos MySQL de XAMPP.",
            "detalle" => $e->getMessage(),
            "ayuda" => "Asegurate de iniciar Apache y MySQL en el panel de control de XAMPP e importar database.sql en phpMyAdmin."
        ]));
    }
}

// Función de inicialización rápida en caso de SQLite
function inicializarBaseDatosSqlite($pdo) {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            rol TEXT NOT NULL,
            telefono TEXT,
            especialidad TEXT,
            api_key TEXT UNIQUE NOT NULL
        );
        CREATE TABLE IF NOT EXISTS mascotas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER,
            nombre TEXT NOT NULL,
            especie TEXT NOT NULL,
            raza TEXT,
            edad INTEGER,
            peso REAL,
            foto TEXT,
            estado_salud TEXT DEFAULT 'Estable'
        );
        CREATE TABLE IF NOT EXISTS turnos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER,
            mascota_id INTEGER,
            fecha TEXT,
            hora TEXT,
            motivo TEXT,
            tipo TEXT,
            veterinario TEXT,
            sede TEXT,
            estado TEXT DEFAULT 'pendiente'
        );
        CREATE TABLE IF NOT EXISTS historial_clinico (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mascota_id INTEGER,
            fecha TEXT,
            motivo TEXT,
            diagnostico TEXT,
            tratamiento TEXT,
            veterinario TEXT,
            sede TEXT,
            radiografia_url TEXT
        );
        CREATE TABLE IF NOT EXISTS productos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            categoria TEXT,
            precio REAL,
            stock INTEGER,
            imagen TEXT,
            descripcion TEXT
        );
    ");

    // Insertar usuario admin si está vacía
    $check = $pdo->query("SELECT COUNT(*) as c FROM usuarios")->fetch();
    if ($check && $check['c'] == 0) {
        $pdo->exec("
            INSERT INTO usuarios (nombre, email, password, rol, telefono, especialidad, api_key)
            VALUES ('Dr. Santiago Méndez (Admin)', 'admin@vetanimal.com', 'Admin2026!', 'veterinario', '11-4000-1000', 'Medicina General y Cirugía', 'vet_admin_secret_key_2026_x99'),
                   ('Agustina Gómez (Cliente)', 'agustina.gomez@example.com', '123456', 'cliente', '11-5555-2222', NULL, 'client_agustina_api_key_8832');

            INSERT INTO mascotas (usuario_id, nombre, especie, raza, edad, peso, foto)
            VALUES (2, 'Bella', 'Perro', 'Golden Retriever', 4, 28.5, 'https://images.unsplash.com/photo-1552053831-71594a27632d?w=500&q=80'),
                   (2, 'Milo', 'Gato', 'Siamés', 2, 4.2, 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=500&q=80');

            INSERT INTO turnos (usuario_id, mascota_id, fecha, hora, motivo, tipo, veterinario, sede, estado)
            VALUES (2, 1, '2026-09-25', '10:00', 'Vacunación y chequeo clínico', 'general', 'Dr. Santiago Méndez', 'Sede Central Del Viso', 'confirmado');

            INSERT INTO productos (nombre, categoria, precio, stock, imagen, descripcion)
            VALUES ('Alimento Royal Canin Mini Adult 7.5kg', 'Alimentos', 34500, 15, 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=400&q=80', 'Nutrición balanceada.'),
                   ('Pipeta Antiparasitaria Frontline Plus', 'Farmacia', 9800, 20, 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400&q=80', 'Antiparasitario externo.');
        ");
    }
}
