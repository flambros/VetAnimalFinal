<?php
// backend/api/tienda.php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/db.php';

$metodo = $_SERVER['REQUEST_METHOD'];

if ($metodo === 'GET') {
    $stmt = $pdo->query("SELECT * FROM productos ORDER BY id ASC");
    echo json_encode($stmt->fetchAll());
    exit;
}

if ($metodo === 'POST') {
    // Procesar pedido / compra
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        $input = $_POST;
    }

    $items = $input['items'] ?? [];
    $nombre = trim($input['cliente_nombre'] ?? 'Cliente VetAnimal');
    $email = trim($input['cliente_email'] ?? 'cliente@vetanimal.com');
    $usuario_id = intval($input['usuario_id'] ?? 3);
    $total = floatval($input['total'] ?? 0);
    $orderCode = 'VET-' . rand(1000, 9999);

    try {
        $stmt = $pdo->prepare("
            INSERT INTO pedidos (order_code, usuario_id, cliente_nombre, cliente_email, total, estado)
            VALUES (?, ?, ?, ?, ?, 'pagado')
        ");
        $stmt->execute([$orderCode, $usuario_id, $nombre, $email, $total]);

        echo json_encode([
            "success" => true,
            "order_code" => $orderCode,
            "total" => $total,
            "mensaje" => "Pedido confirmado con éxito. Te enviamos el comprobante por email."
        ]);
    } catch (\Exception $e) {
        http_response_code(500);
        echo json_encode(["error" => "Error al guardar el pedido: " . $e->getMessage()]);
    }
    exit;
}

http_response_code(405);
echo json_encode(["error" => "Método no permitido"]);
