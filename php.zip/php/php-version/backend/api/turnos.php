<?php
// backend/api/turnos.php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/api_auth.php';

$user = autenticarPorApiKey($pdo);
$metodo = $_SERVER['REQUEST_METHOD'];

if ($metodo === 'GET') {
    // Listar turnos
    $usuario_id = $_GET['usuario_id'] ?? ($user['id'] ?? null);

    if ($user && $user['rol'] === 'veterinario') {
        // El admin/veterinario ve todos los turnos
        $stmt = $pdo->query("
            SELECT t.*, m.nombre as mascota_nombre, m.especie as mascota_especie, u.nombre as cliente_nombre, u.telefono as cliente_telefono
            FROM turnos t
            LEFT JOIN mascotas m ON t.mascota_id = m.id
            LEFT JOIN usuarios u ON t.usuario_id = u.id
            ORDER BY t.fecha ASC, t.hora ASC
        ");
    } else {
        // El cliente ve sus turnos
        $targetUser = $usuario_id ? intval($usuario_id) : 3;
        $stmt = $pdo->prepare("
            SELECT t.*, m.nombre as mascota_nombre, m.especie as mascota_especie
            FROM turnos t
            LEFT JOIN mascotas m ON t.mascota_id = m.id
            WHERE t.usuario_id = ?
            ORDER BY t.fecha ASC, t.hora ASC
        ");
        $stmt->execute([$targetUser]);
    }

    $turnos = $stmt->fetchAll();
    echo json_encode($turnos);
    exit;
}

if ($metodo === 'POST') {
    // Crear un nuevo turno
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        $input = $_POST;
    }

    $usuario_id = intval($input['usuario_id'] ?? ($user['id'] ?? 3));
    $mascota_id = intval($input['mascota_id'] ?? 1);
    $fecha = trim($input['fecha'] ?? '');
    $hora = trim($input['hora'] ?? '10:00');
    $motivo = trim($input['motivo'] ?? 'Consulta Veterinaria General');
    $tipo = trim($input['tipo'] ?? 'general');
    $veterinario = trim($input['veterinario'] ?? 'Dr. Santiago Méndez');
    $sede = trim($input['sede'] ?? 'Sede Central Del Viso (Av. Eduardo Madero 1250)');

    if (empty($fecha)) {
        http_response_code(400);
        echo json_encode(["error" => "La fecha del turno es obligatoria"]);
        exit;
    }

    $stmt = $pdo->prepare("
        INSERT INTO turnos (usuario_id, mascota_id, fecha, hora, motivo, tipo, veterinario, sede, estado)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'confirmado')
    ");
    $stmt->execute([$usuario_id, $mascota_id, $fecha, $hora, $motivo, $tipo, $veterinario, $sede]);
    $nuevoId = $pdo->lastInsertId();

    echo json_encode([
        "success" => true,
        "mensaje" => "Turno agendado con éxito",
        "id" => $nuevoId,
        "turno" => [
            "id" => $nuevoId,
            "fecha" => $fecha,
            "hora" => $hora,
            "motivo" => $motivo,
            "veterinario" => $veterinario,
            "sede" => $sede,
            "estado" => "confirmado"
        ]
    ]);
    exit;
}

if ($metodo === 'DELETE' || ($metodo === 'POST' && isset($_POST['_method']) && $_POST['_method'] === 'DELETE')) {
    $id = intval($_GET['id'] ?? 0);
    if ($id > 0) {
        $stmt = $pdo->prepare("UPDATE turnos SET estado = 'cancelado' WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(["success" => true, "mensaje" => "Turno cancelado"]);
        exit;
    }
}

http_response_code(405);
echo json_encode(["error" => "Método no permitido"]);
