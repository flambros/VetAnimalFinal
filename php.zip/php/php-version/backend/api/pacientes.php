<?php
// backend/api/pacientes.php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/api_auth.php';

$user = autenticarPorApiKey($pdo);
$metodo = $_SERVER['REQUEST_METHOD'];

if ($metodo === 'GET') {
    $action = $_GET['action'] ?? 'mascotas';

    if ($action === 'historial') {
        $mascota_id = intval($_GET['mascota_id'] ?? 0);
        if ($mascota_id > 0) {
            $stmt = $pdo->prepare("SELECT * FROM historial_clinico WHERE mascota_id = ? ORDER BY fecha DESC");
            $stmt->execute([$mascota_id]);
        } else {
            $stmt = $pdo->query("SELECT * FROM historial_clinico ORDER BY fecha DESC");
        }
        echo json_encode($stmt->fetchAll());
        exit;
    }

    // Listar Mascotas
    $all = isset($_GET['all']) && $_GET['all'] === 'true';
    if ($all || ($user && $user['rol'] === 'veterinario')) {
        $stmt = $pdo->query("
            SELECT m.*, u.nombre as dueno, u.telefono
            FROM mascotas m
            LEFT JOIN usuarios u ON m.usuario_id = u.id
            ORDER BY m.id DESC
        ");
    } else {
        $targetUser = intval($_GET['usuario_id'] ?? ($user['id'] ?? 3));
        $stmt = $pdo->prepare("
            SELECT m.*, u.nombre as dueno, u.telefono
            FROM mascotas m
            LEFT JOIN usuarios u ON m.usuario_id = u.id
            WHERE m.usuario_id = ?
            ORDER BY m.id DESC
        ");
        $stmt->execute([$targetUser]);
    }

    echo json_encode($stmt->fetchAll());
    exit;
}

if ($metodo === 'POST') {
    // Registrar nueva mascota
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        $input = $_POST;
    }

    $usuario_id = intval($input['usuario_id'] ?? ($user['id'] ?? 3));
    $nombre = trim($input['nombre'] ?? '');
    $especie = trim($input['especie'] ?? 'Perro');
    $raza = trim($input['raza'] ?? 'Mestizo');
    $edad = !empty($input['edad']) ? intval($input['edad']) : 1;
    $peso = !empty($input['peso']) ? floatval($input['peso']) : 5.0;
    $foto = trim($input['foto'] ?? '');

    if (empty($foto)) {
        $foto = ($especie === 'Gato')
            ? 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=500&q=80'
            : 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=500&q=80';
    }

    if (empty($nombre)) {
        http_response_code(400);
        echo json_encode(["error" => "El nombre de la mascota es requerido"]);
        exit;
    }

    $stmt = $pdo->prepare("
        INSERT INTO mascotas (usuario_id, nombre, especie, raza, edad, peso, foto, estado_salud)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'Estable')
    ");
    $stmt->execute([$usuario_id, $nombre, $especie, $raza, $edad, $peso, $foto]);
    $nuevoId = $pdo->lastInsertId();

    echo json_encode([
        "success" => true,
        "mensaje" => "Mascota registrada correctamente",
        "id" => $nuevoId,
        "nombre" => $nombre,
        "especie" => $especie
    ]);
    exit;
}

http_response_code(405);
echo json_encode(["error" => "Método no permitido"]);
