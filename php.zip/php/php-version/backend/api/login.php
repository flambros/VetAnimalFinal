<?php
// backend/api/login.php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/db.php';

$metodo = $_SERVER['REQUEST_METHOD'];

if ($metodo === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        $input = $_POST;
    }

    $email = trim($input['email'] ?? '');
    $password = trim($input['password'] ?? '');

    if (empty($email) || empty($password)) {
        http_response_code(400);
        echo json_encode(["error" => "Email y contraseña son requeridos"]);
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    $valido = false;
    if ($user) {
        // Soporta tanto password_hash de PHP como texto plano de prueba en clase
        if (password_verify($password, $user['password']) || $user['password'] === $password) {
            $valido = true;
        }
    }

    if ($valido) {
        unset($user['password']); // No exponer password
        $_SESSION['user'] = $user;

        echo json_encode([
            "success" => true,
            "mensaje" => "Inicio de sesión exitoso",
            "api_key" => $user['api_key'],
            "user" => $user
        ]);
    } else {
        http_response_code(401);
        echo json_encode(["error" => "Credenciales incorrectas"]);
    }
    exit;
}

if ($metodo === 'GET') {
    // Retorna usuario logueado o requiere api key
    require_once __DIR__ . '/../config/api_auth.php';
    $user = autenticarPorApiKey($pdo);
    if ($user) {
        echo json_encode(["logged_in" => true, "user" => $user]);
    } else {
        echo json_encode(["logged_in" => false]);
    }
    exit;
}

http_response_code(405);
echo json_encode(["error" => "Método no permitido"]);
