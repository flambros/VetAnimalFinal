<?php
// backend/api/chat.php
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    $input = $_POST;
}

$userMessage = trim($input['message'] ?? '');
if (empty($userMessage)) {
    http_response_code(400);
    echo json_encode(["error" => "El mensaje no puede estar vacío"]);
    exit;
}

$lower = mb_strtolower($userMessage, 'UTF-8');

// 1. Respuestas Rápidas Inteligentes de la Clínica
if (strpos($lower, 'ayuno') !== false || strpos($lower, 'ecograf') !== false || strpos($lower, 'sangre') !== false) {
    $reply = "🐾 **Preparación para estudios en VetAnimal Del Viso:**\n\n• **Ecografía Abdominal:** 8 a 10 horas de ayuno sólido (agua permitida hasta 2 hs antes). Vejiga moderadamente llena.\n• **Análisis de Sangre:** 8 a 12 horas de ayuno.\n• **Radiografías:** No requieren ayuno salvo indicación de sedación.\n\n¿Deseas agendar un turno ahora?";
} elseif (strpos($lower, 'vacun') !== false || strpos($lower, 'cachorr') !== false || strpos($lower, 'gatit') !== false) {
    $reply = "🐾 **Plan de Vacunación Preventivo:**\n\n• **Cachorros Caninos:** A partir de los 45 días (Séxtuple con refuerzos cada 21 días) y Antirrábica a los 3 meses.\n• **Gatitos Felinos:** Triple Felina a los 60 días con su refuerzo y Antirrábica anual.\n\n*Nota:* La mascota debe estar desparasitada antes de vacunarse.";
} elseif (strpos($lower, 'horario') !== false || strpos($lower, 'donde') !== false || strpos($lower, 'direcci') !== false || strpos($lower, 'ubicaci') !== false) {
    $reply = "🏥 **VetAnimal Clínica Veterinaria:**\n\n• **Sede Central:** Av. Eduardo Madero 1250, Del Viso (Partido del Pilar).\n• **Horarios:** Lunes a Sábados de 08:30 a 20:00 hs.\n• **Urgencias / Guardia:** (02320) 47-1234 / 11-4000-1000.\n• **Red de Derivaciones:** Centro Asociado Tortuguitas (Cura Brochero 1420).";
} elseif (strpos($lower, 'cardio') !== false || strpos($lower, 'doppler') !== false || strpos($lower, 'rayos') !== false || strpos($lower, 'rx') !== false) {
    $reply = "❤️ **Estudios de Alta Complejidad:**\n\nCoordinamos turnos para Cardiografía, Ecocardiograma Doppler y Radiología Digital HD en Del Viso y con derivación asistida a Tortuguitas. Podés pedirlo desde la sección Turnos Especializados.";
} elseif (strpos($lower, 'ahoga') !== false || strpos($lower, 'respir') !== false || strpos($lower, 'urgenc') !== false || strpos($lower, 'emergenc') !== false) {
    $reply = "🚨 **¡ATENCIÓN - URGENCIA VETERINARIA!**\n\nAcudí inmediatamente a nuestra guardia presencial en **Av. Eduardo Madero 1250, Del Viso**. Mantené a tu mascota en un lugar fresco y no comprimas su cuello. Tel: (02320) 47-1234.";
} else {
    $reply = "🐾 ¡Hola! Soy **VetBot**, el asistente virtual de **VetAnimal Del Viso**.\n\nPodés consultarme sobre:\n• Ayuno y preparación de ecografías o análisis\n• Calendario de vacunas para perros y gatos\n• Horarios y ubicación en Del Viso\n• Cómo agendar turnos clínicos o especializados.\n\n¿En qué te puedo asesorar hoy?";
}

echo json_encode([
    "reply" => $reply,
    "source" => "vetbot-php"
]);
