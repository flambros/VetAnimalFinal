// frontend/js/main.js
// Animaciones e interactividad visual con JavaScript Vanilla

document.addEventListener('DOMContentLoaded', () => {
    // 1. Animación de aparición suave al hacer scroll (Fade-in reveal)
    const fadeElements = document.querySelectorAll('.fade-in, .card, .hero-section');
    
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -40px 0px'
    };

    const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                // Efecto de entrada suave
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    fadeElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(18px)';
        el.style.transition = 'opacity 0.5s ease-out, transform 0.5s ease-out';
        revealObserver.observe(el);
    });

    // 2. Efecto de cabecera fija con sombra al scrollear
    const header = document.querySelector('.site-header');
    if (header) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 20) {
                header.style.boxShadow = '0 4px 20px -2px rgba(0, 0, 0, 0.1)';
            } else {
                header.style.boxShadow = '0 1px 2px rgba(0, 0, 0, 0.05)';
            }
        });
    }

    // 3. Efectos hover interactivos en tarjetas
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transition = 'transform 0.25s ease, box-shadow 0.25s ease';
        });
    });
});
