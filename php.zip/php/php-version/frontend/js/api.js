// frontend/js/api.js
// Conexiones asíncronas con el backend en PHP mediante Fetch API y cabecera X-API-KEY

const API_CONFIG = {
    baseUrl: 'backend/api',
    apiKeyStorageKey: 'vetanimal_api_key',
    userStorageKey: 'vetanimal_user'
};

// Obtener o guardar la API Key actual
function getApiKey() {
    return localStorage.getItem(API_CONFIG.apiKeyStorageKey) || 'client_agustina_api_key_8832';
}

function setApiKey(key) {
    localStorage.setItem(API_CONFIG.apiKeyStorageKey, key);
}

function getUsuarioActual() {
    const raw = localStorage.getItem(API_CONFIG.userStorageKey);
    return raw ? JSON.parse(raw) : null;
}

function setUsuarioActual(user) {
    if (user) {
        localStorage.setItem(API_CONFIG.userStorageKey, JSON.stringify(user));
        if (user.api_key) setApiKey(user.api_key);
    } else {
        localStorage.removeItem(API_CONFIG.userStorageKey);
    }
}

// Cliente HTTP centralizado para todas las conexiones con PHP
async function apiRequest(endpoint, options = {}) {
    const url = `${API_CONFIG.baseUrl}/${endpoint}`;
    const headers = {
        'Content-Type': 'application/json',
        'X-API-KEY': getApiKey(),
        ...(options.headers || {})
    };

    try {
        const response = await fetch(url, { ...options, headers });
        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || `Error en la petición HTTP: ${response.status}`);
        }

        return data;
    } catch (err) {
        console.error(`[API ERROR en ${endpoint}]:`, err);
        throw err;
    }
}

// Métodos de negocio específicos
const VetApi = {
    // 1. Autenticación y Login
    async login(email, password) {
        const res = await apiRequest('login.php', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });
        if (res.success && res.user) {
            setUsuarioActual(res.user);
            setApiKey(res.api_key);
        }
        return res;
    },

    logout() {
        setUsuarioActual(null);
        localStorage.removeItem(API_CONFIG.apiKeyStorageKey);
        window.location.href = 'login.php';
    },

    // 2. Turnos
    async getTurnos(usuarioId = null) {
        const query = usuarioId ? `?usuario_id=${usuarioId}` : '';
        return await apiRequest(`turnos.php${query}`, { method: 'GET' });
    },

    async crearTurno(turnoData) {
        return await apiRequest('turnos.php', {
            method: 'POST',
            body: JSON.stringify(turnoData)
        });
    },

    async cancelarTurno(turnoId) {
        return await apiRequest(`turnos.php?id=${turnoId}`, {
            method: 'DELETE'
        });
    },

    // 3. Mascotas y Pacientes
    async getMascotas(usuarioId = null) {
        const query = usuarioId ? `?usuario_id=${usuarioId}` : '';
        return await apiRequest(`pacientes.php${query}`, { method: 'GET' });
    },

    async getHistorialClinico(mascotaId = null) {
        const query = mascotaId ? `?action=historial&mascota_id=${mascotaId}` : '?action=historial';
        return await apiRequest(`pacientes.php${query}`, { method: 'GET' });
    },

    async crearMascota(mascotaData) {
        return await apiRequest('pacientes.php', {
            method: 'POST',
            body: JSON.stringify(mascotaData)
        });
    },

    // 4. Tienda
    async getProductos() {
        return await apiRequest('tienda.php', { method: 'GET' });
    },

    async realizarPedido(pedidoData) {
        return await apiRequest('tienda.php', {
            method: 'POST',
            body: JSON.stringify(pedidoData)
        });
    },

    // 5. Chat con Asistente
    async enviarMensajeChat(mensaje) {
        return await apiRequest('chat.php', {
            method: 'POST',
            body: JSON.stringify({ message: mensaje })
        });
    }
};
