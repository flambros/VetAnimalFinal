// frontend/js/chatbox.js
// Asistente Clínico VetBot Flotante con animaciones JavaScript y conexión a chat.php

document.addEventListener('DOMContentLoaded', () => {
    // Inyectar HTML del widget si no existe
    if (!document.getElementById('vetbot-widget-container')) {
        const widgetContainer = document.createElement('div');
        widgetContainer.id = 'vetbot-widget-container';
        widgetContainer.className = 'chatbox-widget';
        widgetContainer.innerHTML = `
            <div id="vetbot-window" class="chatbox-window">
                <div class="chatbox-header">
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span style="font-size: 1.3rem;">🤖</span>
                        <div>
                            <div style="font-weight:700; font-size:0.95rem;">VetBot Asistente Clínico</div>
                            <div style="font-size:0.75rem; opacity:0.85;">En línea | VetAnimal Del Viso</div>
                        </div>
                    </div>
                    <button id="vetbot-close-btn" style="background:none; border:none; color:white; font-size:1.4rem; cursor:pointer;">&times;</button>
                </div>

                <div id="vetbot-messages" class="chatbox-messages">
                    <div class="chat-bubble chat-bubble-bot">
                        ¡Hola! Soy <strong>VetBot</strong> 🐾. ¿En qué te puedo asesorar hoy sobre vacunas, ayuno para ecografías o turnos en Del Viso?
                    </div>
                </div>

                <!-- Sugerencias rápidas -->
                <div id="vetbot-chips" style="padding: 8px 12px; background:#f1f5f9; display:flex; gap:6px; overflow-x:auto; border-top:1px solid #e2e8f0;">
                    <button class="chat-chip" data-msg="¿Cuánto tiempo de ayuno para una ecografía?">🍽️ Ayuno Ecografía</button>
                    <button class="chat-chip" data-msg="¿Qué vacunas necesita mi cachorro o gatito?">💉 Vacunas</button>
                    <button class="chat-chip" data-msg="¿Dónde queda la sede y qué horarios tienen?">🏥 Ubicación</button>
                </div>

                <form id="vetbot-form" class="chatbox-input-area">
                    <input id="vetbot-input" type="text" class="form-control" placeholder="Escribí tu consulta aquí..." autocomplete="off" style="padding:8px 12px; font-size:0.9rem;" required>
                    <button type="submit" class="btn btn-primary" style="padding:8px 14px; font-size:0.9rem;">Enviar</button>
                </form>
            </div>

            <button id="vetbot-toggle-btn" class="chatbox-toggle-btn">
                <span>💬</span>
                <span>Asistente IA</span>
            </button>
        `;
        document.body.appendChild(widgetContainer);

        // Estilos de los chips
        const style = document.createElement('style');
        style.innerHTML = `
            .chat-chip {
                background: white;
                border: 1px solid #cbd5e1;
                border-radius: 20px;
                padding: 4px 10px;
                font-size: 0.75rem;
                cursor: pointer;
                white-space: nowrap;
                color: #334155;
                transition: all 0.2s;
            }
            .chat-chip:hover {
                background: #2563eb;
                color: white;
                border-color: #2563eb;
            }
        `;
        document.head.appendChild(style);
    }

    // Elementos
    const toggleBtn = document.getElementById('vetbot-toggle-btn');
    const closeBtn = document.getElementById('vetbot-close-btn');
    const chatWindow = document.getElementById('vetbot-window');
    const chatForm = document.getElementById('vetbot-form');
    const chatInput = document.getElementById('vetbot-input');
    const chatMessages = document.getElementById('vetbot-messages');
    const chips = document.querySelectorAll('.chat-chip');

    // Toggle abrir/cerrar con animación suave
    function toggleChat(abrir) {
        if (abrir) {
            chatWindow.classList.add('open');
            chatWindow.style.opacity = '0';
            chatWindow.style.transform = 'translateY(15px)';
            chatWindow.style.transition = 'all 0.25s ease';
            setTimeout(() => {
                chatWindow.style.opacity = '1';
                chatWindow.style.transform = 'translateY(0)';
                chatInput.focus();
            }, 20);
        } else {
            chatWindow.style.opacity = '0';
            chatWindow.style.transform = 'translateY(15px)';
            setTimeout(() => {
                chatWindow.classList.remove('open');
            }, 200);
        }
    }

    toggleBtn.addEventListener('click', () => {
        const isOpen = chatWindow.classList.contains('open');
        toggleChat(!isOpen);
    });

    closeBtn.addEventListener('click', () => {
        toggleChat(false);
    });

    // Enviar mensaje
    async function sendMessage(texto) {
        if (!texto) return;

        // 1. Agregar burbuja de usuario
        const userBubble = document.createElement('div');
        userBubble.className = 'chat-bubble chat-bubble-user';
        userBubble.textContent = texto;
        chatMessages.appendChild(userBubble);
        chatMessages.scrollTop = chatMessages.scrollHeight;

        // 2. Burbuja de "escribiendo..."
        const typingBubble = document.createElement('div');
        typingBubble.className = 'chat-bubble chat-bubble-bot';
        typingBubble.innerHTML = '<em>VetBot está escribiendo...</em>';
        chatMessages.appendChild(typingBubble);
        chatMessages.scrollTop = chatMessages.scrollHeight;

        try {
            // Conexión con backend PHP
            const res = await VetApi.enviarMensajeChat(texto);
            
            // Reemplazar indicador por respuesta real
            typingBubble.innerHTML = formatMarkdown(res.reply || 'No obtuve respuesta.');
        } catch (err) {
            typingBubble.innerHTML = '⚠️ Ocurrió un error al consultar el servidor. Podés llamarnos al (02320) 47-1234.';
        }

        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const msg = chatInput.value.trim();
        if (msg) {
            sendMessage(msg);
            chatInput.value = '';
        }
    });

    // Chips de preguntas sugeridas
    chips.forEach(chip => {
        chip.addEventListener('click', () => {
            const msg = chip.getAttribute('data-msg');
            sendMessage(msg);
        });
    });

    // Formateador simple de negritas y viñetas
    function formatMarkdown(text) {
        return text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\n• /g, '<br>• ')
            .replace(/\n\n/g, '<br><br>');
    }
});
