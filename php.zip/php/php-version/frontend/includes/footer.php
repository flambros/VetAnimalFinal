</main>

<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">
            <div class="footer-col">
                <div class="logo-brand" style="color:white; margin-bottom:12px;">
                    <span>🐾</span>
                    <span>VetAnimal Del Viso</span>
                </div>
                <p style="color:#94a3b8; font-size:0.9rem;">
                    Atención veterinaria integral, diagnóstico por imágenes de alta complejidad y medicina preventiva.
                </p>
            </div>

            <div class="footer-col">
                <h4>Sede Central</h4>
                <p>📍 Av. Eduardo Madero 1250, Del Viso</p>
                <p>📞 Tel: (02320) 47-1234</p>
                <p>🕒 Lun a Sáb: 08:30 a 20:00 hs</p>
            </div>

            <div class="footer-col">
                <h4>Red Asociada</h4>
                <p>🏥 Centro Tortuguitas: Cura Brochero 1420</p>
                <p>🩺 Cardiografía, Doppler y Rayos X</p>
                <p>🚨 Guardia 24hs: 11-4000-1000</p>
            </div>

            <div class="footer-col">
                <h4>Tecnología del Proyecto</h4>
                <p>🐘 Backend: PHP 7.4+ / 8.x con PDO</p>
                <p>🐬 Base de Datos: MySQL (XAMPP)</p>
                <p>✨ Frontend: HTML5 + CSS3 + JS Vanilla</p>
            </div>
        </div>

        <div class="footer-bottom">
            <p>&copy; <?= date('Y') ?> VetAnimal Clínica Veterinaria. Proyecto Académico PHP + JavaScript.</p>
        </div>
    </div>
</footer>

<!-- Scripts JavaScript para Conexiones y Animaciones -->
<script src="frontend/js/api.js"></script>
<script src="frontend/js/main.js"></script>
<script src="frontend/js/chatbox.js"></script>

</body>
</html>
