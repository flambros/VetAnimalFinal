<?php
// frontend/includes/header.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$currentUser = $_SESSION['user'] ?? null;
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VetAnimal - Clínica Veterinaria (PHP & MySQL)</title>
    <!-- Estilos CSS -->
    <link rel="stylesheet" href="frontend/css/style.css">
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%232563eb'><path d='M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z'/></svg>">
</head>
<body>

<header class="site-header">
    <div class="container">
        <a href="index.php" class="logo-brand">
            <span style="font-size:1.8rem;">🐾</span>
            <span>VetAnimal</span>
        </a>

        <nav>
            <ul class="nav-links">
                <li><a href="index.php" class="<?= $currentPage === 'index.php' ? 'active' : '' ?>">Inicio</a></li>
                <li><a href="turnos.php" class="<?= $currentPage === 'turnos.php' ? 'active' : '' ?>">Reservar Turno</a></li>
                <li><a href="historial.php" class="<?= $currentPage === 'historial.php' ? 'active' : '' ?>">Historial Clínico</a></li>
                <li><a href="tienda.php" class="<?= $currentPage === 'tienda.php' ? 'active' : '' ?>">Tienda</a></li>

                <?php if ($currentUser): ?>
                    <li style="display:flex; align-items:center; gap:8px;">
                        <span class="badge">
                            👤 <?= htmlspecialchars($currentUser['nombre']) ?> (<?= ucfirst($currentUser['rol']) ?>)
                        </span>
                    </li>
                    <li><a href="logout.php" class="btn btn-outline" style="padding:6px 12px; font-size:0.85rem;">Salir</a></li>
                <?php else: ?>
                    <li><a href="login.php" class="btn btn-primary">Ingresar con API Key</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header>
<main>
