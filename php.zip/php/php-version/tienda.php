<?php
// tienda.php - Farmacia y Nutrición Veterinaria
require_once __DIR__ . '/backend/config/db.php';
require_once __DIR__ . '/frontend/includes/header.php';

$mensajeCompra = '';
if (isset($_POST['action']) && $_POST['action'] === 'comprar') {
    $cliente = trim($_POST['cliente'] ?? 'Cliente VetAnimal');
    $email = trim($_POST['email'] ?? 'cliente@vetanimal.com');
    $total = floatval($_POST['total'] ?? 0);
    $orderCode = 'VET-' . rand(1000, 9999);

    if ($total > 0) {
        $stmt = $pdo->prepare("
            INSERT INTO pedidos (order_code, usuario_id, cliente_nombre, cliente_email, total, estado)
            VALUES (?, 3, ?, ?, ?, 'pagado')
        ");
        $stmt->execute([$orderCode, $cliente, $email, $total]);
        $mensajeCompra = "¡Compra confirmada con éxito! Código de Pedido: <strong>#$orderCode</strong> por $" . number_format($total, 2, ',', '.') . " ARS.";
    }
}

// Consultar productos
$productos = $pdo->query("SELECT * FROM productos ORDER BY id ASC")->fetchAll();
?>

<div class="container section">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:28px; flex-wrap:wrap; gap:16px;">
        <div>
            <h1>Tienda & Farmacia Veterinaria</h1>
            <p style="color:var(--text-muted);">Alimentos clínicos, pipetas antiparasitarias y fármacos con asesoramiento profesional.</p>
        </div>
        <button class="btn btn-primary" onclick="abrirCarrito()">
            🛒 Ver Carrito (<span id="cart-counter">0</span>)
        </button>
    </div>

    <?php if (!empty($mensajeCompra)): ?>
        <div style="background:#ecfdf5; border:1px solid #6ee7b7; color:#065f46; padding:14px 18px; border-radius:var(--radius-md); margin-bottom:24px;">
            ✅ <?= $mensajeCompra ?>
        </div>
    <?php endif; ?>

    <div class="cards-grid">
        <?php foreach ($productos as $p): ?>
            <div class="card fade-in" style="display:flex; flex-direction:column; justify-content:space-between;">
                <div>
                    <img src="<?= htmlspecialchars($p['imagen']) ?>" alt="<?= htmlspecialchars($p['nombre']) ?>" style="width:100%; height:190px; object-fit:cover; border-radius:var(--radius-md); margin-bottom:14px;">
                    <span class="badge" style="margin-bottom:8px; font-size:0.75rem;"><?= htmlspecialchars($p['categoria']) ?></span>
                    <h3 style="font-size:1.15rem; margin-bottom:6px;"><?= htmlspecialchars($p['nombre']) ?></h3>
                    <p style="color:var(--text-muted); font-size:0.85rem; margin-bottom:14px;">
                        <?= htmlspecialchars($p['descripcion']) ?>
                    </p>
                </div>

                <div>
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                        <span style="font-size:1.3rem; font-weight:800; color:var(--primary);">
                            $<?= number_format($p['precio'], 0, ',', '.') ?> ARS
                        </span>
                        <span style="font-size:0.8rem; color:var(--text-muted);">Stock: <?= $p['stock'] ?></span>
                    </div>

                    <button class="btn btn-outline" style="width:100%;" onclick="agregarAlCarrito(<?= $p['id'] ?>, '<?= addslashes(htmlspecialchars($p['nombre'])) ?>', <?= $p['precio'] ?>)">
                        ➕ Agregar al Carrito
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Modal Carrito de Compras en JavaScript -->
<div id="modal-carrito" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(15,23,42,0.6); z-index:100; align-items:center; justify-content:center;">
    <div class="card" style="width:100%; max-width:480px; padding:30px; box-shadow:var(--shadow-xl);">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
            <h2>Tu Carrito</h2>
            <button onclick="cerrarCarrito()" style="background:none; border:none; font-size:1.5rem; cursor:pointer; color:var(--text-muted);">&times;</button>
        </div>

        <div id="carrito-items" style="max-height:240px; overflow-y:auto; margin-bottom:20px;">
            <p style="color:var(--text-muted); text-align:center;">El carrito está vacío.</p>
        </div>

        <div style="border-top:1px solid var(--border-color); padding-top:16px; margin-bottom:20px; display:flex; justify-content:space-between; font-weight:700; font-size:1.2rem;">
            <span>Total:</span>
            <span id="carrito-total">$0 ARS</span>
        </div>

        <form method="POST">
            <input type="hidden" name="action" value="comprar">
            <input type="hidden" name="total" id="form-total" value="0">

            <div class="form-group">
                <label class="form-label">Tu Nombre y Apellido</label>
                <input type="text" name="cliente" class="form-control" value="<?= htmlspecialchars($_SESSION['user']['nombre'] ?? 'Agustina Gómez') ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Email de Confirmación</label>
                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($_SESSION['user']['email'] ?? 'agustina.gomez@example.com') ?>" required>
            </div>

            <button type="submit" id="btn-checkout" class="btn btn-primary" style="width:100%;" disabled>
                Confirmar Compra
            </button>
        </form>
    </div>
</div>

<script>
let carrito = [];

function agregarAlCarrito(id, nombre, precio) {
    const item = carrito.find(i => i.id === id);
    if (item) {
        item.cantidad++;
    } else {
        carrito.push({ id, nombre, precio, cantidad: 1 });
    }
    actualizarCarritoUI();
}

function actualizarCarritoUI() {
    const counter = document.getElementById('cart-counter');
    const itemsContainer = document.getElementById('carrito-items');
    const totalEl = document.getElementById('carrito-total');
    const formTotal = document.getElementById('form-total');
    const btnCheckout = document.getElementById('btn-checkout');

    const totalCount = carrito.reduce((sum, i) => sum + i.cantidad, 0);
    const totalPrice = carrito.reduce((sum, i) => sum + (i.precio * i.cantidad), 0);

    counter.textContent = totalCount;
    totalEl.textContent = '$' + totalPrice.toLocaleString('es-AR') + ' ARS';
    formTotal.value = totalPrice;

    if (carrito.length === 0) {
        itemsContainer.innerHTML = '<p style="color:var(--text-muted); text-align:center;">El carrito está vacío.</p>';
        btnCheckout.disabled = true;
    } else {
        itemsContainer.innerHTML = carrito.map((item, idx) => `
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; font-size:0.9rem; padding-bottom:8px; border-bottom:1px solid #f1f5f9;">
                <div>
                    <strong>${item.nombre}</strong><br>
                    <span style="color:var(--text-muted);">${item.cantidad} x $${item.precio.toLocaleString('es-AR')}</span>
                </div>
                <button type="button" onclick="eliminarItem(${idx})" style="background:none; border:none; color:#ef4444; cursor:pointer; font-size:1.1rem;">&times;</button>
            </div>
        `).join('');
        btnCheckout.disabled = false;
    }
}

function eliminarItem(idx) {
    carrito.splice(idx, 1);
    actualizarCarritoUI();
}

function abrirCarrito() {
    document.getElementById('modal-carrito').style.display = 'flex';
}

function cerrarCarrito() {
    document.getElementById('modal-carrito').style.display = 'none';
}
</script>

<?php require_once __DIR__ . '/frontend/includes/footer.php'; ?>
