<?php
// index.php - Página Principal
require_once __DIR__ . '/backend/config/db.php';
require_once __DIR__ . '/frontend/includes/header.php';

// Consultar estadísticas de la clínica desde PHP
$totalMascotas = $pdo->query("SELECT COUNT(*) FROM mascotas")->fetchColumn();
$totalTurnos = $pdo->query("SELECT COUNT(*) FROM turnos WHERE estado != 'cancelado'")->fetchColumn();
$totalProductos = $pdo->query("SELECT COUNT(*) FROM productos")->fetchColumn();
?>

<!-- Sección Hero con Animaciones JS -->
<section class="hero-section">
    <div class="container hero-grid">
        <div class="fade-in">
            <span class="badge" style="margin-bottom:16px;">
                ⭐ Atención Médica Veterinaria de Excelencia
            </span>
            <h1 class="hero-title">Cuidamos la salud y felicidad de tus mascotas</h1>
            <p class="hero-subtitle">
                Desde controles preventivos y vacunación hasta cardiografía, ecografías y radiología digital de alta resolución en Del Viso y Tortuguitas.
            </p>
            <div style="display:flex; gap:14px; flex-wrap:wrap;">
                <a href="turnos.php" class="btn btn-primary">📅 Reservar Turno Online</a>
                <a href="historial.php" class="btn btn-outline">📋 Ver Pacientes e Historial</a>
            </div>

            <div class="hero-badges">
                <span class="badge">📍 Del Viso: Av. Madero 1250</span>
                <span class="badge">🕒 Lun a Sáb 8:30 a 20:00 hs</span>
                <span class="badge">🤖 Asistente IA VetBot Activo</span>
            </div>
        </div>

        <div class="fade-in" style="text-align:center;">
            <img src="https://images.unsplash.com/photo-1628009368231-7bb7cfcb0def?w=700&q=80" alt="Veterinaria VetAnimal" style="width:100%; max-width:480px; border-radius:var(--radius-lg); box-shadow:var(--shadow-xl); border:3px solid white;">
        </div>
    </div>
</section>

<!-- Estadísticas en Vivo (PHP Backend) -->
<section class="section" style="background:#ffffff; border-bottom:1px solid var(--border-color);">
    <div class="container">
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:20px; text-align:center;">
            <div class="card" style="border:none; box-shadow:none;">
                <div style="font-size:2.5rem; font-weight:800; color:var(--primary);"><?= $totalMascotas ?></div>
                <div style="color:var(--text-muted); font-weight:600;">Mascotas Atendidas</div>
            </div>
            <div class="card" style="border:none; box-shadow:none;">
                <div style="font-size:2.5rem; font-weight:800; color:#10b981;"><?= $totalTurnos ?></div>
                <div style="color:var(--text-muted); font-weight:600;">Turnos Activos</div>
            </div>
            <div class="card" style="border:none; box-shadow:none;">
                <div style="font-size:2.5rem; font-weight:800; color:#8b5cf6;"><?= $totalProductos ?></div>
                <div style="color:var(--text-muted); font-weight:600;">Productos en Farmacia</div>
            </div>
            <div class="card" style="border:none; box-shadow:none;">
                <div style="font-size:2.5rem; font-weight:800; color:#f59e0b;">24 hs</div>
                <div style="color:var(--text-muted); font-weight:600;">Guardia y Urgencias</div>
            </div>
        </div>
    </div>
</section>

<!-- Servicios Principales -->
<section class="section">
    <div class="container">
        <h2 class="section-title">Servicios Médicos Especializados</h2>
        <p class="section-subtitle">
            Infraestructura clínica moderna y profesionales comprometidos con el bienestar animal.
        </p>

        <div class="cards-grid">
            <div class="card fade-in">
                <div style="font-size:2.2rem; margin-bottom:14px;">🩺</div>
                <h3>Clínica General y Vacunas</h3>
                <p style="color:var(--text-muted); margin:10px 0 16px;">
                    Planes completos para cachorros y adultos. Desparasitación interna y externa periódica.
                </p>
                <a href="turnos.php" class="btn btn-outline" style="width:100%;">Pedir Turno General</a>
            </div>

            <div class="card fade-in">
                <div style="font-size:2.2rem; margin-bottom:14px;">❤️</div>
                <h3>Cardiología y Ecocardiograma</h3>
                <p style="color:var(--text-muted); margin:10px 0 16px;">
                    Diagnóstico cardiovascular avanzado y Ecodoppler con derivación prioritaria a nuestro centro asociado.
                </p>
                <a href="turnos.php?tipo=especializado" class="btn btn-outline" style="width:100%;">Turno Especializado</a>
            </div>

            <div class="card fade-in">
                <div style="font-size:2.2rem; margin-bottom:14px;">🦴</div>
                <h3>Radiología Digital HD</h3>
                <p style="color:var(--text-muted); margin:10px 0 16px;">
                    Placas óseas y torácicas de alta definición con informes clínicos directos en el historial del paciente.
                </p>
                <a href="historial.php" class="btn btn-outline" style="width:100%;">Ver Historial Médico</a>
            </div>
        </div>
    </div>
</section>

<!-- Panel Informativo de la API Key para el Alumno/Profesor -->
<section class="section" style="background:#f1f5f9;">
    <div class="container">
        <div class="card" style="border-left:4px solid var(--primary); background:white;">
            <div style="display:flex; gap:16px; align-items:flex-start;">
                <div style="font-size:2rem;">🔑</div>
                <div>
                    <h3 style="margin-bottom:6px;">Autenticación con API Key (Para el Profesor y Evaluaciones)</h3>
                    <p style="color:var(--text-muted); margin-bottom:12px; font-size:0.95rem;">
                        Este proyecto cuenta con autenticación por <strong>API Key</strong> en PHP. Podés probar las conexiones enviando la clave en la cabecera <code>X-API-KEY</code> o ingresando directamente desde la pantalla de Login:
                    </p>
                    <div style="background:#0f172a; color:#38bdf8; padding:12px 16px; border-radius:var(--radius-sm); font-family:monospace; font-size:0.85rem; overflow-x:auto;">
                        Veterinario Admin: <strong>vet_admin_secret_key_2026_x99</strong><br>
                        Cliente Demo: <strong>client_agustina_api_key_8832</strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/frontend/includes/footer.php'; ?>
