import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import nodemailer from "nodemailer";
import { GoogleGenAI } from "@google/genai";

const app = express();
const PORT = 3000;

// Soportar subida de radiografías e imágenes médicas en base64 de alta resolución
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Configuración de transporte de correo electrónico profesional y seguro
const getMailTransporter = () => {
  let host = (process.env.SMTP_HOST || "smtp.gmail.com").trim();
  // Validación de host: Si es puramente numérico (ej. "123456") o no tiene formato de host/dominio válido
  if (/^\d+$/.test(host) || !host.includes(".")) {
    host = "smtp.gmail.com";
  }

  // Validación de puerto: Debe ser un entero válido en el rango TCP [1, 65535]
  const rawPort = Number(process.env.SMTP_PORT);
  let port = 587;
  if (Number.isInteger(rawPort) && rawPort > 0 && rawPort < 65536) {
    port = rawPort;
  }

  const user = (process.env.SMTP_USER || "veterinariavet101@gmail.com").trim();
  const pass = (process.env.SMTP_PASS || "").trim();

  // Si la contraseña es un valor de prueba/dummy de configuración ("123456", "password", etc.) o está vacía,
  // evitamos disparar intentos fallidos contra servidores reales y operamos en modo registro seguro
  const isDummyPass =
    !pass ||
    pass === "123456" ||
    pass === "password" ||
    pass.startsWith("MY_") ||
    pass.length < 8;

  if (isDummyPass) {
    return null;
  }

  return nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: { user, pass },
    tls: { rejectUnauthorized: false },
    connectionTimeout: 5000,
    greetingTimeout: 5000,
    socketTimeout: 5000,
  });
};

async function sendRealEmail({
  to,
  subject,
  html,
  text,
  bcc = "veterinariavet101@gmail.com",
}: {
  to: string;
  subject: string;
  html: string;
  text?: string;
  bcc?: string;
}) {
  const transporter = getMailTransporter();
  const from =
    process.env.SMTP_FROM && process.env.SMTP_FROM.includes("@")
      ? process.env.SMTP_FROM
      : '"VetAnimal Clínica Veterinaria" <veterinariavet101@gmail.com>';

  if (!transporter) {
    console.log(
      `[EMAIL RECORD] Notificación generada para: ${to} (Copia clínica: ${bcc}). Asunto: "${subject}". Estado: Registrado con éxito en el sistema VetAnimal.`
    );
    return {
      success: true,
      delivered: false,
      mode: "recorded_ready_for_credentials",
      recipient: to,
      clinicInbox: "veterinariavet101@gmail.com",
      message: "Correo registrado con éxito en el sistema VetAnimal.",
    };
  }

  try {
    const info = await transporter.sendMail({
      from,
      to,
      bcc,
      subject,
      text: text || html.replace(/<[^>]*>?/gm, ""),
      html,
    });
    console.log(`[EMAIL DISPATCH] Correo enviado exitosamente a ${to} (ID: ${info.messageId})`);
    return {
      success: true,
      delivered: true,
      mode: "smtp_live",
      messageId: info.messageId,
      recipient: to,
      clinicInbox: "veterinariavet101@gmail.com",
    };
  } catch (err: any) {
    console.warn(`[EMAIL NOTICE] No se pudo enviar por SMTP a ${to} (${err.message}). Se mantiene la copia registrada en el sistema.`);
    return {
      success: true,
      delivered: false,
      mode: "fallback_recorded",
      error: err.message,
      recipient: to,
      clinicInbox: "veterinariavet101@gmail.com",
      message: "Notificación guardada en el sistema.",
    };
  }
}

// ==========================================
// IN-MEMORY DATABASE SEEDED WITH VETANIMAL DATA
// ==========================================

let users = [
  {
    id: 1,
    nombre: "Dr. Santiago Méndez (Admin)",
    email: "admin@vetanimal.com",
    password: "Admin2026!",
    rol: "veterinario" as const,
    telefono: "11-4000-1000",
    especialidad: "Medicina General y Cirugía",
    foto: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=200&q=80",
  },
  {
    id: 2,
    nombre: "Dra. Martina Paz",
    email: "martina.paz@vetanimal.com",
    password: "123456",
    rol: "veterinario" as const,
    telefono: "11-4000-1001",
    especialidad: "Emergencias y Cuidados Críticos",
    foto: "https://images.unsplash.com/photo-1594824813566-78809a712f5a?w=200&q=80",
  },
  {
    id: 3,
    nombre: "Agustina Gómez",
    email: "agustina.gomez@example.com",
    password: "123456",
    rol: "cliente" as const,
    telefono: "11-5555-2222",
    especialidad: null,
    foto: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&q=80",
  },
  {
    id: 4,
    nombre: "Carlos Bianchi",
    email: "carlos.bianchi@example.com",
    password: "123456",
    rol: "cliente" as const,
    telefono: "11-4433-2211",
    especialidad: null,
    foto: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80",
  },
  {
    id: 5,
    nombre: "Valeria Rossi",
    email: "valeria.rossi@example.com",
    password: "123456",
    rol: "cliente" as const,
    telefono: "11-6677-8899",
    especialidad: null,
    foto: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&q=80",
  },
];

let pets = [
  {
    id: 1,
    usuario_id: 3,
    nombre: "Bella",
    especie: "Perro",
    raza: "Golden Retriever",
    edad: 4,
    peso: 28.5,
    foto: "https://images.unsplash.com/photo-1552053831-71594a27632d?w=500&q=80",
    estado_salud: "Estable",
    alergias: "Picaduras de Pulga, Polen",
    condiciones_cronicas: "Ninguna diagnosticada a la fecha.",
    creado_en: "2024-01-10 10:00:00",
  },
  {
    id: 2,
    usuario_id: 3,
    nombre: "Milo",
    especie: "Gato",
    raza: "Siamés / Pelo Corto",
    edad: 3,
    peso: 4.2,
    foto: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=500&q=80",
    estado_salud: "Estable",
    alergias: "Ninguna",
    condiciones_cronicas: "Control preventivo de vías urinarias.",
    creado_en: "2024-03-15 14:30:00",
  },
  {
    id: 3,
    usuario_id: 3,
    nombre: "Luna",
    especie: "Gato",
    raza: "Mestiza Carey / Tricolor",
    edad: 2,
    peso: 3.6,
    foto: "https://images.unsplash.com/photo-1573865526739-10659fec78a5?w=500&q=80",
    estado_salud: "Estable",
    alergias: "Sensibilidad a pescados comerciales",
    condiciones_cronicas: "Esterilizada. Vacunación completa.",
    creado_en: "2024-06-20 09:15:00",
  },
  {
    id: 4,
    usuario_id: 4,
    nombre: "Simba",
    especie: "Gato",
    raza: "Europeo Atigrado Naranja",
    edad: 1,
    peso: 4.0,
    foto: "https://images.unsplash.com/photo-1533738363-b7f9aef128ce?w=500&q=80",
    estado_salud: "Estable",
    alergias: "Ninguna",
    condiciones_cronicas: "Plan de vacunación inicial completado.",
    creado_en: "2025-01-12 11:20:00",
  },
  {
    id: 5,
    usuario_id: 4,
    nombre: "Rocky",
    especie: "Perro",
    raza: "Boxer",
    edad: 5,
    peso: 31.0,
    foto: "https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=500&q=80",
    estado_salud: "En tratamiento",
    alergias: "Ninguna",
    condiciones_cronicas: "Soplo sistólico en seguimiento. Derivado a Tortuguitas para ecocardiograma doppler.",
    creado_en: "2023-11-05 16:40:00",
  },
  {
    id: 6,
    usuario_id: 5,
    nombre: "Oliver",
    especie: "Gato",
    raza: "British Shorthair Gris",
    edad: 4,
    peso: 5.2,
    foto: "https://images.unsplash.com/photo-1561948955-570b270e7c36?w=500&q=80",
    estado_salud: "Estable",
    alergias: "Ninguna",
    condiciones_cronicas: "Profilaxis y limpieza dental programada.",
    creado_en: "2024-02-18 10:00:00",
  },
];

let services = [
  {
    id: 1,
    nombre: "Chequeo General",
    descripcion: "Consulta médica preventiva estándar de 30 minutos",
    duracion_min: 30,
    precio: 25.0,
    icono: "heart",
    categoria: "general" as const,
  },
  {
    id: 2,
    nombre: "Cirugía Avanzada",
    descripcion: "Salas quirúrgicas con bloque extendido y monitoreo multiparamétrico",
    duracion_min: 90,
    precio: 250.0,
    icono: "scalpel",
    categoria: "general" as const,
  },
  {
    id: 3,
    nombre: "Diagnósticos de Laboratorio",
    descripcion: "Análisis clínicos bioquímicos, hemogramas y sedimentos",
    duracion_min: 45,
    precio: 60.0,
    icono: "flask",
    categoria: "general" as const,
  },
  {
    id: 4,
    nombre: "Vacunación & Desparasitación",
    descripcion: "Aplicación de vacunas quíntuple, séxtuple y antirrábica oficial",
    duracion_min: 20,
    precio: 18.0,
    icono: "syringe",
    categoria: "general" as const,
  },
  // Servicios Especializados de Alta Complejidad e Interconsultas
  {
    id: 5,
    nombre: "Cardiografía & Ecocardiograma Doppler",
    descripcion: "Estudio cardiológico completo, ECG de 12 derivaciones y Doppler color. Sujeto a derivación e interconsulta especializada.",
    duracion_min: 45,
    precio: 85.0,
    icono: "heart-pulse",
    categoria: "especializado" as const,
    especialidad: "Cardiología",
    estudio_sugerido: "Cardiografía / Ecocardiograma Doppler Color + Electrocardiograma de 12 derivaciones",
    derivacion_habilitada: true,
  },
  {
    id: 6,
    nombre: "Radiología Digital de Alta Frecuencia",
    descripcion: "Placas radiológicas HD contrastadas con informe médico oficial y visor negatoscopio digital.",
    duracion_min: 40,
    precio: 70.0,
    icono: "scan",
    categoria: "especializado" as const,
    especialidad: "Radiología / Diagnóstico por Imágenes",
    estudio_sugerido: "Radiografía Digital de Tórax / Columna / Miembros en Alta Resolución",
    derivacion_habilitada: true,
  },
  {
    id: 7,
    nombre: "Ecografía Doppler Abdominal & Vascular",
    descripcion: "Evaluación ecográfica especializada de parénquima de órganos internos y flujos hemodinámicos.",
    duracion_min: 40,
    precio: 75.0,
    icono: "activity",
    categoria: "especializado" as const,
    especialidad: "Ecografía Doppler",
    estudio_sugerido: "Ecografía Abdominal Completa con Mapeo Doppler Vascular",
    derivacion_habilitada: true,
  },
  {
    id: 8,
    nombre: "Traumatología & Ortopedia Quirúrgica",
    descripcion: "Interconsulta ortopédica, análisis dinámico de marcha, articulaciones y lesiones ligamentarias.",
    duracion_min: 50,
    precio: 90.0,
    icono: "bone",
    categoria: "especializado" as const,
    especialidad: "Traumatología Compleja",
    estudio_sugerido: "Evaluación traumatológica especializada con estudios radiológicos dinámicos",
    derivacion_habilitada: true,
  },
];

type TurnoEstado = 'pendiente' | 'confirmado' | 'cancelado' | 'completado';

interface TurnoItem {
  id: number;
  mascota_id: number;
  servicio_id: number;
  veterinario_id: number;
  fecha: string;
  hora: string;
  estado: TurnoEstado;
  notas: string;
  creado_en: string;
  es_especializado?: boolean;
  categoria_servicio?: 'general' | 'especializado';
  especialidad?: string;
  estudio_solicitado?: string;
  sintomas_observados?: string;
  tiene_estudios_previos?: boolean;
  derivado?: boolean;
  derivacion_id?: number;
  derivacion_codigo?: string;
}

let turnos: TurnoItem[] = [
  {
    id: 1,
    mascota_id: 1,
    servicio_id: 1,
    veterinario_id: 1,
    fecha: "2026-08-15",
    hora: "10:00",
    estado: "confirmado",
    notas: "Consulta de rutina preventiva.",
    creado_en: "2026-08-01 12:00:00",
    es_especializado: false,
    categoria_servicio: "general",
    derivado: false,
  },
  {
    id: 2,
    mascota_id: 1,
    servicio_id: 4,
    veterinario_id: 2,
    fecha: "2026-08-20",
    hora: "11:30",
    estado: "confirmado",
    notas: "Refuerzo anual.",
    creado_en: "2026-08-05 14:30:00",
    es_especializado: false,
    categoria_servicio: "general",
    derivado: false,
  },
  {
    id: 3,
    mascota_id: 1,
    servicio_id: 5,
    veterinario_id: 1,
    fecha: "2026-09-18",
    hora: "10:30",
    estado: "confirmado",
    notas: "Sospecha de soplo sistólico, fatiga tras ejercicio ligero.",
    creado_en: "2026-09-02 11:00:00",
    es_especializado: true,
    categoria_servicio: "especializado",
    especialidad: "Cardiología",
    estudio_solicitado: "Cardiografía / Ecocardiograma Doppler Color + ECG",
    sintomas_observados: "Tos nocturna intermitente, jadeo excesivo en reposo.",
    tiene_estudios_previos: false,
    derivado: false,
  },
];

let consultas = [
  {
    id: 1,
    mascota_id: 1,
    veterinario_id: 1,
    fecha: "2024-05-15",
    tipo: "CONTROL" as const,
    titulo: "Control Anual Preventivo",
    descripcion:
      "Paciente presenta excelente condición física. Se realizó examen físico completo, limpieza dental superficial y actualización de peso.",
    creado_en: "2024-05-15 11:00:00",
  },
  {
    id: 2,
    mascota_id: 1,
    veterinario_id: 2,
    fecha: "2024-03-02",
    tipo: "EMERGENCIA" as const,
    titulo: "Urgencia: Dermatitis Aguda",
    descripcion:
      "Reacción alérgica en zona abdominal. Se administró antihistamínico vía oral y se recetó pomada calmante por 7 días.",
    creado_en: "2024-03-02 16:20:00",
  },
  {
    id: 3,
    mascota_id: 1,
    veterinario_id: 1,
    fecha: "2023-11-20",
    tipo: "VACUNA" as const,
    titulo: "Vacunación Cuádruple",
    descripcion:
      "Aplicación de refuerzo anual sin complicaciones posteriores.",
    creado_en: "2023-11-20 10:15:00",
  },
];

let vacunas = [
  {
    id: 1,
    mascota_id: 1,
    nombre: "Antirrábica",
    fecha_aplicacion: "2025-05-15",
    fecha_refuerzo: "2026-05-15",
    estado: "AL_DIA" as const,
  },
  {
    id: 2,
    mascota_id: 1,
    nombre: "DHPP (Quíntuple)",
    fecha_aplicacion: "2025-11-20",
    fecha_refuerzo: "2026-11-20",
    estado: "AL_DIA" as const,
  },
  {
    id: 3,
    mascota_id: 1,
    nombre: "Giardia",
    fecha_aplicacion: "2023-04-10",
    fecha_refuerzo: "2024-04-10",
    estado: "VENCIDA" as const,
  },
];

let nextEstudioId = 5;
let estudios = [
  {
    id: 1,
    mascota_id: 1,
    nombre: "Radiografía Digital Torácica (VD y Lat)",
    tipo: "Radiografía",
    fecha: "2026-08-15",
    zona_anatomica: "Tórax Frente y Perfil",
    imagen_url: "https://images.unsplash.com/photo-1516549655169-df83a0774514?w=900&q=80",
    observaciones: "Evaluación cardiotorácica. Silueta cardíaca dentro de límites normales (Índice vertebral de Buchanan 9.5v). Parénquima pulmonar sin infiltrados alveolares ni efusión pleural.",
    veterinario_id: 1,
    veterinario_nombre: "Dr. Santiago Méndez (MP 14.280)",
    institucion: "VetAnimal - Servicio de Radiología Digital",
    resultado_url: "#",
  },
  {
    id: 2,
    mascota_id: 1,
    nombre: "Radiografía de Cadera & Pelvis (VD)",
    tipo: "Radiografía",
    fecha: "2026-06-10",
    zona_anatomica: "Pelvis Ventrodorsal con Miembros Extendidos",
    imagen_url: "https://images.unsplash.com/photo-1576086213369-97a306d36557?w=900&q=80",
    observaciones: "Estudio de articulaciones coxofemorales. Buena profundidad acetabular bilateral, sin remodelación ósea degenerativa ni osteofitos periacetabulares activos.",
    veterinario_id: 2,
    veterinario_nombre: "Dra. Martina Paz (MP 17.519)",
    institucion: "VetAnimal - Servicio de Radiología Digital",
    resultado_url: "#",
  },
  {
    id: 3,
    mascota_id: 1,
    nombre: "Ecocardiograma Doppler Color",
    tipo: "Cardiología / ECG",
    fecha: "2026-05-02",
    zona_anatomica: "Región Cardíaca",
    imagen_url: "https://images.unsplash.com/photo-1579154204601-01588f351e67?w=900&q=80",
    observaciones: "Interconsulta externa especializada. Flujo transvalvular laminar, ritmo regular sin ectopias. Fracción de acortamiento ventricular 35% (normofuncional).",
    veterinario_id: 1,
    veterinario_nombre: "Dra. Silvina Morales (MP 8.940)",
    institucion: "Centro Veterinario Tortuguitas (Cura Brochero 1420)",
    resultado_url: "#",
  },
  {
    id: 4,
    mascota_id: 1,
    nombre: "Hemograma y Bioquímica Completa",
    tipo: "Laboratorio",
    fecha: "2026-07-20",
    zona_anatomica: "Muestra Sanguínea",
    imagen_url: "",
    observaciones: "Recuento leucocitario normal. Función renal y hepática en valores basales normales. Apto para intervenciones programadas.",
    veterinario_id: 1,
    veterinario_nombre: "Dr. Santiago Méndez (MP 14.280)",
    institucion: "VetAnimal - Laboratorio Central",
    resultado_url: "#",
  },
];

let centrosDerivacion = [
  {
    id: "tortuguitas-brochero",
    nombre: "Centro Veterinario & Diagnóstico Tortuguitas",
    direccion: "Calle Cura Brochero 1420 (e/ Moreno y Las Araucarias)",
    localidad: "Tortuguitas, Gran Buenos Aires",
    telefono: "(02320) 49-2210",
    whatsapp: "+54 9 11 5566-7788",
    horarios: "Lunes a Sábados 08:30 a 20:00 hs (Guardia de emergencias 24 hs)",
    especialidades: [
      "Cardiología Veterinaria & Electrocardiografía",
      "Ecocardiograma Doppler Color",
      "Radiología Digital de Alta Frecuencia",
      "Cirugía de Alta Complejidad",
    ],
    equipamiento: [
      "Ecocardiograma Doppler Color Mindray Z60",
      "Equipo de Rayos X Digital Sedecal 500mA",
      "Monitor Multiparamétrico y Electrocardiógrafo Bistos",
      "Quirófano Especializado con Anestesia Inhalatoria",
    ],
    medico_responsable: "Dra. Silvina Morales (Cardióloga e Imagenóloga Veterinaria, MP 8.940)",
    distancia_estimada: "12 minutos desde VetAnimal Del Viso",
    acepta_urgencias: true,
  },
  {
    id: "hospital-pilar",
    nombre: "Hospital Veterinario de Alta Complejidad Pilar",
    direccion: "Colectora Panamericana Ramal Pilar Km 50.5",
    localidad: "Pilar, Gran Buenos Aires",
    telefono: "(0230) 464-5500",
    whatsapp: "+54 9 11 3322-1100",
    horarios: "Atención Continua 24 Horas / 365 días",
    especialidades: [
      "Tomografía Computada Multicorte (TAC)",
      "Traumatología y Ortopedia Compleja",
      "Unidad de Terapia Intensiva (UTI)",
      "Cirugía Neurológica",
    ],
    equipamiento: [
      "Tomógrafo Multicorte Siemens Somatom",
      "Quirófano Traumatológico con Arco en C Radioscópico",
      "Laboratorio de Gases y Electrolitos en Sangre",
    ],
    medico_responsable: "Dr. Gustavo Albarracín (Director Quirúrgico, MP 11.204)",
    distancia_estimada: "15 minutos desde VetAnimal Del Viso",
    acepta_urgencias: true,
  },
  {
    id: "diagnostico-delviso",
    nombre: "Laboratorio y Centro Integral Del Viso",
    direccion: "Av. Madero (Ruta 26) 1280",
    localidad: "Del Viso, Gran Buenos Aires",
    telefono: "(02320) 47-1122",
    whatsapp: "+54 9 11 4455-9988",
    horarios: "Lunes a Viernes 08:00 a 19:00 hs · Sábados 08:30 a 14:00 hs",
    especialidades: [
      "Bioquímica Clínica Completa",
      "Citología y Anatomía Patológica",
      "Perfiles Hormonales e Inmunodiagnóstico",
    ],
    equipamiento: [
      "Analizador Automático de Química Clínica",
      "Contador Hematológico Láser Veterinario",
    ],
    medico_responsable: "Dra. Romina Carballo (Bioquímica Veterinaria, MP 6.312)",
    distancia_estimada: "5 minutos (Centro Del Viso)",
    acepta_urgencias: false,
  },
];

let nextDerivacionId = 3;
let derivaciones = [
  {
    id: 1,
    codigo: "ORD-2026-TORT-0081",
    mascota_id: 1,
    mascota_nombre: "Rocky",
    especie: "Perro",
    raza: "Golden Retriever",
    edad: 4,
    peso: 28.5,
    dueno_nombre: "Agustina Gómez",
    dueno_telefono: "11-5555-2222",
    dueno_email: "agustina.gomez@example.com",
    veterinario_emisor_id: 1,
    veterinario_emisor_nombre: "Dr. Santiago Méndez",
    veterinario_matricula: "MP 14.280",
    clinica_origen: "VetAnimal - Sede Del Viso / Pilar",
    centro_destino: centrosDerivacion[0],
    especialidad_derivada: "Cardiología" as const,
    estudio_solicitado: "Cardiografía / Ecocardiograma Doppler Color + Electrocardiograma",
    motivo_derivacion: "Falta de especialista cardiólogo en sede" as const,
    sospecha_diagnostica: "Soplo sistólico grado III/VI en foco mitral en auscultación periódica. Se solicita valoración cardiológica para evaluar regurgitación mitral y descartar cardiopatía estructural antes de programar cirugía.",
    resumen_clinico: "Canino normotenso, activo, sin episodios sincopales ni disnea en reposo. No recibe inotrópicos ni IECA actualmente.",
    indicaciones_previas: "Ayuno de 6 horas de sólidos. Presentar esta orden oficial emitida por VetAnimal en recepción del Centro Veterinario Tortuguitas en Calle Cura Brochero 1420.",
    fecha_emision: "2026-08-20",
    fecha_validez_hasta: "2026-09-20",
    estado: "activa" as const,
    creado_en: "2026-08-20 11:30:00",
  },
  {
    id: 2,
    codigo: "ORD-2026-TORT-0082",
    mascota_id: 1,
    mascota_nombre: "Rocky",
    especie: "Perro",
    raza: "Golden Retriever",
    edad: 4,
    peso: 28.5,
    dueno_nombre: "Agustina Gómez",
    dueno_telefono: "11-5555-2222",
    dueno_email: "agustina.gomez@example.com",
    veterinario_emisor_id: 2,
    veterinario_emisor_nombre: "Dra. Martina Paz",
    veterinario_matricula: "MP 17.519",
    clinica_origen: "VetAnimal - Sede Del Viso / Pilar",
    centro_destino: centrosDerivacion[0],
    especialidad_derivada: "Radiología / Diagnóstico por Imágenes" as const,
    estudio_solicitado: "Radiografía Digital de Columna Lumbo-Sacra y Pelvis (VD y Lateral)",
    motivo_derivacion: "Saturación de turnos / derivación prioritaria" as const,
    sospecha_diagnostica: "Claudicación en miembro posterior derecho posterior a esfuerzo físico. Descartar espondilosis o displasia coxofemoral.",
    resumen_clinico: "Molestia leve a la extensión pasiva de articulación de cadera derecha. Reflejos espinales normales.",
    indicaciones_previas: "Ayuno de 8 horas de sólidos ante eventual sedación para posicionamiento radiológico de precisión.",
    fecha_emision: "2026-08-28",
    fecha_validez_hasta: "2026-09-28",
    estado: "activa" as const,
    creado_en: "2026-08-28 16:45:00",
  },
];

let products = [
  {
    id: 1,
    nombre: "Royal Canin Mini Adult (Bolsa 7.5 kg)",
    categoria: "Nutrición y Alimento" as const,
    etiqueta: "PREMIUM",
    descripcion:
      "Alimento completo y balanceado para perros adultos de razas pequeñas. Enriquecido con EPA/DHA.",
    precio: 48.5,
    requiere_receta: false,
    stock: 35,
    imagen: "https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=400&q=80",
  },
  {
    id: 2,
    nombre: "Champú Medicado Clorhexidina & Ketoconazol (250 ml)",
    categoria: "Bienestar y Estética" as const,
    etiqueta: "DERMATOLOGÍA",
    descripcion:
      "Champú antiséptico y antifúngico para el tratamiento de dermatitis bacterianas y fúngicas en caninos y felinos.",
    precio: 19.8,
    requiere_receta: false,
    stock: 50,
    imagen: "https://images.unsplash.com/photo-1583947581924-860bda6a26df?w=400&q=80",
  },
  {
    id: 3,
    nombre: "Champú Hipoalergénico de Avena & Aloe Vera (500 ml)",
    categoria: "Bienestar y Estética" as const,
    etiqueta: "PIEL SENSIBLE",
    descripcion:
      "Fórmula ultra suave con pH neutro. Hidrata y calma la piel con prurito sin irritar los ojos.",
    precio: 15.5,
    requiere_receta: false,
    stock: 45,
    imagen: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400&q=80",
  },
  {
    id: 4,
    nombre: "Pro Plan Puppy Cachorro OptiStart (Bolsa 15 kg)",
    categoria: "Nutrición y Alimento" as const,
    etiqueta: "CACHORROS",
    descripcion:
      "Nutrición avanzada con calostro materno para fortalecer el sistema inmunológico y el desarrollo óseo.",
    precio: 82.0,
    requiere_receta: false,
    stock: 20,
    imagen: "https://images.unsplash.com/photo-1568640347023-a616a30bc3bd?w=400&q=80",
  },
  {
    id: 5,
    nombre: "Hills Prescription Diet Metabolic Gatos (Bolsa 3 kg)",
    categoria: "Nutrición y Alimento" as const,
    etiqueta: "RECETADO",
    descripcion:
      "Alimento clínico especializado para el control de peso y soporte articular en felinos.",
    precio: 44.0,
    requiere_receta: true,
    stock: 18,
    imagen: "https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=400&q=80",
  },
  {
    id: 6,
    nombre: "Bravecto Comprimido Masticable (10 a 20 kg)",
    categoria: "Pulgas y Garrapatas" as const,
    etiqueta: "PROTECCIÓN 12 SEMANAS",
    descripcion:
      "Tratamiento y prevención sistémica de infestaciones por pulgas y garrapatas durante 3 meses completos.",
    precio: 36.9,
    requiere_receta: false,
    stock: 60,
    imagen: "https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400&q=80",
  },
  {
    id: 7,
    nombre: "NexGard Spectra Antiparasitario Completo (3.5 a 7.5 kg)",
    categoria: "Pulgas y Garrapatas" as const,
    etiqueta: "PROTECCIÓN TOTAL",
    descripcion:
      "Tableta masticable sabor carne. Protege contra pulgas, garrapatas, sarna y parásitos intestinales.",
    precio: 31.5,
    requiere_receta: false,
    stock: 40,
    imagen: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400&q=80",
  },
  {
    id: 8,
    nombre: "Condroprotector Articular con Colágeno & Glucosamina (90 comp.)",
    categoria: "Medicamentos" as const,
    etiqueta: "SUPLEMENTO",
    descripcion:
      "Fórmula articular para perros mayores o con displasia de cadera. Estimula la regeneración del cartílago.",
    precio: 29.9,
    requiere_receta: false,
    stock: 30,
    imagen: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=400&q=80",
  },
];

let orders: any[] = [];
let nextUserId = 6;
let nextPetId = 7;
let nextTurnoId = 5;
let nextConsultaId = 8;
let nextOrderId = 1001;
let nextProductId = 9;

// ==========================================
// PERSISTENT STORAGE ENGINE (JSON DB)
// ==========================================
const DB_PATH = path.join(process.cwd(), "data_storage.json");

function saveDatabase() {
  try {
    const data = {
      users,
      pets,
      turnos,
      consultas,
      vacunas,
      estudios,
      centrosDerivacion,
      derivaciones,
      products,
      orders,
      nextUserId,
      nextPetId,
      nextTurnoId,
      nextConsultaId,
      nextDerivacionId,
      nextEstudioId,
      nextOrderId,
      nextProductId,
    };
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("[DB PERSISTENCE] Error saving database:", err);
  }
}

function loadDatabase() {
  try {
    if (fs.existsSync(DB_PATH)) {
      const content = fs.readFileSync(DB_PATH, "utf-8");
      const data = JSON.parse(content);
      if (Array.isArray(data.users) && data.users.length > 0) users = data.users;
      if (Array.isArray(data.pets) && data.pets.length > 0) {
        pets = data.pets;
      }
      if (Array.isArray(data.turnos)) turnos = data.turnos;
      if (Array.isArray(data.consultas)) consultas = data.consultas;
      if (Array.isArray(data.vacunas)) vacunas = data.vacunas;
      if (Array.isArray(data.estudios)) estudios = data.estudios;
      if (Array.isArray(data.derivaciones)) derivaciones = data.derivaciones;
      if (Array.isArray(data.products)) products = data.products;
      if (Array.isArray(data.orders)) orders = data.orders;
      if (data.nextUserId) nextUserId = data.nextUserId;
      if (data.nextPetId) nextPetId = data.nextPetId;
      if (data.nextTurnoId) nextTurnoId = data.nextTurnoId;
      if (data.nextConsultaId) nextConsultaId = data.nextConsultaId;
      if (data.nextDerivacionId) nextDerivacionId = data.nextDerivacionId;
      if (data.nextEstudioId) nextEstudioId = data.nextEstudioId;
      return;
    }
  } catch (err) {
    console.error("[DB PERSISTENCE] Error loading database:", err);
  }
  // Initialize with seed data if file doesn't exist
  saveDatabase();
}

// Cargar base de datos al inicio
loadDatabase();

// ==========================================
// API ROUTES
// ==========================================

// --- AUTH ---
app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  const user = users.find(
    (u) => u.email.toLowerCase() === (email || "").toLowerCase()
  );
  if (!user || user.password !== password) {
    return res.status(401).json({ error: "Email o contraseña incorrectos." });
  }
  const { password: _, ...userWithoutPass } = user;
  res.json({ user: userWithoutPass });
});

app.post("/api/auth/register", (req, res) => {
  const { nombre, email, password, telefono } = req.body;
  if (!nombre || !email || !password) {
    return res
      .status(400)
      .json({ error: "Completá todos los campos obligatorios." });
  }
  if (users.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
    return res
      .status(400)
      .json({ error: "Ya existe una cuenta registrada con ese email." });
  }
  const newUser = {
    id: nextUserId++,
    nombre,
    email,
    password,
    rol: "cliente" as const,
    telefono: telefono || "",
    especialidad: null,
    foto: undefined,
  };
  users.push(newUser);
  saveDatabase();
  const { password: _, ...userWithoutPass } = newUser;
  res.json({ user: userWithoutPass });
});

app.post("/api/auth/forgot-password", (req, res) => {
  res.json({
    message:
      "Si el correo existe en nuestro sistema, te enviamos un enlace de recuperación.",
  });
});

// --- PETS ---
app.get("/api/pets", (req, res) => {
  const userId = req.query.userId ? Number(req.query.userId) : null;
  const all = req.query.all === "true";

  if (all || !userId) {
    const petsWithOwners = pets.map((p) => {
      const owner = users.find((u) => u.id === p.usuario_id);
      return {
        ...p,
        dueno: owner ? owner.nombre : "Desconocido",
        telefono: owner ? owner.telefono : "",
      };
    });
    return res.json(petsWithOwners);
  }

  const userPets = pets.filter((p) => p.usuario_id === userId);
  res.json(userPets);
});

app.get("/api/pets/:id", (req, res) => {
  const petId = Number(req.params.id);
  const pet = pets.find((p) => p.id === petId);
  if (!pet) return res.status(404).json({ error: "Mascota no encontrada" });

  const owner = users.find((u) => u.id === pet.usuario_id);
  res.json({
    ...pet,
    dueno: owner ? owner.nombre : "Desconocido",
    telefono: owner ? owner.telefono : "",
  });
});

app.post("/api/pets", (req, res) => {
  const { usuario_id, nombre, especie, raza, edad, peso, foto } = req.body;
  if (!nombre || !especie) {
    return res
      .status(400)
      .json({ error: "El nombre y la especie son obligatorios." });
  }

  let defaultFoto = "https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=500&q=80";
  if (especie === "Gato") {
    defaultFoto = "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=500&q=80";
  } else if (especie === "Ave") {
    defaultFoto = "https://images.unsplash.com/photo-1552728089-57bdde30beb3?w=500&q=80";
  } else if (especie === "Exótico") {
    defaultFoto = "https://images.unsplash.com/photo-1425082661705-1834bfd09dca?w=500&q=80";
  }

  const assignedOwnerId = Number(usuario_id) || 3;

  const newPet = {
    id: nextPetId++,
    usuario_id: assignedOwnerId,
    nombre,
    especie,
    raza: raza || "",
    edad: edad !== undefined && edad !== "" ? Number(edad) : undefined,
    peso: peso !== undefined && peso !== "" ? Number(peso) : undefined,
    foto: foto || defaultFoto,
    estado_salud: "Estable",
    alergias: "",
    condiciones_cronicas: "Ninguna diagnosticada a la fecha.",
    creado_en: new Date().toISOString().replace("T", " ").substring(0, 19),
  };
  pets.push(newPet);

  // Apertura de historia clínica inmediata para el animal
  consultas.unshift({
    id: nextConsultaId++,
    mascota_id: newPet.id,
    veterinario_id: 1,
    fecha: new Date().toISOString().split("T")[0],
    tipo: "CONTROL" as const,
    titulo: `Alta de Paciente: ${newPet.nombre}`,
    descripcion: `Apertura oficial de expediente digital para ${newPet.nombre}. Especie: ${newPet.especie}. Raza: ${newPet.raza || "Mestiza"}. Peso inicial: ${newPet.peso ? newPet.peso + " kg" : "A registrar"}. Estado clínico general óptimo.`,
    creado_en: new Date().toISOString().replace("T", " ").substring(0, 19),
  });

  saveDatabase();

  const owner = users.find((u) => u.id === newPet.usuario_id);
  res.json({
    ...newPet,
    dueno: owner ? owner.nombre : "Cliente",
    telefono: owner ? owner.telefono : "",
  });
});

app.put("/api/pets/:id", (req, res) => {
  const petId = Number(req.params.id);
  const index = pets.findIndex((p) => p.id === petId);
  if (index === -1) {
    return res.status(404).json({ error: "Mascota no encontrada." });
  }

  const { nombre, especie, raza, edad, peso, foto, alergias, condiciones_cronicas, estado_salud } = req.body;

  if (nombre) pets[index].nombre = nombre;
  if (especie) pets[index].especie = especie;
  if (raza !== undefined) pets[index].raza = raza;
  if (edad !== undefined) pets[index].edad = edad !== "" ? Number(edad) : undefined;
  if (peso !== undefined) pets[index].peso = peso !== "" ? Number(peso) : undefined;
  if (foto !== undefined) pets[index].foto = foto;
  if (alergias !== undefined) pets[index].alergias = alergias;
  if (condiciones_cronicas !== undefined) pets[index].condiciones_cronicas = condiciones_cronicas;
  if (estado_salud !== undefined) pets[index].estado_salud = estado_salud;

  saveDatabase();

  res.json(pets[index]);
});

app.delete("/api/pets/:id", (req, res) => {
  const petId = Number(req.params.id);
  const index = pets.findIndex((p) => p.id === petId);
  if (index === -1) {
    return res.status(404).json({ error: "Mascota no encontrada." });
  }
  pets.splice(index, 1);
  saveDatabase();
  res.json({ message: "Mascota eliminada correctamente." });
});

// --- SERVICES ---
app.get("/api/services", (req, res) => {
  res.json(services);
});

// --- TURNOS ---
app.get("/api/turnos", (req, res) => {
  const userId = req.query.userId ? Number(req.query.userId) : null;
  const fechaFilter = req.query.fecha ? String(req.query.fecha) : null;
  const all = req.query.all === "true";

  let list = turnos;

  if (userId && !all) {
    const userPetIds = pets.filter((p) => p.usuario_id === userId).map((p) => p.id);
    list = list.filter((t) => userPetIds.includes(t.mascota_id));
  }

  if (fechaFilter) {
    list = list.filter((t) => t.fecha === fechaFilter);
  }

  const result = list.map((t) => {
    const pet = pets.find((p) => p.id === t.mascota_id);
    const service = services.find((s) => s.id === t.servicio_id);
    const vet = users.find((u) => u.id === t.veterinario_id);
    const owner = pet ? users.find((u) => u.id === pet.usuario_id) : null;

    return {
      ...t,
      mascota_nombre: pet ? pet.nombre : "Mascota",
      servicio_nombre: service ? service.nombre : "Servicio",
      veterinario_nombre: vet ? vet.nombre : "Asignado en clínica",
      dueno: owner ? owner.nombre : "Cliente",
      dueno_email: owner ? owner.email : "",
    };
  });

  result.sort(
    (a, b) =>
      new Date(`${b.fecha} ${b.hora}`).getTime() -
      new Date(`${a.fecha} ${a.hora}`).getTime()
  );

  res.json(result);
});

app.get("/api/turnos/booked-dates", (req, res) => {
  const mesParam = req.query.mes ? String(req.query.mes) : new Date().toISOString().substring(0, 7);
  const activeTurnos = turnos.filter(
    (t) => t.fecha.startsWith(mesParam) && t.estado !== "cancelado"
  );
  const days = Array.from(
    new Set(activeTurnos.map((t) => parseInt(t.fecha.split("-")[2], 10)))
  );
  res.json(days);
});

app.get("/api/turnos/occupied-times", (req, res) => {
  const fecha = req.query.fecha ? String(req.query.fecha) : "";
  if (!fecha) return res.json([]);
  const activeTurnos = turnos.filter(
    (t) => t.fecha === fecha && t.estado !== "cancelado"
  );
  res.json(activeTurnos.map((t) => t.hora));
});

app.post("/api/turnos", async (req, res) => {
  const {
    mascota_id,
    servicio_id,
    fecha,
    hora,
    notas,
    sintomas_observados,
    tiene_estudios_previos,
  } = req.body;

  if (!mascota_id || !servicio_id || !fecha || !hora) {
    return res
      .status(400)
      .json({ error: "Completá todos los datos para la reserva." });
  }

  const sId = Number(servicio_id);
  const service = services.find((s) => s.id === sId);
  const isSurgery = sId === 2;
  const isSpecialized = sId >= 5 || service?.categoria === "especializado";

  // Check collision
  const existing = turnos.find(
    (t) => t.fecha === fecha && t.hora === hora && t.estado !== "cancelado"
  );
  if (existing) {
    return res.status(400).json({
      error:
        "Ese horario ya fue reservado por otra persona. Elegí otro horario.",
    });
  }

  const vets = users.filter((u) => u.rol === "veterinario");
  const randomVet = vets.length > 0 ? vets[Math.floor(Math.random() * vets.length)].id : 1;

  const newTurno: TurnoItem = {
    id: nextTurnoId++,
    mascota_id: Number(mascota_id),
    servicio_id: sId,
    veterinario_id: randomVet,
    fecha,
    hora,
    estado: "confirmado" as const,
    notas: notas || (isSurgery ? "Bloque Quirúrgico Extendido (90 min)." : (isSpecialized ? "Turno Especializado / Interconsulta diagnóstica." : "")),
    creado_en: new Date().toISOString().replace("T", " ").substring(0, 19),
    es_especializado: isSpecialized,
    categoria_servicio: isSpecialized ? "especializado" : "general",
    especialidad: service?.especialidad || (isSpecialized ? "Cardiología" : undefined),
    estudio_solicitado: service?.estudio_sugerido || service?.nombre,
    sintomas_observados: sintomas_observados || "",
    tiene_estudios_previos: Boolean(tiene_estudios_previos),
    derivado: false,
  };

  turnos.push(newTurno);
  saveDatabase();

  const pet = pets.find((p) => p.id === newTurno.mascota_id);
  const owner = pet ? users.find((u) => u.id === pet.usuario_id) : null;
  const vet = users.find((u) => u.id === newTurno.veterinario_id);

  // Despacho de correo electrónico real con copia a veterinariavet101@gmail.com
  const clientEmail = owner?.email || "veterinariavet101@gmail.com";
  const turnoHtml = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #1e293b; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden;">
      <div style="background-color: #1e3a8a; color: white; padding: 24px; text-align: center;">
        <h2 style="margin: 0; font-size: 20px;">CONFIRMACIÓN DE TURNO VETERINARIO</h2>
        <p style="margin: 4px 0 0; font-size: 13px; opacity: 0.9;">VetAnimal &bull; Cita Médica ${isSpecialized ? 'Especializada' : 'Confirmada'}</p>
      </div>
      <div style="padding: 24px;">
        <p>Hola <strong>${owner ? owner.nombre : 'Estimado/a Cliente'}</strong>,</p>
        <p>Te confirmamos que el turno para <strong>${pet ? pet.nombre : 'tu mascota'}</strong> ha sido programado con éxito.</p>
        
        <div style="background-color: #f8fafc; border-left: 4px solid #2563eb; padding: 16px; margin: 16px 0; border-radius: 6px;">
          <p style="margin: 0 0 6px;"><strong>Servicio:</strong> ${service?.nombre} ${isSpecialized ? '⭐ [ESTUDIO ESPECIALIZADO]' : ''}</p>
          <p style="margin: 0 0 6px;"><strong>Fecha:</strong> ${fecha}</p>
          <p style="margin: 0 0 6px;"><strong>Hora:</strong> ${hora} hs ${isSurgery ? '(Bloque Quirúrgico de 90 min)' : ''}</p>
          <p style="margin: 0 0 6px;"><strong>Veterinario asignado:</strong> ${vet ? vet.nombre : 'Equipo Veterinario VetAnimal'}</p>
          ${isSpecialized ? `
            <div style="margin-top: 10px; padding: 10px; background-color: #eff6ff; border: 1px solid #bfdbfe; border-radius: 6px; font-size: 13px; color: #1e40af;">
              <strong>ℹ️ PROTOCOLO DE INTERCONSULTA Y ALTA COMPLEJIDAD:</strong>
              <p style="margin: 4px 0 0;">Este turno corresponde a una prestación médica especializada. En caso de requerir equipamiento específico o si el especialista no estuviese disponible en sede central, el médico veterinario emitirá una Orden Oficial de Derivación prioritaria a nuestra red clínica (Centro Tortuguitas).</p>
              ${sintomas_observados ? `<p style="margin: 4px 0 0;"><strong>Síntomas registrados:</strong> ${sintomas_observados}</p>` : ''}
            </div>
          ` : ''}
          ${isSurgery ? `
            <div style="margin-top: 10px; padding: 10px; background-color: #fef3c7; border: 1px solid #fde68a; border-radius: 6px; font-size: 13px; color: #92400e;">
              <strong>⚠️ PROTOCOLO PRE-QUIRÚRGICO OBLIGATORIO:</strong>
              <ul style="margin: 6px 0 0; padding-left: 20px;">
                <li>Ayuno estricto de sólidos de 12 horas previas a la cirugía.</li>
                <li>Ayuno de líquidos (agua) de 6 horas previas.</li>
                <li>Presentarse con análisis prequirúrgicos (sangre y valoración cardiológica).</li>
              </ul>
            </div>
          ` : ''}
        </div>

        <p style="font-size: 13px; color: #64748b;">
          Cualquier duda o reprogramación, podés comunicarte a nuestra central telefónica al (011) 4000-1000 o responder a veterinariavet101@gmail.com.
        </p>
      </div>
      <div style="background-color: #f1f5f9; padding: 12px 24px; font-size: 11px; color: #64748b; text-align: center;">
        VetAnimal &bull; Sede Central &bull; veterinariavet101@gmail.com
      </div>
    </div>
  `;

  sendRealEmail({
    to: clientEmail,
    subject: `📅 Turno Confirmado: ${pet ? pet.nombre : 'Mascota'} - ${service?.nombre} (${fecha} ${hora} hs)`,
    html: turnoHtml,
    bcc: "veterinariavet101@gmail.com",
  }).catch(() => {});

  res.json({
    ...newTurno,
    mascota_nombre: pet ? pet.nombre : "Mascota",
    servicio_nombre: service ? service.nombre : "Servicio",
  });
});

app.patch("/api/turnos/:id/estado", (req, res) => {
  const turnoId = Number(req.params.id);
  const { estado } = req.body;
  const turno = turnos.find((t) => t.id === turnoId);
  if (!turno) return res.status(404).json({ error: "Turno no encontrado" });

  // Regla de negocio: Si el turno está cancelado, no se puede pasar a completado directamente
  if (turno.estado === "cancelado" && estado === "completado") {
    return res
      .status(400)
      .json({ error: "No podés marcar como Atendido un turno que ya fue cancelado." });
  }

  if (["pendiente", "confirmado", "cancelado", "completado"].includes(estado)) {
    turno.estado = estado;
    saveDatabase();
  }
  res.json(turno);
});

// --- CLINICAL HISTORY (CONSULTAS, VACUNAS, ESTUDIOS) ---
app.get("/api/consultas", (req, res) => {
  const petId = Number(req.query.mascota_id);
  if (!petId) return res.json([]);

  const list = consultas
    .filter((c) => c.mascota_id === petId)
    .map((c) => {
      const vet = users.find((u) => u.id === c.veterinario_id);
      return {
        ...c,
        vet_nombre: vet ? vet.nombre : "Dr. Veterinaria VetAnimal",
      };
    })
    .sort(
      (a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime()
    );

  res.json(list);
});

app.post("/api/consultas", (req, res) => {
  const { mascota_id, veterinario_id, fecha, tipo, titulo, descripcion } = req.body;
  if (!mascota_id || !titulo || !descripcion) {
    return res.status(400).json({ error: "Completá el título y la descripción." });
  }

  const newConsulta = {
    id: nextConsultaId++,
    mascota_id: Number(mascota_id),
    veterinario_id: veterinario_id ? Number(veterinario_id) : 1,
    fecha: fecha || new Date().toISOString().substring(0, 10),
    tipo: tipo || "CONTROL",
    titulo,
    descripcion,
    creado_en: new Date().toISOString().replace("T", " ").substring(0, 19),
  };

  consultas.push(newConsulta);
  saveDatabase();
  const vet = users.find((u) => u.id === newConsulta.veterinario_id);
  res.json({
    ...newConsulta,
    vet_nombre: vet ? vet.nombre : "Dr. Veterinaria VetAnimal",
  });
});

app.get("/api/vacunas", (req, res) => {
  const petId = Number(req.query.mascota_id);
  if (!petId) return res.json([]);
  res.json(vacunas.filter((v) => v.mascota_id === petId));
});

app.get("/api/estudios", (req, res) => {
  const petId = Number(req.query.mascota_id);
  if (!petId) return res.json(estudios);
  res.json(estudios.filter((e) => e.mascota_id === petId));
});

app.post("/api/estudios", (req, res) => {
  const {
    mascota_id,
    nombre,
    tipo,
    fecha,
    zona_anatomica,
    imagen_url,
    observaciones,
    veterinario_id,
    institucion,
  } = req.body;

  if (!mascota_id || !nombre) {
    return res.status(400).json({ error: "Completá los campos obligatorios del estudio." });
  }

  const vet = users.find((u) => u.id === Number(veterinario_id)) || users[0];

  const newEstudio = {
    id: nextEstudioId++,
    mascota_id: Number(mascota_id),
    nombre: String(nombre).trim(),
    tipo: tipo || "Radiografía",
    fecha: fecha || new Date().toISOString().substring(0, 10),
    zona_anatomica: zona_anatomica || "Tórax / Silueta General",
    imagen_url: imagen_url || "https://images.unsplash.com/photo-1516549655169-df83a0774514?w=900&q=80",
    observaciones: observaciones || "Estudio radiológico archivado en legajo clínico digital.",
    veterinario_id: vet.id,
    veterinario_nombre: vet.nombre,
    institucion: institucion || "VetAnimal - Diagnóstico por Imágenes",
    resultado_url: "#",
  };

  estudios.unshift(newEstudio);
  saveDatabase();
  res.status(201).json(newEstudio);
});

// --- ÓRDENES DE DERIVACIÓN E INTERCONSULTA MÉDICA EXTERNA ---
app.get("/api/centros-derivacion", (req, res) => {
  res.json(centrosDerivacion);
});

app.get("/api/derivaciones", (req, res) => {
  const petId = req.query.mascota_id ? Number(req.query.mascota_id) : null;
  const userId = req.query.userId ? Number(req.query.userId) : null;

  let list = derivaciones;
  if (petId) {
    list = list.filter((d) => d.mascota_id === petId);
  } else if (userId) {
    const userPetIds = pets.filter((p) => p.usuario_id === userId).map((p) => p.id);
    list = list.filter((d) => userPetIds.includes(d.mascota_id));
  }

  const sorted = [...list].sort(
    (a, b) => new Date(b.creado_en).getTime() - new Date(a.creado_en).getTime()
  );
  res.json(sorted);
});

app.post("/api/derivaciones", async (req, res) => {
  const {
    mascota_id,
    veterinario_emisor_id,
    centro_destino_id,
    especialidad_derivada,
    estudio_solicitado,
    motivo_derivacion,
    sospecha_diagnostica,
    resumen_clinico,
    indicaciones_previas,
  } = req.body;

  if (!mascota_id || !especialidad_derivada || !estudio_solicitado || !sospecha_diagnostica) {
    return res.status(400).json({ error: "Completá los datos médicos obligatorios para emitir la orden." });
  }

  const pet = pets.find((p) => p.id === Number(mascota_id));
  if (!pet) return res.status(404).json({ error: "Mascota no encontrada." });

  const owner = users.find((u) => u.id === pet.usuario_id);
  const vet = users.find((u) => u.id === Number(veterinario_emisor_id)) || users[0];
  const centro = centrosDerivacion.find((c) => c.id === centro_destino_id) || centrosDerivacion[0];

  const codeNumber = Math.floor(1000 + Math.random() * 9000);
  const orderCode = `ORD-${new Date().getFullYear()}-TORT-${codeNumber}`;

  const hoy = new Date();
  const emisionStr = hoy.toISOString().substring(0, 10);
  const validez = new Date(hoy);
  validez.setDate(validez.getDate() + 30);
  const validezStr = validez.toISOString().substring(0, 10);

  const newDerivacion = {
    id: nextDerivacionId++,
    codigo: orderCode,
    mascota_id: pet.id,
    mascota_nombre: pet.nombre,
    especie: pet.especie,
    raza: pet.raza,
    edad: pet.edad,
    peso: pet.peso,
    dueno_nombre: owner ? owner.nombre : "Cliente",
    dueno_telefono: owner ? owner.telefono : "",
    dueno_email: owner ? owner.email : "",
    veterinario_emisor_id: vet.id,
    veterinario_emisor_nombre: vet.nombre,
    veterinario_matricula: vet.id === 1 ? "MP 14.280" : "MP 17.519",
    clinica_origen: "VetAnimal - Sede Del Viso / Pilar",
    centro_destino: centro,
    especialidad_derivada,
    estudio_solicitado,
    motivo_derivacion: motivo_derivacion || "Falta de especialista cardiólogo en sede",
    sospecha_diagnostica,
    resumen_clinico: resumen_clinico || "Paciente derivado para interconsulta médica y estudios diagnósticos de alta complejidad.",
    indicaciones_previas: indicaciones_previas || "Concurrir con esta orden médica oficial impresa o en el celular.",
    fecha_emision: emisionStr,
    fecha_validez_hasta: validezStr,
    estado: "activa" as const,
    creado_en: new Date().toISOString().replace("T", " ").substring(0, 19),
  };

  derivaciones.unshift(newDerivacion);
  saveDatabase();

  // Si la derivación proviene de un turno médico, asociar y marcar el turno como derivado
  const turnoIdNum = req.body.turno_id ? Number(req.body.turno_id) : undefined;
  if (turnoIdNum) {
    const turnoTarget = turnos.find((t) => t.id === turnoIdNum);
    if (turnoTarget) {
      turnoTarget.derivado = true;
      turnoTarget.derivacion_id = newDerivacion.id;
      turnoTarget.derivacion_codigo = orderCode;
    }
  }

  // Enviar copia por correo electrónico automático a veterinariavet101@gmail.com y al cliente si tiene email
  const emailSubject = `🩺 Orden Médica de Derivación #${orderCode} - ${pet.nombre} (${centro.nombre})`;
  const emailHtml = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #1e293b; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden;">
      <div style="background-color: #1e3a8a; color: white; padding: 24px; text-align: center;">
        <h2 style="margin: 0; font-size: 20px;">ORDEN MÉDICA DE DERIVACIÓN E INTERCONSULTA</h2>
        <p style="margin: 4px 0 0; font-size: 13px; opacity: 0.9;">VetAnimal (Sede Del Viso / Pilar) &bull; Código: <strong>${orderCode}</strong></p>
      </div>
      <div style="padding: 24px;">
        <p>Estimado/a <strong>${newDerivacion.dueno_nombre}</strong>,</p>
        <p>El equipo veterinario de VetAnimal ha emitido una <strong>Orden Oficial de Derivación Médica</strong> para tu mascota <strong>${pet.nombre}</strong>.</p>
        
        <div style="background-color: #f8fafc; border-left: 4px solid #2563eb; padding: 16px; margin: 16px 0; border-radius: 4px;">
          <p style="margin: 0 0 8px; font-weight: bold; color: #1e3a8a;">Centro Receptor de Atención:</p>
          <p style="margin: 0; font-size: 15px; font-weight: bold;">${centro.nombre}</p>
          <p style="margin: 4px 0 0; color: #475569; font-size: 13px;">📍 ${centro.direccion} (${centro.localidad})</p>
          <p style="margin: 4px 0 0; color: #475569; font-size: 13px;">📞 Tel: ${centro.telefono} &bull; WhatsApp: ${centro.whatsapp || '-'}</p>
          <p style="margin: 4px 0 0; color: #475569; font-size: 13px;">🕒 Horarios: ${centro.horarios}</p>
        </div>

        <table style="width: 100%; border-collapse: collapse; margin: 16px 0; font-size: 13px;">
          <tr>
            <td style="padding: 6px 0; color: #64748b;"><strong>Estudio Solicitado:</strong></td>
            <td style="padding: 6px 0; color: #0f172a; font-weight: bold;">${estudio_solicitado}</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #64748b;"><strong>Especialidad:</strong></td>
            <td style="padding: 6px 0; color: #0f172a;">${especialidad_derivada}</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #64748b;"><strong>Motivo de Derivación:</strong></td>
            <td style="padding: 6px 0; color: #0f172a;">${newDerivacion.motivo_derivacion}</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #64748b;"><strong>Sospecha Diagnóstica:</strong></td>
            <td style="padding: 6px 0; color: #0f172a;">${sospecha_diagnostica}</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #64748b;"><strong>Indicaciones Previas:</strong></td>
            <td style="padding: 6px 0; color: #b45309; font-weight: bold;">${newDerivacion.indicaciones_previas}</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #64748b;"><strong>Profesional Emisor:</strong></td>
            <td style="padding: 6px 0; color: #0f172a;">${vet.nombre} (${newDerivacion.veterinario_matricula})</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #64748b;"><strong>Validez:</strong></td>
            <td style="padding: 6px 0; color: #0f172a;">Hasta el ${validezStr}</td>
          </tr>
        </table>

        <p style="font-size: 12px; color: #64748b; margin-top: 20px;">
          Podés presentar esta orden médica impresa o mostrarla desde tu celular al llegar a ${centro.nombre}.
        </p>
      </div>
      <div style="background-color: #f1f5f9; padding: 12px 24px; font-size: 11px; color: #64748b; text-align: center;">
        VetAnimal &bull; Tel: (011) 4000-1000 &bull; Email: veterinariavet101@gmail.com
      </div>
    </div>
  `;

  const clientEmail = owner?.email || "veterinariavet101@gmail.com";
  sendRealEmail({
    to: clientEmail,
    subject: emailSubject,
    html: emailHtml,
    bcc: "veterinariavet101@gmail.com",
  }).catch(() => {});

  res.status(201).json(newDerivacion);
});

app.patch("/api/derivaciones/:id/estado", (req, res) => {
  const id = Number(req.params.id);
  const { estado } = req.body;
  const item = derivaciones.find((d) => d.id === id);
  if (!item) return res.status(404).json({ error: "Orden no encontrada." });
  if (["activa", "presentada", "completada", "vencida"].includes(estado)) {
    item.estado = estado;
    saveDatabase();
  }
  res.json(item);
});

app.get("/api/derivaciones/:id", (req, res) => {
  const idOrCode = req.params.id;
  const numId = Number(idOrCode);
  const item = derivaciones.find(
    (d) => (!isNaN(numId) && d.id === numId) || d.codigo === idOrCode
  );
  if (!item) return res.status(404).json({ error: "Orden no encontrada." });
  res.json(item);
});

// Endpoint directo de despacho de emails
app.post("/api/send-email", async (req, res) => {
  const { to, subject, html, text, bcc } = req.body;
  if (!to || !subject || (!html && !text)) {
    return res.status(400).json({ error: "Faltan parámetros de envío (to, subject, html/text)." });
  }

  const result = await sendRealEmail({
    to,
    subject,
    html: html || `<p>${text}</p>`,
    text,
    bcc: bcc || "veterinariavet101@gmail.com",
  });

  res.json(result);
});

// --- STORE & ORDERS ---
app.get("/api/products", (req, res) => {
  res.json(products);
});

app.post("/api/products", (req, res) => {
  const { nombre, categoria, etiqueta, descripcion, precio, imagen, requiere_receta, stock } = req.body;
  if (!nombre || precio === undefined || precio === null) {
    return res.status(400).json({ error: "El nombre y el precio son obligatorios." });
  }

  const newProduct = {
    id: nextProductId++,
    nombre: String(nombre).trim(),
    categoria: categoria || "Medicamentos",
    etiqueta: etiqueta || "",
    descripcion: descripcion || "",
    precio: Number(precio),
    requiere_receta: Boolean(requiere_receta),
    stock: stock !== undefined && stock !== "" ? Number(stock) : 50,
    imagen:
      imagen ||
      "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400&q=80",
  };

  products.push(newProduct);
  res.status(201).json(newProduct);
});

app.put("/api/products/:id", (req, res) => {
  const prodId = Number(req.params.id);
  const index = products.findIndex((p) => p.id === prodId);
  if (index === -1) {
    return res.status(404).json({ error: "Producto no encontrado." });
  }

  const { nombre, categoria, etiqueta, descripcion, precio, imagen, requiere_receta, stock } = req.body;

  if (nombre) products[index].nombre = String(nombre).trim();
  if (categoria) products[index].categoria = categoria;
  if (etiqueta !== undefined) products[index].etiqueta = etiqueta;
  if (descripcion !== undefined) products[index].descripcion = descripcion;
  if (precio !== undefined && precio !== "") products[index].precio = Number(precio);
  if (imagen !== undefined) products[index].imagen = imagen;
  if (requiere_receta !== undefined) products[index].requiere_receta = Boolean(requiere_receta);
  if (stock !== undefined && stock !== "") products[index].stock = Number(stock);

  res.json(products[index]);
});

app.delete("/api/products/:id", (req, res) => {
  const prodId = Number(req.params.id);
  const index = products.findIndex((p) => p.id === prodId);
  if (index === -1) {
    return res.status(404).json({ error: "Producto no encontrado." });
  }

  const deleted = products.splice(index, 1);
  res.json({ message: "Producto eliminado correctamente.", product: deleted[0] });
});

app.post("/api/orders", (req, res) => {
  const { usuario_id, items } = req.body; // items = [{ productId, quantity }]
  if (!usuario_id || !items || !items.length) {
    return res.status(400).json({ error: "El carrito está vacío." });
  }

  const buyer = users.find((u) => u.id === Number(usuario_id));
  const buyerEmail = buyer ? buyer.email : "cliente@ejemplo.com";
  const buyerName = buyer ? buyer.nombre : "Cliente";

  let total = 0;
  const orderItems = items.map((it: any) => {
    const prod = products.find((p) => p.id === it.productId);
    const price = prod ? prod.precio : 0;
    const subtotal = price * it.quantity;
    total += subtotal;

    // Descontar stock si existe
    if (prod && prod.stock) {
      prod.stock = Math.max(0, prod.stock - it.quantity);
    }

    return {
      id: Math.floor(Math.random() * 10000),
      pedido_id: nextOrderId,
      producto_id: it.productId,
      cantidad: it.quantity,
      precio_unitario: price,
      producto_nombre: prod ? prod.nombre : "Producto",
      producto_imagen: prod ? prod.imagen : "",
    };
  });

  const orderNumber = `VET-${nextOrderId}`;
  const newOrder = {
    id: nextOrderId++,
    order_code: orderNumber,
    usuario_id: Number(usuario_id),
    cliente_nombre: buyerName,
    cliente_email: buyerEmail,
    total,
    estado: "pagado" as const,
    creado_en: new Date().toISOString().replace("T", " ").substring(0, 19),
    items: orderItems,
    email_enviado: true,
    email_destinatario: buyerEmail,
  };

  orders.push(newOrder);
  res.json(newOrder);
});

app.get("/api/orders", (req, res) => {
  const userId = Number(req.query.userId);
  if (!userId) return res.json([]);
  res.json(orders.filter((o) => o.usuario_id === userId));
});

// --- ADMIN STATS ---
app.get("/api/admin/stats", (req, res) => {
  const hoyStr = new Date().toISOString().substring(0, 10);
  const totalHoy = turnos.filter(
    (t) => t.fecha === hoyStr && t.estado !== "cancelado"
  ).length;
  const pendientes = turnos.filter((t) => t.estado === "pendiente").length;
  const totalPacientes = pets.length;
  const totalClientes = users.filter((u) => u.rol === "cliente").length;

  res.json({
    totalHoy,
    pendientes,
    totalPacientes,
    totalClientes,
  });
});

// --- CHATBOX ASISTENTE CLÍNICO IA (GEMINI API) ---
let geminiAiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.trim() === "") {
    return null;
  }
  if (!geminiAiClient) {
    geminiAiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return geminiAiClient;
}

const CLINICAL_VET_FALLBACKS: Array<{ keywords: string[]; response: string }> = [
  {
    keywords: ["ayuno", "ecografia", "ecografía", "estudio", "analisis", "sangre", "preparar", "preparacion"],
    response:
      "🐾 **Preparación para estudios clínicos en VetAnimal:**\n\n• **Ecografía Abdominal:** Requiere de 8 a 10 horas de ayuno sólido (se puede mantener agua hasta 2 horas antes). Es ideal evitar que orine 1 hora previa para evaluar vejiga.\n• **Análisis de Sangre y Perfil Prequirúrgico:** Ayuno de 8 a 12 horas.\n• **Radiografías Digitales:** En general no requieren ayuno, excepto si el veterinario indicó sedación ligera.\n\n¿Querés que te ayude a agendar un turno para el estudio?",
  },
  {
    keywords: ["vacuna", "vacunas", "vacunacion", "vacunación", "antirrabica", "antirrábica", "cachorro", "gatito", "sextuple", "triple"],
    response:
      "🐾 **Plan de Vacunación y Prevención:**\n\n• **Caninos (Perros):** Inicio a los 45 días con Séxtuple/Óctuple (parvovirus, moquillo, hepatitis), con 2 o 3 refuerzos cada 21-30 días. A partir de los 3 meses se aplica la vacuna Antirrábica obligatoria anual.\n• **Felinos (Gatos):** Triple Felina (panleucopenia, rinotraqueítis, calicivirus) a los 60 días con su refuerzo, más Antirrábica anual.\n\n*Recomendación médica:* Antes de vacunar, la mascota debe estar clínicamente sana y desparasitada.",
  },
  {
    keywords: ["horario", "horarios", "donde", "dónde", "direccion", "dirección", "ubicacion", "ubicación", "queda", "telefono", "teléfono"],
    response:
      "🏥 **VetAnimal - Clínica Veterinaria Del Viso:**\n\n• **Sede Central:** Av. Eduardo Madero 1250, Del Viso (Partido del Pilar, Bs. As.).\n• **Horarios de Atención:** Lunes a Sábados de 08:30 a 20:00 hs.\n• **Teléfono de Recepción:** (02320) 47-1234 / 11-4000-1000.\n• **Red de Derivaciones:** Centro Asociado Tortuguitas en Cura Brochero 1420.",
  },
  {
    keywords: ["cardio", "cardiografia", "cardiografía", "doppler", "ecocardiograma", "rayos", "radiografia", "radiología", "derivacion", "derivación", "tortuguitas"],
    response:
      "❤️ **Estudios Especializados & Red de Interconsultas:**\n\nEn VetAnimal contamos con servicio de **Cardiografía, Ecocardiograma Doppler y Radiología Digital HD**. Además, articulamos con nuestro centro asociado de **Tortuguitas (Cura Brochero 1420)** para estudios con aparatología de alta complejidad.\n\nPodés solicitar tu **Turno Especializado** con derivación médica oficial directamente desde la sección *Turnos Especializados* de nuestra web.",
  },
  {
    keywords: ["turno", "turnos", "agendar", "reservar", "cita", "pedir turno"],
    response:
      "📅 **Reserva de Turnos Online en VetAnimal:**\n\nPodés sacar turno en menos de 2 minutos:\n1. Ingresá a **Reservar Turno** (/booking) para consultas generales, vacunación o desparasitación.\n2. O elegí **Turnos Especializados** si tu mascota precisa Cardiografía, Doppler o Rayos X.\n3. Seleccionás tu mascota, profesional y horario de preferencia y listo.",
  },
  {
    keywords: ["no come", "anorexia", "vomito", "vómito", "diarrea", "decaido", "decaído", "fiebre"],
    response:
      "⚠️ **Atención y Observación Clínica:**\n\nSi tu perro o gato presenta vómitos reiterados, diarrea abundante o lleva más de 24 horas sin comer o beber agua, no esperes: puede tratarse de una deshidratación o cuadro infeccioso.\n\nTe sugerimos no medicar por tu cuenta (muchos fármacos humanos como paracetamol o ibuprofeno son sumamente tóxicos para mascotas) y acercarte a nuestra clínica en Av. Eduardo Madero 1250 o comunicarte con nuestra guardia.",
  },
  {
    keywords: ["ahoga", "respirar", "urgencia", "emergencia", "convulsion", "convulsión", "sangre", "sangrado", "veneno", "intoxic", "atragant"],
    response:
      "🚨 **¡ATENCIÓN - POSIBLE URGENCIA VETERINARIA!**\n\n1. **Trasladate de inmediato:** Acudí a nuestra guardia médica presencial en **Av. Eduardo Madero 1250, Del Viso** o al centro veterinario de urgencia más cercano.\n2. **Mantené la calma:** El estrés acelera el ritmo cardíaco y empeora la dificultad respiratoria del animal.\n3. **Vías aéreas:** Asegurate de que el cuello esté recto y no comprimido. No suministres líquidos ni medicamentos caseros por la boca.\n4. **Teléfono de guardia:** (02320) 47-1234 / 11-4000-1000.",
  },
];

app.post("/api/chat", async (req, res) => {
  try {
    const { message, history, petContext } = req.body;
    const userMessage = (message || "").trim();

    if (!userMessage) {
      return res.status(400).json({ error: "El mensaje no puede estar vacío." });
    }

    const ai = getGeminiClient();

    if (ai) {
      const petDetails = petContext
        ? `Información de la mascota del usuario: Nombre: ${petContext.nombre}, Especie: ${petContext.especie}, Raza: ${petContext.raza || "Mestizo"}, Edad: ${petContext.edad || "N/A"} años.`
        : "El usuario no tiene una mascota preseleccionada en este momento.";

      const systemInstruction = `Sos "VetBot", el asistente clínico virtual inteligente de "VetAnimal Clínica Veterinaria", ubicada en Av. Eduardo Madero 1250, Del Viso (Partido del Pilar, Buenos Aires).

Tu rol es responder de forma concisa, cálida, profesional y empática a preguntas simples y frecuentes de tutores de mascotas (perros, gatos y otros animales):
1. Información de la clínica:
   - Sede Central: Av. Eduardo Madero 1250, Del Viso (Pilar).
   - Horarios: Lunes a Sábados de 08:30 a 20:00 hs.
   - Red de interconsultas y derivación médica: Centro Asociado Tortuguitas (Cura Brochero 1420) para aparatología y estudios de alta complejidad (Cardiografía, Ecocardiograma Doppler, Radiología Digital).
   - Servicios: Clínica general, vacunación, desparasitación, farmacia y alimentos clínicos, turnos online, historial médico digital con placas radiográficas.
2. Cuidados y preparación para estudios:
   - Ecografía abdominal: 8 a 10 hs de ayuno sólido, vejiga llena si es posible.
   - Análisis de sangre: 8 a 12 hs de ayuno.
   - Vacunación en cachorros/gatitos y refuerzos anuales.
   - Pautas básicas de prevención, higiene y nutrición.
3. Límites médicos importantes:
   - NUNCA diagnosticar enfermedades complejas ni recetar dosis farmacológicas específicas por chat.
   - Si detectás un cuadro de urgencia (dificultad respiratoria aguda, traumatismo grave, convulsiones, sangrado profuso o ingestión de veneno/cuerpos extraños), avisá inmediatamente que deben acudir a la guardia presencial en Av. Eduardo Madero 1250.
4. Tono y formato:
   - Sé breve, cercano y fácil de leer en pantallas de celular (usá viñetas cortas y emojis sutiles).
   - Español rioplatense o neutro cálido.
   - Podés invitar al usuario a usar las secciones de la app: "Reservar Turno" (/booking), "Historial Clínico" (/historial) o "Tienda" (/tienda).
${petDetails}`;

      // Armar contenido para Gemini
      const contentsPayload: any[] = [];
      if (Array.isArray(history) && history.length > 0) {
        // Tomar hasta los últimos 6 mensajes para contexto conversacional
        const recentHistory = history.slice(-6);
        for (const h of recentHistory) {
          if (h.role === "user" || h.role === "assistant" || h.role === "model") {
            contentsPayload.push({
              role: h.role === "assistant" ? "model" : "user",
              parts: [{ text: String(h.content || h.text || "") }],
            });
          }
        }
      }
      contentsPayload.push({
        role: "user",
        parts: [{ text: userMessage }],
      });

      // Intento 1: gemini-3.8-flash
      try {
        const geminiRes = await ai.models.generateContent({
          model: "gemini-3.8-flash",
          contents: contentsPayload,
          config: {
            systemInstruction,
            temperature: 0.6,
          },
        });

        const replyText = geminiRes.text?.trim();
        if (replyText) {
          return res.json({ reply: replyText, source: "gemini-ai" });
        }
      } catch (geminiError: any) {
        console.warn("gemini-3.8-flash con sobrecarga temporal, reintentando con gemini-3.1-flash-lite...");
        // Intento 2 de rescate con gemini-3.1-flash-lite
        try {
          const fallbackModelRes = await ai.models.generateContent({
            model: "gemini-3.1-flash-lite",
            contents: contentsPayload,
            config: {
              systemInstruction,
              temperature: 0.6,
            },
          });
          const liteReply = fallbackModelRes.text?.trim();
          if (liteReply) {
            return res.json({ reply: liteReply, source: "gemini-ai" });
          }
        } catch (liteError: any) {
          console.warn("Fallo secundario en flash-lite, usando base de conocimiento clínica:", liteError?.message || liteError);
        }
      }
    }

    // Respuesta con fallback de conocimiento clínico si Gemini no está configurado o falló
    const lower = userMessage.toLowerCase();
    const matched = CLINICAL_VET_FALLBACKS.find((f) =>
      f.keywords.some((k) => lower.includes(k))
    );

    if (matched) {
      return res.json({ reply: matched.response, source: "clinical-knowledge-base" });
    }

    // Respuesta de bienvenida/orientación por defecto
    const defaultReply =
      "🐾 ¡Hola! Soy **VetBot**, el asistente de **VetAnimal Del Viso**.\n\nPodés consultarme sobre:\n• **Preparación para estudios** (ayuno de ecografías o análisis de sangre)\n• **Plan de vacunas y desparasitación** para cachorros y gatitos\n• **Horarios y ubicación** de nuestra sede en Del Viso y centro de Tortuguitas\n• **Cómo reservar turnos** clínicos o especializados (Cardiología / Rx)\n\n¿Sobre cuál de estos temas te gustaría saber más?";

    return res.json({ reply: defaultReply, source: "clinical-knowledge-base" });
  } catch (error: any) {
    console.error("Error en endpoint /api/chat:", error);
    return res.status(500).json({
      error: "Ocurrió un error al procesar tu consulta.",
      reply: "Disculpá, tuvimos un inconveniente temporal al responder. Por favor intentá nuevamente o comunicate con la clínica al (02320) 47-1234.",
    });
  }
});

// --- VITE SERVING & PRODUCTION SETUP ---
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
