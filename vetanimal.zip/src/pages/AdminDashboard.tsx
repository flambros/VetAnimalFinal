import React, { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { AdminStats, Turno } from "../types";
import { LogoIcon } from "../components/LogoIcon";
import { 
  LayoutDashboard, 
  Calendar, 
  Users, 
  FileText, 
  ShoppingBag, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  ArrowLeft 
} from "lucide-react";

interface AdminDashboardProps {
  navigate: (path: string) => void;
  activeTab: "dashboard" | "turnos" | "pacientes";
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  navigate,
  activeTab,
}) => {
  const { user } = useAuth();
  const [stats, setStats] = useState<AdminStats>({
    totalHoy: 0,
    pendientes: 0,
    totalPacientes: 0,
    totalClientes: 0,
  });
  const [todayTurnos, setTodayTurnos] = useState<Turno[]>([]);

  const hoyStr = new Date().toISOString().substring(0, 10);

  useEffect(() => {
    if (!user || user.rol !== "veterinario") {
      navigate("/");
      return;
    }

    fetch("/api/admin/stats")
      .then((res) => res.json())
      .then((data) => setStats(data));

    fetch(`/api/turnos?all=true&fecha=${hoyStr}`)
      .then((res) => res.json())
      .then((data) => setTodayTurnos(data));
  }, [user]);

  const updateEstado = async (id: number, estado: string) => {
    try {
      const res = await fetch(`/api/turnos/${id}/estado`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ estado }),
      });
      if (res.ok) {
        setTodayTurnos((prev) =>
          prev.map((t) => (t.id === id ? { ...t, estado: estado as any } : t))
        );
      }
    } catch (e) {}
  };

  return (
    <div className="admin-shell">
      <div className="admin-sidebar">
        <div
          className="logo cursor-pointer flex items-center gap-3 text-white mb-6"
          onClick={() => navigate("/admin/dashboard")}
        >
          <LogoIcon size={34} />
          <div>
            <div className="font-bold text-base leading-tight">VetAnimal</div>
            <div className="text-[10px] text-blue-200 uppercase font-semibold">Panel Veterinario</div>
          </div>
        </div>
        <nav className="admin-nav">
          <button
            className={`flex items-center gap-2.5 ${activeTab === "dashboard" ? "active" : ""}`}
            onClick={() => navigate("/admin/dashboard")}
          >
            <LayoutDashboard size={16} />
            <span>Panel Principal</span>
          </button>
          <button
            className={`flex items-center gap-2.5 ${activeTab === "turnos" ? "active" : ""}`}
            onClick={() => navigate("/admin/turnos")}
          >
            <Calendar size={16} />
            <span>Gestión de Turnos</span>
          </button>
          <button
            className={`flex items-center gap-2.5 ${activeTab === "pacientes" ? "active" : ""}`}
            onClick={() => navigate("/admin/pacientes")}
          >
            <Users size={16} />
            <span>Pacientes &amp; Clientes</span>
          </button>
          <button 
            className="flex items-center gap-2.5"
            onClick={() => navigate("/historial")}
          >
            <FileText size={16} />
            <span>Historiales Clínicos</span>
          </button>
          <button 
            className="flex items-center gap-2.5"
            onClick={() => navigate("/admin/tienda")}
          >
            <ShoppingBag size={16} />
            <span>Gestión de Tienda</span>
          </button>
        </nav>
        <div className="mt-auto pt-6 border-t border-white/20">
          <p className="text-xs text-white/70">Sesión iniciada como:</p>
          <p className="font-semibold text-sm">{user?.nombre}</p>
          <p className="text-xs text-blue-200 font-mono mt-0.5">{user?.email}</p>
          <button
            onClick={() => navigate("/")}
            className="btn btn-outline btn-sm text-white border-white/40 hover:bg-white/10 mt-4 w-full"
          >
            ← Ir a la web pública
          </button>
        </div>
      </div>

      <div className="admin-main">
        <div className="admin-topbar">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Panel Veterinario</h1>
            <p className="text-sm text-slate-500">
              Bienvenido/a, Dr/a. {user?.nombre}. Hoy es {hoyStr}.
            </p>
          </div>
          <button
            onClick={() => navigate("/booking")}
            className="btn btn-primary btn-sm font-bold flex items-center gap-1.5"
          >
            <span>+</span>
            <span>Agendar Turno</span>
          </button>
        </div>

        <div className="stat-grid">
          <div className="stat-card">
            <div className="num">{stats.totalHoy}</div>
            <div className="lbl">Turnos para hoy</div>
          </div>
          <div className="stat-card">
            <div className="num">{stats.pendientes}</div>
            <div className="lbl">Pendientes de atención</div>
          </div>
          <div className="stat-card">
            <div className="num">{stats.totalPacientes}</div>
            <div className="lbl">Pacientes en sistema</div>
          </div>
          <div className="stat-card">
            <div className="num">{stats.totalClientes}</div>
            <div className="lbl">Clientes registrados</div>
          </div>
        </div>

        <div className="panel-card">
          <h2>Agenda del Día ({todayTurnos.length})</h2>
          {todayTurnos.length === 0 ? (
            <p className="text-slate-500 py-8 text-center">
              No hay turnos agendados para la fecha de hoy.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Hora</th>
                    <th>Mascota</th>
                    <th>Dueño</th>
                    <th>Servicio</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {todayTurnos.map((t) => (
                    <tr key={t.id}>
                      <td>
                        <strong>{t.hora} hs</strong>
                      </td>
                      <td>{t.mascota_nombre}</td>
                      <td>{t.dueno}</td>
                      <td>{t.servicio_nombre}</td>
                      <td>
                        <span className={`badge badge-${t.estado}`}>
                          {t.estado === "completado" ? "ATENDIDO" : t.estado.toUpperCase()}
                        </span>
                      </td>
                      <td>
                        <div className="table-actions">
                          {t.estado !== "completado" && t.estado !== "cancelado" && (
                            <button
                              onClick={() => updateEstado(t.id, "completado")}
                              className="btn btn-primary btn-sm text-xs py-1 px-2.5"
                              title="Marcar como atendido"
                            >
                              ✓ Atendido
                            </button>
                          )}
                          {t.estado !== "cancelado" && t.estado !== "completado" && (
                            <button
                              onClick={() => {
                                if (confirm(`¿Deseas cancelar el turno #${t.id}?`)) {
                                  updateEstado(t.id, "cancelado");
                                }
                              }}
                              className="btn btn-danger btn-sm text-xs py-1 px-2.5"
                              title="Cancelar turno"
                            >
                              ✕
                            </button>
                          )}
                          {t.estado === "cancelado" && (
                            <span className="text-xs text-red-600 font-semibold bg-red-50 px-2 py-0.5 rounded border border-red-200">
                              Cancelado
                            </span>
                          )}
                          {t.estado === "completado" && (
                            <span className="text-xs text-green-700 font-semibold bg-green-50 px-2 py-0.5 rounded border border-green-200">
                              Atendido
                            </span>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
