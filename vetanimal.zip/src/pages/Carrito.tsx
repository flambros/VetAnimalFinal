import React, { useState } from "react";
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";
import { Mail, CheckCircle2, Eye, EyeOff, Trash2, ShoppingBag, ArrowLeft, ArrowRight, ShieldCheck } from "lucide-react";
import { LogoIcon } from "../components/LogoIcon";
import { sendOrderConfirmationEmail, EmailMessage } from "../services/emailService";
import { EmailPreviewModal } from "../components/EmailPreviewModal";

interface CarritoProps {
  navigate: (path: string) => void;
}

export const Carrito: React.FC<CarritoProps> = ({ navigate }) => {
  const { items, removeFromCart, clearCart, total } = useCart();
  const { user } = useAuth();
  const [completedOrder, setCompletedOrder] = useState<any | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [emailResent, setEmailResent] = useState(false);

  // Email modal preview
  const [orderEmailMsg, setOrderEmailMsg] = useState<EmailMessage | null>(null);
  const [showEmailModal, setShowEmailModal] = useState(false);

  const handleCheckout = async () => {
    if (!user) {
      navigate("/login");
      return;
    }
    if (items.length === 0) return;

    setSubmitting(true);
    setError("");

    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          usuario_id: user.id,
          items: items.map((i) => ({
            productId: i.product.id,
            quantity: i.quantity,
          })),
        }),
      });

      const data = await res.json();
      setSubmitting(false);

      if (!res.ok) {
        setError(data.error || "Error al procesar la compra");
        return;
      }

      const orderCode = data.order_code || `VET-${data.id}`;
      const emailMsg = sendOrderConfirmationEmail(
        user.nombre,
        user.email,
        orderCode,
        items.map((it) => ({
          name: it.product.nombre,
          quantity: it.quantity,
          price: it.product.precio,
        })),
        total,
        "Envío prioritario a domicilio"
      );

      setOrderEmailMsg(emailMsg);
      setCompletedOrder(data);
      clearCart();
    } catch (e) {
      setSubmitting(false);
      setError("Error de red al procesar el pago");
    }
  };

  const handleResendEmail = () => {
    if (user && completedOrder) {
      const orderCode = completedOrder.order_code || `VET-${completedOrder.id}`;
      sendOrderConfirmationEmail(
        user.nombre,
        user.email,
        orderCode,
        completedOrder.items?.map((it: any) => ({
          name: it.producto_nombre,
          quantity: it.cantidad,
          price: it.precio_unitario,
        })) || [],
        completedOrder.total,
        "Envío prioritario a domicilio"
      );
    }
    setEmailResent(true);
    setTimeout(() => setEmailResent(false), 3500);
  };

  if (completedOrder) {
    const userEmail = completedOrder.cliente_email || user?.email || "cliente@ejemplo.com";
    const userName = completedOrder.cliente_nombre || user?.nombre || "Cliente";
    const orderCode = completedOrder.order_code || `VET-${completedOrder.id}`;

    return (
      <>
        <div className="container section" style={{ maxWidth: "720px" }}>
          <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-xl text-center space-y-6 animate-in zoom-in-95">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 size={36} />
            </div>

            <div>
              <span className="inline-block text-xs font-bold uppercase tracking-wider px-3 py-1 bg-emerald-50 text-emerald-800 rounded-full border border-emerald-200 mb-2">
                ¡Compra Confirmada y Acreditada!
              </span>

              <h1 className="text-lg sm:text-xl font-bold bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 bg-clip-text text-transparent mb-1">
                ¡Gracias por tu compra, {userName.split(" ")[0]}!
              </h1>

              <p className="text-slate-500 text-sm">
                Orden <strong className="text-slate-800 font-bold font-mono">#{orderCode}</strong> registrada con éxito.
              </p>
            </div>

            {/* Email dispatch banner */}
            <div className="bg-blue-50/70 border border-blue-200 rounded-2xl p-5 text-left shadow-sm">
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-md">
                  <Mail size={20} />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-sm text-blue-950 flex items-center gap-2">
                    <span>Email de confirmación y factura enviado</span>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                      Entregado
                    </span>
                  </h3>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    Hemos enviado el detalle de los productos, factura electrónica y código de seguimiento a:{" "}
                    <strong className="text-blue-900 font-semibold">{userEmail}</strong>.
                  </p>
                  <div className="flex flex-wrap gap-2.5 mt-3.5">
                    <button
                      type="button"
                      onClick={() => setShowEmailModal(true)}
                      className="btn btn-primary btn-sm text-xs py-2 px-3.5 flex items-center gap-1.5 font-bold shadow-sm"
                    >
                      <Eye size={14} />
                      <span>Ver email recibido</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleResendEmail}
                      className="btn btn-light btn-sm text-xs py-2 px-3.5 font-semibold"
                    >
                      Reenviar email
                    </button>
                  </div>
                  {emailResent && (
                    <p className="text-xs font-semibold text-emerald-700 mt-2 flex items-center gap-1">
                      <CheckCircle2 size={14} />
                      <span>Correo de confirmación reenviado exitosamente a {userEmail}.</span>
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Order items summary card */}
            <div className="border border-slate-200 rounded-2xl p-5 text-left bg-slate-50">
              <h3 className="font-bold text-xs uppercase tracking-wider text-slate-700 mb-3 flex items-center gap-1.5">
                <ShoppingBag size={14} className="text-blue-600" />
                <span>Detalle del Pedido #{orderCode}</span>
              </h3>
              <div className="divide-y divide-slate-200 text-xs bg-white rounded-xl p-3 border border-slate-200/80">
                {completedOrder.items?.map((it: any, idx: number) => (
                  <div key={idx} className="py-2.5 flex items-center justify-between">
                    <div>
                      <span className="font-semibold text-slate-800">{it.producto_nombre}</span>
                      <span className="text-slate-500 block text-[11px]">
                        Cantidad: {it.cantidad} × ${Number(it.precio_unitario).toFixed(2)}
                      </span>
                    </div>
                    <span className="font-bold text-slate-900">
                      ${(it.precio_unitario * it.cantidad).toFixed(2)}
                    </span>
                  </div>
                ))}
                <div className="pt-3 flex items-center justify-between font-bold text-sm">
                  <span className="text-slate-800">Total Abonado:</span>
                  <span className="text-blue-700 text-lg font-extrabold">${Number(completedOrder.total).toFixed(2)}</span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap justify-center gap-3 pt-2">
              <button
                onClick={() => navigate("/tienda")}
                className="btn btn-primary px-6 py-2.5 text-xs font-bold"
              >
                Volver a la Tienda
              </button>
              <button
                onClick={() => navigate("/perfil")}
                className="btn btn-outline px-6 py-2.5 text-xs font-semibold"
              >
                Ir a Mi Perfil
              </button>
            </div>
          </div>
        </div>

        {/* Modal for email view */}
        <EmailPreviewModal
          email={orderEmailMsg}
          isOpen={showEmailModal}
          onClose={() => setShowEmailModal(false)}
          onNavigate={navigate}
        />
      </>
    );
  }

  return (
    <div className="container section" style={{ maxWidth: "800px" }}>
      <button
        onClick={() => navigate("/tienda")}
        className="text-xs font-bold text-blue-600 hover:text-blue-800 mb-6 flex items-center gap-1.5 cursor-pointer"
      >
        <ArrowLeft size={14} />
        <span>Volver a la Tienda</span>
      </button>

      <div className="flex items-center gap-2 mb-3">
        <LogoIcon size={24} />
        <span className="text-xs font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-3.5 py-1 rounded-full border border-blue-200">
          Tienda &amp; Farmacia Oficial
        </span>
      </div>

      <div className="space-y-1 mb-8">
        <h1 className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 bg-clip-text text-transparent">
          Carrito de Compras
        </h1>
        <p className="text-slate-500 text-xs sm:text-sm">
          Revisá tus productos antes de finalizar el pedido.
        </p>
      </div>

      {error && <div className="alert alert-error mb-4">{error}</div>}

      {items.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center shadow-sm">
          <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4 border border-blue-100">
            <ShoppingBag size={32} />
          </div>
          <h2 className="text-xl font-bold text-slate-800 mb-2">Tu carrito está vacío</h2>
          <p className="text-slate-500 text-sm max-w-sm mx-auto mb-6">
            Explorá nuestra tienda para agregar alimentos balanceados, champús o medicamentos.
          </p>
          <button onClick={() => navigate("/tienda")} className="btn btn-primary font-bold text-xs py-2.5 px-6">
            Ir a la Tienda
          </button>
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm">
          <div className="divide-y divide-slate-100">
            {items.map((item) => (
              <div
                key={item.product.id}
                className="py-4 flex items-center justify-between gap-4"
              >
                <div className="flex items-center gap-4">
                  <img
                    src={
                      item.product.imagen ||
                      "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=200&q=80"
                    }
                    alt={item.product.nombre}
                    className="w-16 h-16 object-cover rounded-2xl border border-slate-200"
                  />
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                      {item.product.nombre}
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Cantidad: {item.quantity} × ${item.product.precio.toFixed(2)}
                    </p>
                    {item.product.requiere_receta && (
                      <span className="text-[10px] text-amber-700 font-semibold bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200 mt-1 inline-block">
                        Requiere Receta
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-extrabold text-base text-slate-900">
                    ${(item.product.precio * item.quantity).toFixed(2)}
                  </span>
                  <button
                    onClick={() => removeFromCart(item.product.id)}
                    className="text-red-500 hover:text-red-700 p-2 rounded-lg hover:bg-red-50 transition-colors cursor-pointer"
                    title="Eliminar producto"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 pt-6 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-xs text-slate-500 block uppercase font-bold tracking-wider">Total a Pagar:</span>
              <span className="text-3xl font-extrabold text-blue-700">
                ${total.toFixed(2)}
              </span>
            </div>
            {user && (
              <div className="text-xs text-slate-500 bg-slate-50 p-2.5 px-3 rounded-xl border border-slate-200">
                <span>Confirmación y factura se enviará a: </span>
                <strong className="text-blue-900 block sm:inline">{user.email}</strong>
              </div>
            )}
          </div>

          <div className="mt-8 flex flex-wrap justify-end gap-3">
            <button
              onClick={clearCart}
              className="btn btn-light text-xs font-semibold py-2.5 px-4"
            >
              Vaciar Carrito
            </button>
            <button
              onClick={handleCheckout}
              disabled={submitting}
              className="btn btn-primary text-xs font-bold py-2.5 px-6 shadow-lg shadow-blue-600/25 flex items-center gap-2"
            >
              <span>{submitting ? "Procesando orden..." : "Confirmar Compra & Enviar Email"}</span>
              <ArrowRight size={14} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
