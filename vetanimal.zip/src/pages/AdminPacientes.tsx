import React, { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { Pet } from "../types";
import { LogoIcon } from "../components/LogoIcon";
import { 
  LayoutDashboard, 
  Calendar, 
  Users, 
  FileText, 
  ShoppingBag, 
  Search,
  Plus,
  X,
  Check,
  Upload,
  AlertCircle
} from "lucide-react";

interface AdminPacientesProps {
  navigate: (path: string) => void;
}

const photoPresets = [
  { label: "Perro 1", url: "https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=500&q=80" },
  { label: "Perro 2 (Boxer)", url: "https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=500&q=80" },
  { label: "Perro 3 (Golden)", url: "https://images.unsplash.com/photo-1552053831-71594a27632d?w=500&q=80" },
  { label: "Gato 1 (Siamés)", url: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=500&q=80" },
  { label: "Gato 2 (Carey)", url: "https://images.unsplash.com/photo-1573865526739-10659fec78a5?w=500&q=80" },
  { label: "Gato 3 (Naranja)", url: "https://images.unsplash.com/photo-1533738363-b7f9aef128ce?w=500&q=80" },
  { label: "Ave", url: "https://images.unsplash.com/photo-1552728089-57bdde30beb3?w=500&q=80" },
  { label: "Exótico", url: "https://images.unsplash.com/photo-1425082661705-1834bfd09dca?w=500&q=80" },
];

export const AdminPacientes: React.FC<AdminPacientesProps> = ({ navigate }) => {
  const { user } = useAuth();
  const [pets, setPets] = useState<Pet[]>([]);
  const [search, setSearch] = useState("");

  // Modal para registrar paciente
  const [showModal, setShowModal] = useState(false);
  const [nombre, setNombre] = useState("");
  const [especie, setEspecie] = useState("Gato");
  const [raza, setRaza] = useState("");
  const [edad, setEdad] = useState("");
  const [peso, setPeso] = useState("");
  const [duenoId, setDuenoId] = useState("3"); // Por defecto Agustina Gómez
  const [foto, setFoto] = useState("");
  const [customFotoUrl, setCustomFotoUrl] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  const loadPets = () => {
    fetch("/api/pets?all=true")
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) setPets(data);
      })
      .catch((err) => console.error("Error loading pets:", err));
  };

  useEffect(() => {
    if (!user || user.rol !== "veterinario") {
      navigate("/");
      return;
    }
    loadPets();
  }, [user]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === "string") {
          setFoto(reader.result);
          setCustomFotoUrl("");
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCreatePet = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nombre.trim()) {
      setErrorMsg("El nombre del paciente es obligatorio.");
      return;
    }

    setSubmitting(true);
    setErrorMsg("");
    setSuccessMsg("");

    const selectedPhoto = customFotoUrl.trim() || foto;

    try {
      const res = await fetch("/api/pets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          usuario_id: Number(duenoId) || 3,
          nombre: nombre.trim(),
          especie,
          raza: raza.trim(),
          edad: edad ? Number(edad) : undefined,
          peso: peso ? Number(peso) : undefined,
          foto: selectedPhoto || undefined,
        }),
      });

      const data = await res.json();
      setSubmitting(false);

      if (!res.ok) {
        setErrorMsg(data.error || "No se pudo registrar el paciente.");
        return;
      }

      setSuccessMsg(`¡${data.nombre} (${data.especie}) registrado exitosamente en la base de datos!`);
      // Reset form
      setNombre("");
      setRaza("");
      setEdad("");
      setPeso("");
      setFoto("");
      setCustomFotoUrl("");
      loadPets();

      setTimeout(() => {
        setShowModal(false);
        setSuccessMsg("");
      }, 1400);
    } catch (err) {
      setSubmitting(false);
      setErrorMsg("Error de conexión con el servidor.");
    }
  };

  const handleDeletePet = async (petId: number, petName: string) => {
    if (!window.confirm(`¿Estás seguro de eliminar a ${petName} del registro?`)) return;
    try {
      const res = await fetch(`/api/pets/${petId}`, { method: "DELETE" });
      if (res.ok) {
        setPets((prev) => prev.filter((p) => p.id !== petId));
      }
    } catch (err) {
      console.error(err);
    }
  };

  const filteredPets = pets.filter((p) => {
    const s = search.toLowerCase();
    return (
      p.nombre.toLowerCase().includes(s) ||
      p.especie.toLowerCase().includes(s) ||
      (p.dueno && p.dueno.toLowerCase().includes(s)) ||
      (p.raza && p.raza.toLowerCase().includes(s))
    );
  });

  const countGatos = pets.filter((p) => p.especie.toLowerCase() === "gato").length;
  const countPerros = pets.filter((p) => p.especie.toLowerCase() === "perro").length;
  const countOtros = pets.length - countGatos - countPerros;

  return (
    <div className="admin-shell">
      <div className="admin-sidebar">
        <div
          className="logo cursor-pointer flex items-center gap-3 text-white mb-6"
          onClick={() => navigate("/admin/dashboard")}
        >
          <LogoIcon size={34} />
          <div>
            <div className="font-bold text-base leading-tight">VetAnimal</div>
            <div className="text-[10px] text-blue-200 uppercase font-semibold">Panel Veterinario</div>
          </div>
        </div>
        <nav className="admin-nav">
          <button 
            className="flex items-center gap-2.5"
            onClick={() => navigate("/admin/dashboard")}
          >
            <LayoutDashboard size={16} />
            <span>Panel Principal</span>
          </button>
          <button 
            className="flex items-center gap-2.5"
            onClick={() => navigate("/admin/turnos")}
          >
            <Calendar size={16} />
            <span>Gestión de Turnos</span>
          </button>
          <button
            className="active flex items-center gap-2.5"
            onClick={() => navigate("/admin/pacientes")}
          >
            <Users size={16} />
            <span>Pacientes &amp; Clientes</span>
          </button>
          <button 
            className="flex items-center gap-2.5"
            onClick={() => navigate("/historial")}
          >
            <FileText size={16} />
            <span>Historiales Clínicos</span>
          </button>
          <button 
            className="flex items-center gap-2.5"
            onClick={() => navigate("/admin/tienda")}
          >
            <ShoppingBag size={16} />
            <span>Gestión de Tienda</span>
          </button>
        </nav>
      </div>

      <div className="admin-main">
        <div className="admin-topbar flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Registro de Pacientes</h1>
            <p className="text-sm text-slate-600">
              Listado completo de animales atendidos, gatos, perros y legajos médicos en Del Viso.
            </p>
          </div>

          <button
            onClick={() => {
              setErrorMsg("");
              setSuccessMsg("");
              setShowModal(true);
            }}
            className="btn btn-primary px-4 py-2.5 text-xs font-bold flex items-center gap-2 bg-blue-600 hover:bg-blue-500 shadow-md cursor-pointer"
          >
            <Plus size={16} />
            <span>Registrar Nuevo Paciente (Gato / Perro)</span>
          </button>
        </div>

        {/* Resumen de Pacientes */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Pacientes</span>
            <span className="text-2xl font-black text-slate-900 mt-1">{pets.length}</span>
            <span className="text-[11px] text-slate-400 mt-0.5">En base de datos</span>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-amber-200 shadow-sm flex flex-col bg-amber-50/40">
            <span className="text-xs font-bold text-amber-800 uppercase tracking-wider flex items-center gap-1">
              🐱 Felinos (Gatos)
            </span>
            <span className="text-2xl font-black text-amber-900 mt-1">{countGatos}</span>
            <span className="text-[11px] text-amber-700 mt-0.5">Pacientes felinos</span>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-blue-200 shadow-sm flex flex-col bg-blue-50/40">
            <span className="text-xs font-bold text-blue-800 uppercase tracking-wider flex items-center gap-1">
              🐶 Caninos (Perros)
            </span>
            <span className="text-2xl font-black text-blue-900 mt-1">{countPerros}</span>
            <span className="text-[11px] text-blue-700 mt-0.5">Pacientes caninos</span>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Otras Especies</span>
            <span className="text-2xl font-black text-slate-900 mt-1">{countOtros}</span>
            <span className="text-[11px] text-slate-400 mt-0.5">Aves y exóticos</span>
          </div>
        </div>

        <div className="panel-card">
          <div className="mb-6 max-w-md">
            <div className="search-bar">
              <Search size={16} className="text-slate-400" />
              <input
                type="text"
                placeholder="Buscar por nombre, especie (gato/perro), raza o dueño..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Paciente</th>
                  <th>Especie / Raza</th>
                  <th>Edad &amp; Peso</th>
                  <th>Dueño / Contacto</th>
                  <th>Estado Clínico</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {filteredPets.map((p) => (
                  <tr key={p.id}>
                    <td>
                      <div className="flex items-center gap-3">
                        <img
                          src={
                            p.foto ||
                            (p.especie === "Gato"
                              ? "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=200&q=80"
                              : "https://images.unsplash.com/photo-1552053831-71594a27632d?w=200&q=80")
                          }
                          alt={p.nombre}
                          className="w-11 h-11 rounded-full object-cover border border-slate-200 shadow-sm"
                        />
                        <div>
                          <strong className="block text-slate-900 font-bold">{p.nombre}</strong>
                          <span className="text-xs text-slate-400">ID #{p.id}</span>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                            p.especie.toLowerCase() === "gato"
                              ? "bg-amber-100 text-amber-900 border border-amber-200"
                              : p.especie.toLowerCase() === "perro"
                              ? "bg-blue-100 text-blue-900 border border-blue-200"
                              : "bg-purple-100 text-purple-900 border border-purple-200"
                          }`}
                        >
                          {p.especie === "Gato" ? "🐱 Gato" : p.especie === "Perro" ? "🐶 Perro" : p.especie}
                        </span>
                      </div>
                      <small className="text-slate-500 font-medium mt-0.5 block">{p.raza || "Mestizo / Sin especificar"}</small>
                    </td>
                    <td>
                      <span className="text-sm font-semibold text-slate-800">
                        {p.edad ? `${p.edad} años` : "No esp."}
                      </span>
                      <br />
                      <small className="text-slate-500 font-medium">
                        {p.peso ? `${p.peso} kg` : "Sin pesar"}
                      </small>
                    </td>
                    <td>
                      <strong className="text-slate-900 block font-semibold">{p.dueno || "Cliente VetAnimal"}</strong>
                      <small className="text-slate-500">{p.telefono || "11-4000-1000"}</small>
                    </td>
                    <td>
                      <span
                        className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold ${
                          p.estado_salud?.includes("En tratamiento") || p.estado_salud?.includes("observación")
                            ? "bg-amber-100 text-amber-900"
                            : "bg-emerald-100 text-emerald-900"
                        }`}
                      >
                        {p.estado_salud || "Estable"}
                      </span>
                    </td>
                    <td>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => navigate(`/historial?mascota_id=${p.id}`)}
                          className="btn btn-outline btn-sm text-xs font-bold py-1.5 px-3 flex items-center gap-1 hover:bg-blue-600 hover:text-white transition-colors cursor-pointer"
                          title={`Abrir historial clínico de ${p.nombre}`}
                        >
                          <FileText size={14} />
                          <span>Historial</span>
                        </button>
                        <button
                          onClick={() => handleDeletePet(p.id, p.nombre)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
                          title="Eliminar paciente"
                        >
                          <X size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* MODAL PARA REGISTRAR NUEVO PACIENTE DIRECTAMENTE */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-5 right-5 text-slate-400 hover:text-slate-700 p-2 rounded-full hover:bg-slate-100 transition-colors"
            >
              <X size={20} />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                <Plus size={22} />
              </div>
              <div>
                <h2 className="text-xl font-bold text-slate-900">Registrar Nuevo Paciente</h2>
                <p className="text-xs text-slate-500">
                  Ingreso directo a la base de datos de VetAnimal Del Viso
                </p>
              </div>
            </div>

            {errorMsg && (
              <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs font-semibold text-rose-800 flex items-center gap-2">
                <AlertCircle size={16} />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-800 flex items-center gap-2">
                <Check size={16} />
                <span>{successMsg}</span>
              </div>
            )}

            <form onSubmit={handleCreatePet} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Nombre del Paciente *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ej: Oliver, Simba, Kira..."
                    value={nombre}
                    onChange={(e) => setNombre(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Especie *
                  </label>
                  <select
                    value={especie}
                    onChange={(e) => setEspecie(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-semibold text-slate-800"
                  >
                    <option value="Gato">🐱 Gato (Felino)</option>
                    <option value="Perro">🐶 Perro (Canino)</option>
                    <option value="Ave">🦜 Ave</option>
                    <option value="Exótico">🦎 Exótico / Roedor / Otro</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Raza
                  </label>
                  <input
                    type="text"
                    placeholder="Ej: Siamés, Mestizo..."
                    value={raza}
                    onChange={(e) => setRaza(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Edad (Años)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.5"
                    placeholder="Ej: 2"
                    value={edad}
                    onChange={(e) => setEdad(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Peso (Kg)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.1"
                    placeholder="Ej: 4.5"
                    value={peso}
                    onChange={(e) => setPeso(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Dueño / Cliente Asignado *
                </label>
                <select
                  value={duenoId}
                  onChange={(e) => setDuenoId(e.target.value)}
                  className="w-full border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800"
                >
                  <option value="3">Agustina Gómez (agustina.gomez@example.com - Tel: 11-5555-2222)</option>
                  <option value="4">Carlos Bianchi (carlos.bianchi@example.com - Tel: 11-4433-2211)</option>
                  <option value="5">Valeria Rossi (valeria.rossi@example.com - Tel: 11-6677-8899)</option>
                </select>
              </div>

              {/* Selector de Fotos / Presets */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Foto del Paciente
                </label>
                <div className="grid grid-cols-4 sm:grid-cols-8 gap-2 mb-2">
                  {photoPresets.map((p, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setFoto(p.url);
                        setCustomFotoUrl("");
                      }}
                      className={`relative rounded-xl overflow-hidden aspect-square border-2 transition-all cursor-pointer ${
                        (customFotoUrl ? "" : foto) === p.url
                          ? "border-blue-600 scale-105 shadow-md"
                          : "border-transparent opacity-75 hover:opacity-100"
                      }`}
                    >
                      <img src={p.url} alt={p.label} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="url"
                    placeholder="O pegar URL de imagen..."
                    value={customFotoUrl}
                    onChange={(e) => {
                      setCustomFotoUrl(e.target.value);
                      setFoto("");
                    }}
                    className="flex-1 border border-slate-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <label className="px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer border border-slate-200">
                    <Upload size={13} />
                    <span>Subir</span>
                    <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                  </label>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2.5 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="btn btn-primary px-5 py-2.5 text-xs font-bold flex items-center gap-2 bg-blue-600 hover:bg-blue-500 shadow-md cursor-pointer disabled:opacity-50"
                >
                  {submitting ? "Guardando..." : "Guardar en Base de Datos"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
