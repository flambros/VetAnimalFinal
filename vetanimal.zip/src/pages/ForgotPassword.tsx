import React, { useState } from "react";
import { LogoIcon } from "../components/LogoIcon";
import { Mail, ArrowLeft, Send } from "lucide-react";

interface ForgotPasswordProps {
  navigate: (path: string) => void;
}

export const ForgotPassword: React.FC<ForgotPasswordProps> = ({ navigate }) => {
  const [email, setEmail] = useState("");
  const [mensaje, setMensaje] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      })
        .then((res) => res.json())
        .then((data) => {
          setMensaje(
            data.message ||
              "Si el correo existe en nuestro sistema, te enviamos un enlace de recuperación."
          );
        });
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-slate-50">
      <div
        className="flex items-center gap-2.5 mb-6 cursor-pointer"
        onClick={() => navigate("/")}
      >
        <LogoIcon size={34} />
        <span className="font-bold text-2xl text-slate-900">VetAnimal</span>
      </div>
      <div className="bg-white rounded-3xl shadow-md p-8 sm:p-10 max-w-md w-full text-center border border-slate-200">
        <h1 className="text-2xl font-bold text-slate-900 mb-2">Restablecer Contraseña</h1>
        <p className="text-slate-500 mb-6 text-sm">
          Ingresá tu correo electrónico y te enviaremos las instrucciones de recuperación.
        </p>

        {mensaje ? (
          <div className="alert alert-success text-sm mb-4">{mensaje}</div>
        ) : (
          <form onSubmit={handleSubmit} className="text-left">
            <div className="field">
              <label>Dirección de Correo Electrónico</label>
              <div className="input-wrap">
                <span className="text-slate-400 flex items-center justify-center">
                  <Mail size={16} />
                </span>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="nombre@ejemplo.com"
                  required
                />
              </div>
            </div>
            <button type="submit" className="btn btn-primary btn-block mt-4 font-bold py-3 flex items-center justify-center gap-2">
              <span>Enviar enlace de recuperación</span>
              <Send size={15} />
            </button>
          </form>
        )}

        <div className="mt-6 pt-4 border-t border-slate-100">
          <button
            type="button"
            className="text-blue-600 hover:text-blue-700 text-sm font-semibold flex items-center justify-center gap-1.5 mx-auto cursor-pointer"
            onClick={() => navigate("/login")}
          >
            <ArrowLeft size={15} />
            <span>Volver al inicio de sesión</span>
          </button>
        </div>
      </div>
    </div>
  );
};
