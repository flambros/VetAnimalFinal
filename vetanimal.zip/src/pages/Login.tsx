import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { LogoIcon } from "../components/LogoIcon";
import { Mail, Lock, ShieldCheck, UserCheck, ArrowRight, Eye, CheckCircle2 } from "lucide-react";
import { sendLoginAlertEmail, EmailMessage } from "../services/emailService";
import { EmailPreviewModal } from "../components/EmailPreviewModal";

interface LoginProps {
  navigate: (path: string) => void;
}

export const Login: React.FC<LoginProps> = ({ navigate }) => {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [remember, setRemember] = useState(false);
  const [loading, setLoading] = useState(false);

  // Email alert modal
  const [loginAlertEmail, setLoginAlertEmail] = useState<EmailMessage | null>(null);
  const [previewEmailOpen, setPreviewEmailOpen] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    const res = await login(email, password);
    setLoading(false);

    if (res.success) {
      // Dispatch Login Security Email
      const alertMsg = sendLoginAlertEmail(
        email.includes("admin") ? "Administrador VetAnimal" : "Agustina Gómez",
        email
      );
      setLoginAlertEmail(alertMsg);

      // Short delay or direct redirect
      setTimeout(() => {
        if (email.includes("admin") || email.includes("vetanimal.com")) {
          navigate("/admin/dashboard");
        } else {
          navigate("/");
        }
      }, 300);
    } else {
      setError(res.error || "Credenciales incorrectas. Verificá tu email y contraseña.");
    }
  };

  const handleQuickLogin = (role: "cliente" | "admin") => {
    if (role === "cliente") {
      const uEmail = "agustina.gomez@example.com";
      setEmail(uEmail);
      setPassword("123456");
      login(uEmail, "123456").then((res) => {
        if (res.success) {
          sendLoginAlertEmail("Agustina Gómez", uEmail);
          navigate("/");
        }
      });
    } else {
      const aEmail = "admin@vetanimal.com";
      setEmail(aEmail);
      setPassword("Admin2026!");
      login(aEmail, "Admin2026!").then((res) => {
        if (res.success) {
          sendLoginAlertEmail("Administrador VetAnimal", aEmail);
          navigate("/admin/dashboard");
        }
      });
    }
  };

  return (
    <>
      <div className="auth-wrap">
        <div
          className="auth-visual"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=1000&q=80')",
          }}
        >
          <div
            className="logo cursor-pointer flex items-center gap-2.5 text-white mb-auto"
            onClick={() => navigate("/")}
          >
            <LogoIcon size={32} />
            <span className="font-bold text-xl text-white tracking-tight">VetAnimal</span>
          </div>
          <h2 className="text-white font-bold text-xl sm:text-2xl mb-2">
            Cuidado y Atención
            <br />
            para Cada Compañero.
          </h2>
          <p className="text-blue-100 text-xs sm:text-sm">Acceso seguro para veterinarios y dueños de mascotas.</p>
        </div>

        <div className="auth-form-side">
          <div className="auth-form">
            <div className="mb-4 flex items-center gap-2">
              <LogoIcon size={20} />
              <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
                Acceso al Sistema
              </span>
            </div>

            <div className="space-y-2 mb-8">
              <h1 className="font-bold text-xl sm:text-2xl bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 bg-clip-text text-transparent">
                Iniciar Sesión
              </h1>
              <p className="text-slate-500 text-xs sm:text-sm leading-relaxed pt-1">
                Ingresá tus credenciales para acceder a la plataforma.
              </p>
            </div>

            {error && <div className="alert alert-error mb-4">{error}</div>}

            <form onSubmit={handleSubmit}>
              <div className="field">
                <label>Dirección de Email</label>
                <div className="input-wrap">
                  <span className="text-slate-400 flex items-center justify-center">
                    <Mail size={16} />
                  </span>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="nombre@ejemplo.com"
                    required
                  />
                </div>
              </div>

              <div className="field">
                <label>Contraseña</label>
                <div className="input-wrap">
                  <span className="text-slate-400 flex items-center justify-center">
                    <Lock size={16} />
                  </span>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                  />
                </div>
              </div>

              <div className="field-row flex items-center justify-between text-xs text-slate-600 mb-5">
                <label className="checkbox-row flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={remember}
                    onChange={(e) => setRemember(e.target.checked)}
                  />{" "}
                  <span>Recordarme</span>
                </label>
                <span
                  className="text-blue-600 hover:text-blue-700 font-semibold cursor-pointer"
                  onClick={() => navigate("/forgot-password")}
                >
                  ¿Olvidaste tu contraseña?
                </span>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="btn btn-primary btn-block font-bold text-base py-3 flex items-center justify-center gap-2 shadow-lg shadow-blue-600/25"
              >
                <span>{loading ? "Verificando..." : "Ingresar al Sistema"}</span>
                {!loading && <ArrowRight size={16} />}
              </button>
            </form>

            <div className="auth-foot mt-6 pt-4 border-t border-slate-100 text-xs text-slate-500 text-center">
              ¿No tenés una cuenta todavía?{" "}
              <span
                className="text-blue-600 hover:text-blue-700 cursor-pointer font-bold ml-1"
                onClick={() => navigate("/register")}
              >
                Crear Cuenta
              </span>
            </div>

            {/* Quick Login Assist Card */}
            <div className="mt-6 pt-5 border-t border-slate-200">
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 text-center">
                Accesos Directos de Demostración
              </div>
              <div className="space-y-2 text-xs">
                <div className="p-3 bg-white rounded-xl border border-blue-200 shadow-sm flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShieldCheck size={16} className="text-blue-600" />
                    <div>
                      <span className="font-bold text-blue-900 block">Veterinario / Admin</span>
                      <span className="text-[11px] text-slate-500 font-mono">admin@vetanimal.com</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleQuickLogin("admin")}
                    className="btn btn-primary btn-sm text-[11px] py-1 px-2.5 font-bold"
                  >
                    Usar
                  </button>
                </div>

                <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <UserCheck size={16} className="text-slate-600" />
                    <div>
                      <span className="font-bold text-slate-800 block">Cliente de Prueba</span>
                      <span className="text-[11px] text-slate-500 font-mono">agustina.gomez@example.com</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleQuickLogin("cliente")}
                    className="btn btn-outline btn-sm text-[11px] py-1 px-2.5 font-bold"
                  >
                    Usar
                  </button>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* Email Modal */}
      <EmailPreviewModal
        email={loginAlertEmail}
        isOpen={previewEmailOpen}
        onClose={() => setPreviewEmailOpen(false)}
        onNavigate={navigate}
      />
    </>
  );
};
