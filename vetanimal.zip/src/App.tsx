import React, { useState, useEffect } from "react";
import { AuthProvider } from "./context/AuthContext";
import { CartProvider } from "./context/CartContext";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import { ChatWidget } from "./components/ChatWidget";

import { Home } from "./pages/Home";
import { Login } from "./pages/Login";
import { Register } from "./pages/Register";
import { ForgotPassword } from "./pages/ForgotPassword";
import { BookingWizard } from "./pages/BookingWizard";
import { HistorialClinico } from "./pages/HistorialClinico";
import { MascotaNueva } from "./pages/MascotaNueva";
import { Tienda } from "./pages/Tienda";
import { Carrito } from "./pages/Carrito";
import { Perfil } from "./pages/Perfil";
import { AdminDashboard } from "./pages/AdminDashboard";
import { AdminTurnos } from "./pages/AdminTurnos";
import { AdminPacientes } from "./pages/AdminPacientes";
import { AdminTienda } from "./pages/AdminTienda";

function AppContent() {
  const [currentPath, setCurrentPath] = useState(window.location.pathname || "/");

  const navigate = (path: string) => {
    window.history.pushState({}, "", path);
    // Extraer solo la ruta base sin query params para el ruteo
    const basePath = path.split("?")[0];
    setCurrentPath(basePath);
    window.scrollTo(0, 0);
  };

  useEffect(() => {
    const onPopState = () => {
      setCurrentPath(window.location.pathname || "/");
    };
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);

  const isAuthPage =
    currentPath === "/login" ||
    currentPath === "/register" ||
    currentPath === "/forgot-password";

  const isAdminPage = currentPath.startsWith("/admin");

  return (
    <div className="min-h-screen flex flex-col justify-between">
      {!isAuthPage && !isAdminPage && (
        <Header currentPath={currentPath} navigate={navigate} />
      )}

      <main className="flex-1">
        {currentPath === "/" && <Home navigate={navigate} />}
        {currentPath === "/login" && <Login navigate={navigate} />}
        {currentPath === "/register" && <Register navigate={navigate} />}
        {currentPath === "/forgot-password" && (
          <ForgotPassword navigate={navigate} />
        )}
        {currentPath === "/booking" && <BookingWizard navigate={navigate} />}
        {currentPath === "/historial" && <HistorialClinico navigate={navigate} />}
        {currentPath === "/mascota-nueva" && <MascotaNueva navigate={navigate} />}
        {currentPath === "/tienda" && <Tienda navigate={navigate} />}
        {currentPath === "/carrito" && <Carrito navigate={navigate} />}
        {currentPath === "/perfil" && <Perfil navigate={navigate} />}

        {currentPath === "/admin" && (
          <AdminDashboard navigate={navigate} activeTab="dashboard" />
        )}
        {currentPath === "/admin/dashboard" && (
          <AdminDashboard navigate={navigate} activeTab="dashboard" />
        )}
        {currentPath === "/admin/turnos" && <AdminTurnos navigate={navigate} />}
        {currentPath === "/admin/pacientes" && (
          <AdminPacientes navigate={navigate} />
        )}
        {currentPath === "/admin/tienda" && (
          <AdminTienda navigate={navigate} />
        )}
      </main>

      {!isAuthPage && !isAdminPage && <Footer navigate={navigate} />}

      {!isAuthPage && <ChatWidget navigate={navigate} />}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <AppContent />
      </CartProvider>
    </AuthProvider>
  );
}
