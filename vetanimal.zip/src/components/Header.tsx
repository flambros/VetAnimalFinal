import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";
import { LogoIcon } from "./LogoIcon";
import { ShoppingCart, LogOut, Mail, User as UserIcon, Bell } from "lucide-react";
import { getSentEmails, EmailMessage } from "../services/emailService";
import { EmailPreviewModal } from "./EmailPreviewModal";

interface HeaderProps {
  currentPath: string;
  navigate: (path: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ currentPath, navigate }) => {
  const { user, logout } = useAuth();
  const { itemCount } = useCart();
  const [selectedEmail, setSelectedEmail] = useState<EmailMessage | null>(null);
  const [showInbox, setShowInbox] = useState(false);

  const sentEmails = getSentEmails();

  return (
    <>
      <header className="site-header">
        {/* Zone 1: Brand with Vector Logo */}
        <div 
          className="logo cursor-pointer flex items-center gap-3 hover:opacity-90 transition-opacity" 
          onClick={() => navigate("/")}
        >
          <LogoIcon size={38} />
          <div className="flex flex-col">
            <span className="font-extrabold text-xl leading-tight tracking-tight bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-600 bg-clip-text text-transparent">
              VetAnimal
            </span>
          </div>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="main-nav">
          <button
            className={currentPath === "/" ? "active" : ""}
            onClick={() => navigate("/")}
          >
            Inicio
          </button>
          <button
            className={currentPath === "/booking" ? "active" : ""}
            onClick={() => navigate("/booking")}
          >
            Turnos
          </button>
          <button
            className={currentPath === "/historial" ? "active" : ""}
            onClick={() => navigate("/historial")}
          >
            Diagnósticos
          </button>
          <button
            className={currentPath === "/tienda" ? "active" : ""}
            onClick={() => navigate("/tienda")}
          >
            Tienda &amp; Farmacia
          </button>
          {itemCount > 0 && (
            <button
              className={`flex items-center gap-1.5 ${currentPath === "/carrito" ? "active" : ""}`}
              onClick={() => navigate("/carrito")}
            >
              <ShoppingCart size={16} />
              <span>Carrito</span>
              <span className="bg-blue-600 text-white rounded-full text-xs px-2 py-0.5 font-bold shadow-sm">
                {itemCount}
              </span>
            </button>
          )}
        </nav>

        {/* Zone 3: Actions */}
        <div className="header-actions">
          {/* Email Inbox Button */}
          {sentEmails.length > 0 && (
            <div className="relative">
              <button
                onClick={() => setShowInbox(!showInbox)}
                className="btn btn-light btn-sm flex items-center gap-1.5 text-xs text-slate-700 hover:text-blue-600 hover:border-blue-300 relative py-1.5 px-3"
                title="Ver correos electrónicos enviados"
              >
                <Mail size={15} className="text-blue-600" />
                <span className="hidden sm:inline">Emails</span>
                <span className="w-5 h-5 rounded-full bg-blue-600 text-white text-[10px] flex items-center justify-center font-bold">
                  {sentEmails.length}
                </span>
              </button>

              {/* Quick Dropdown of recent emails */}
              {showInbox && (
                <div className="absolute right-0 top-full mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-xl border border-slate-200 p-3 z-50 animate-in fade-in zoom-in-95">
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 px-1">
                    <span className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                      <Mail size={14} className="text-blue-600" />
                      <span>Bandeja de Emails Emitidos</span>
                    </span>
                    <span className="text-[11px] text-slate-400 font-medium">
                      {sentEmails.length} mensajes
                    </span>
                  </div>
                  <div className="max-h-64 overflow-y-auto space-y-1.5 divide-y divide-slate-50">
                    {sentEmails.map((em) => (
                      <div
                        key={em.id}
                        onClick={() => {
                          setSelectedEmail(em);
                          setShowInbox(false);
                        }}
                        className="p-2 rounded-xl hover:bg-blue-50/70 transition-colors cursor-pointer text-left"
                      >
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-bold text-blue-900 truncate max-w-[180px]">
                            {em.recipientName}
                          </span>
                          <span className="text-slate-400 text-[10px]">{em.date}</span>
                        </div>
                        <p className="text-xs font-semibold text-slate-800 truncate mt-0.5">
                          {em.subject}
                        </p>
                        <p className="text-[11px] text-slate-500 truncate">
                          {em.previewText}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {user ? (
            <>
              {user.rol === "veterinario" && (
                <button
                  onClick={() => navigate("/admin/dashboard")}
                  className="btn btn-outline btn-sm text-xs font-bold"
                >
                  Panel Veterinario
                </button>
              )}
              <button
                onClick={() => navigate("/perfil")}
                className="btn btn-light btn-sm flex items-center gap-2"
                title={`Perfil de ${user.nombre}`}
              >
                <div className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold">
                  {user.nombre.substring(0, 1).toUpperCase()}
                </div>
                <span className="text-xs font-semibold max-w-[100px] truncate">{user.nombre.split(" ")[0]}</span>
              </button>
              <button onClick={logout} className="btn btn-light btn-sm text-xs text-slate-600 hover:text-red-600" title="Cerrar sesión">
                <LogOut size={14} />
                <span>Salir</span>
              </button>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => navigate("/login")}
                className="btn btn-outline btn-sm text-xs font-semibold"
              >
                Acceso Admin / Cliente
              </button>
              <button
                onClick={() => navigate("/booking")}
                className="btn btn-primary btn-sm text-xs font-bold"
              >
                Pedir Turno
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Modal for email preview */}
      <EmailPreviewModal
        email={selectedEmail}
        isOpen={Boolean(selectedEmail)}
        onClose={() => setSelectedEmail(null)}
        onNavigate={navigate}
      />
    </>
  );
};
