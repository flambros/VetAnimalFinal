import React from "react";
import { EmailMessage } from "../services/emailService";
import { LogoIcon } from "./LogoIcon";
import { X, Mail, CheckCircle2, ShieldCheck, ShoppingBag, ExternalLink, Calendar, Copy, Check } from "lucide-react";

interface EmailPreviewModalProps {
  email: EmailMessage | null;
  isOpen: boolean;
  onClose: () => void;
  onNavigate?: (path: string) => void;
}

export const EmailPreviewModal: React.FC<EmailPreviewModalProps> = ({
  email,
  isOpen,
  onClose,
  onNavigate,
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!isOpen || !email) return null;

  const handleCopy = () => {
    navigator.clipboard?.writeText(JSON.stringify(email, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Email App Header Bar */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-sm">
              <Mail size={16} />
            </div>
            <div>
              <div className="text-xs text-blue-300 font-semibold uppercase tracking-wider">
                Bandeja de Entrada Digital
              </div>
              <div className="text-sm font-bold text-white flex items-center gap-2">
                <span>Notificación de VetAnimal</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Entregado
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors text-xs flex items-center gap-1"
              title="Copiar contenido"
            >
              {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {/* Email Metadata Header */}
        <div className="bg-slate-50 px-6 py-3.5 border-b border-slate-200 text-xs text-slate-600 space-y-1.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-900">De:</span>
              <span className="text-slate-700 font-medium">VetAnimal Oficial &lt;veterinariavet101@gmail.com&gt;</span>
            </div>
            <span className="text-slate-400">{email.date}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-900">Para:</span>
            <span className="text-blue-700 font-medium">{email.recipientName} &lt;{email.to}&gt;</span>
          </div>
          <div className="flex items-center gap-2 pt-0.5">
            <span className="font-semibold text-slate-900">Asunto:</span>
            <span className="text-slate-900 font-bold">{email.subject}</span>
          </div>
        </div>

        {/* Email Rendered Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-slate-800 bg-white">
          {/* Branded Email Header */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-blue-700 via-blue-800 to-indigo-900 text-white text-center shadow-md relative overflow-hidden">
            <div className="relative z-10 flex flex-col items-center">
              <div className="p-2.5 bg-white rounded-2xl shadow-lg mb-3">
                <LogoIcon size={38} />
              </div>
              <h2 className="text-xl font-bold tracking-tight text-white mb-1">
                {email.content.title}
              </h2>
              <p className="text-blue-200 text-xs max-w-md">
                {email.content.subtitle}
              </p>
            </div>
            {/* Subtle light effect */}
            <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none" />
          </div>

          {/* Body Paragraphs */}
          <div className="space-y-3 text-sm text-slate-700 leading-relaxed">
            {email.content.bodyParagraphs.map((p, idx) => (
              <p key={idx}>{p}</p>
            ))}
          </div>

          {/* Details Table */}
          {email.content.details && email.content.details.length > 0 && (
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <ShieldCheck size={14} className="text-blue-600" />
                <span>Detalle de la Operación</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {email.content.details.map((d, idx) => (
                  <div key={idx} className="bg-white p-2.5 rounded-xl border border-slate-200/80">
                    <span className="text-slate-400 block text-[11px] font-medium">{d.label}</span>
                    <strong className="text-slate-900 font-semibold text-xs mt-0.5 block">{d.value}</strong>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* If Order: Itemized Invoice */}
          {email.content.items && email.content.items.length > 0 && (
            <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
              <div className="bg-blue-50/60 px-4 py-2.5 border-b border-slate-200 flex items-center justify-between">
                <span className="text-xs font-bold text-blue-950 flex items-center gap-1.5">
                  <ShoppingBag size={14} className="text-blue-600" />
                  <span>Resumen de Productos Comprados</span>
                </span>
                <span className="text-xs font-bold text-blue-700">
                  Orden #{email.content.orderCode}
                </span>
              </div>
              <div className="divide-y divide-slate-100">
                {email.content.items.map((item, idx) => (
                  <div key={idx} className="p-3 px-4 flex items-center justify-between text-xs">
                    <div>
                      <strong className="text-slate-900 font-semibold">{item.name}</strong>
                      <span className="text-slate-500 block text-[11px]">
                        Cantidad: {item.quantity} × ${item.price.toFixed(2)}
                      </span>
                    </div>
                    <div className="text-right font-bold text-slate-900">
                      ${(item.quantity * item.price).toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>
              {email.content.total !== undefined && (
                <div className="bg-slate-50 p-3 px-4 flex items-center justify-between text-sm font-bold text-slate-900 border-t border-slate-200">
                  <span>Total Facturado</span>
                  <span className="text-base text-blue-700">${email.content.total.toFixed(2)}</span>
                </div>
              )}
            </div>
          )}

          {/* Action CTA */}
          {email.content.actionText && (
            <div className="text-center pt-2">
              <button
                onClick={() => {
                  onClose();
                  if (onNavigate && email.content.actionUrl) {
                    onNavigate(email.content.actionUrl);
                  }
                }}
                className="btn btn-primary px-6 py-2.5 text-xs font-bold shadow-md shadow-blue-600/20"
              >
                <span>{email.content.actionText}</span>
                <ExternalLink size={13} />
              </button>
            </div>
          )}

          {/* Email Footer Note */}
          <div className="text-center text-[11px] text-slate-400 pt-4 border-t border-slate-100 space-y-1">
            <p>Este es un correo electrónico oficial emitido automáticamente por VetAnimal.</p>
            <p>Tel: (011) 4000-1000 • Email: veterinariavet101@gmail.com</p>
          </div>
        </div>

        {/* Modal Bottom Actions */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-semibold">
            <CheckCircle2 size={15} />
            <span>Correo enviado y registrado correctamente</span>
          </div>
          <button
            onClick={onClose}
            className="btn btn-light btn-sm text-xs py-1.5 px-4 font-semibold"
          >
            Cerrar previsualización
          </button>
        </div>
      </div>
    </div>
  );
};
