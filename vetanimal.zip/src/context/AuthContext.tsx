import React, { createContext, useContext, useState, useEffect } from "react";
import { User } from "../types";

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  register: (nombre: string, email: string, pass: string, telefono?: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  setUserDirect: (user: User | null) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem("vet_user");
    return saved ? JSON.parse(saved) : null;
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      localStorage.setItem("vet_user", JSON.stringify(user));
    } else {
      localStorage.removeItem("vet_user");
    }
  }, [user]);

  const login = async (email: string, pass: string) => {
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password: pass }),
      });
      const data = await res.json();
      if (!res.ok) {
        setLoading(false);
        return { success: false, error: data.error || "Error al iniciar sesión" };
      }
      setUser(data.user);
      setLoading(false);
      return { success: true };
    } catch (e: any) {
      setLoading(false);
      return { success: false, error: e.message || "Error de red" };
    }
  };

  const register = async (nombre: string, email: string, pass: string, telefono?: string) => {
    setLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nombre, email, password: pass, telefono }),
      });
      const data = await res.json();
      if (!res.ok) {
        setLoading(false);
        return { success: false, error: data.error || "Error al registrarse" };
      }
      setUser(data.user);
      setLoading(false);
      return { success: true };
    } catch (e: any) {
      setLoading(false);
      return { success: false, error: e.message || "Error de red" };
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("vet_user");
    fetch("/api/auth/logout", { method: "POST" }).catch(() => {});
  };

  const setUserDirect = (u: User | null) => {
    setUser(u);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, setUserDirect }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
