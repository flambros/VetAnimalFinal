export interface EmailMessage {
  id: string;
  type: "welcome" | "login" | "order" | "appointment";
  to: string;
  recipientName: string;
  subject: string;
  date: string;
  previewText: string;
  content: {
    title: string;
    subtitle: string;
    bodyParagraphs: string[];
    items?: Array<{ name: string; quantity: number; price: number }>;
    total?: number;
    orderCode?: string;
    details?: Array<{ label: string; value: string }>;
    actionUrl?: string;
    actionText?: string;
  };
}

const STORAGE_KEY = "vetanimal_sent_emails";

export const getSentEmails = (): EmailMessage[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
};

export const saveSentEmail = (email: Omit<EmailMessage, "id" | "date">): EmailMessage => {
  const newEmail: EmailMessage = {
    ...email,
    id: `EMAIL-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    date: new Date().toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "short" }),
  };

  try {
    const current = getSentEmails();
    const updated = [newEmail, ...current].slice(0, 30); // keep last 30
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error("Error saving sent email", e);
  }

  return newEmail;
};

export const sendWelcomeEmail = (name: string, email: string) => {
  return saveSentEmail({
    type: "welcome",
    to: email,
    recipientName: name,
    subject: "🐾 ¡Bienvenido a VetAnimal! Tu cuenta ha sido activada con éxito",
    previewText: `Hola ${name}, tu cuenta en VetAnimal está lista para gestionar la salud de tus mascotas.`,
    content: {
      title: `¡Hola ${name}! Te damos la bienvenida a VetAnimal`,
      subtitle: "Tu cuenta ha sido creada y validada satisfactoriamente.",
      bodyParagraphs: [
        "Nos alegra acompañarte en el cuidado, prevención y bienestar de tus compañeros de cuatro patas.",
        "Desde tu panel de usuario podés registrar a tus mascotas, agendar turnos de consulta presencial, acceder al historial médico digital con vacunas y comprar alimentos o medicamentos en nuestra farmacia oficial con entrega a domicilio.",
      ],
      details: [
        { label: "Usuario registrado", value: name },
        { label: "Correo vinculado", value: email },
        { label: "Estado de cuenta", value: "Activa & Verificada" },
        { label: "Fecha de registro", value: new Date().toLocaleDateString("es-AR") },
      ],
      actionText: "Ir a mi Panel de Mascotas",
      actionUrl: "/perfil",
    },
  });
};

export const sendLoginAlertEmail = (name: string, email: string) => {
  const now = new Date();
  const timeStr = now.toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit" });
  const dateStr = now.toLocaleDateString("es-AR", { day: "2-digit", month: "long", year: "numeric" });

  return saveSentEmail({
    type: "login",
    to: email,
    recipientName: name,
    subject: "🛡️ Aviso de Seguridad: Nuevo inicio de sesión en VetAnimal",
    previewText: `Se registró un nuevo inicio de sesión en tu cuenta de VetAnimal a las ${timeStr}.`,
    content: {
      title: "Nuevo inicio de sesión detectado",
      subtitle: "Aviso automático de seguridad para proteger tu cuenta.",
      bodyParagraphs: [
        `Hola ${name}, te informamos que se acaba de registrar un acceso a tu cuenta de VetAnimal.`,
        "Si fuiste vos, podés ignorar este mensaje. Si no reconocés este inicio de sesión, te sugerimos cambiar tu contraseña de inmediato o contactar a nuestro equipo de soporte.",
      ],
      details: [
        { label: "Cuenta", value: email },
        { label: "Fecha y Hora", value: `${dateStr} a las ${timeStr} hs` },
        { label: "Dispositivo", value: "Navegador Web Seguro (HTTPS)" },
        { label: "Ubicación aproximada", value: "Buenos Aires, Argentina" },
        { label: "Estado", value: "Sesión autorizada" },
      ],
      actionText: "Verificar mi Perfil",
      actionUrl: "/perfil",
    },
  });
};

export const sendOrderConfirmationEmail = (
  name: string,
  email: string,
  orderCode: string,
  items: Array<{ name: string; quantity: number; price: number }>,
  total: number,
  shippingAddress: string
) => {
  return saveSentEmail({
    type: "order",
    to: email,
    recipientName: name,
    subject: `📦 Confirmación de Compra #${orderCode} - VetAnimal`,
    previewText: `¡Gracias por tu compra ${name}! Tu pedido #${orderCode} ha sido confirmado y está en preparación.`,
    content: {
      title: `¡Gracias por tu compra, ${name}!`,
      subtitle: `Tu pedido #${orderCode} fue procesado correctamente.`,
      bodyParagraphs: [
        "Hemos recibido tu pago y nuestro equipo de farmacia ya se encuentra preparando los productos con todas las normas de bioseguridad y trazabilidad.",
        "A continuación podés revisar el resumen detallado de tu orden y el comprobante digital.",
      ],
      orderCode,
      items,
      total,
      details: [
        { label: "Número de Pedido", value: `#${orderCode}` },
        { label: "Destinatario", value: `${name} (${email})` },
        { label: "Entrega / Retiro", value: shippingAddress || "Envío a domicilio" },
        { label: "Estado del Pedido", value: "Pagado & En Preparación" },
      ],
      actionText: "Seguir mi Pedido en Tienda",
      actionUrl: "/tienda",
    },
  });
};
